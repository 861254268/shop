package com.imooc.flink.course08

import java.util.Properties

import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer
import org.apache.flink.streaming.util.serialization.KeyedSerializationSchemaWrapper
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/22 22:11
  * @File: KafkaConnectorProducerApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: flink对接kafka作为sink使用
  */
object KafkaConnectorProducerApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    // 从socket接收数据，通过flink，将数据sink到kafka
    val data = env.socketTextStream("localhost", 9999)

    val topic = "test1"
    val properties = new Properties()
    properties.setProperty("bootstrap.servers", "localhost:9092")

    val kafkaSink = new FlinkKafkaProducer[String](topic,
      new KeyedSerializationSchemaWrapper[String](new SimpleStringSchema()), //包装器
      properties)

    data.addSink(kafkaSink)


    env.execute("KafkaConnectorProducerApp")
  }
}
