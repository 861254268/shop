package com.imooc.flink.course06


//object TableSQLAPI {
//  def main(args: Array[String]): Unit = {
//    print("由于flink版本的升级，从flink1.7升级到1.9，注释掉了flink-table依赖。" +
//      "为了不影响整个项目环境的使用，因此将该程序注释掉。。。")
//  }
//}

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.table.api.TableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/18 15:56
  * @File: TableSQLAPI.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Scala完成table api&sql功能的开发
  */
object TableSQLAPI {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    val tableEnv = TableEnvironment.getTableEnvironment(env)

    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\data\\06\\sales.csv"

    // 已经拿到了DataSet
    val csv = env.readCsvFile[SalesLog](filePath, ignoreFirstLine = true)
    //    csv.print()


    // DataSet==>Table
    val salesTable = tableEnv.fromDataSet(csv)

    // Table==>table
    tableEnv.registerTable("sales", salesTable)

    // sql
    val resultTable = tableEnv.sqlQuery("select customerId,sum(amountPaid) as money " +
      "from sales group by customerId order by customerId")

    tableEnv.toDataSet[Row](resultTable).print() //[Row] 是类
  }

  case class SalesLog(transactionId: String,
                      customerId: String,
                      itemId: String,
                      amountPaid: Double)

}
