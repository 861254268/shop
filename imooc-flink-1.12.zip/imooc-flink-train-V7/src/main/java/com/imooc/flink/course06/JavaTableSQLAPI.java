package com.imooc.flink.course06;


import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.java.BatchTableEnvironment;
import org.apache.flink.types.Row;


/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/18 18:39
 * @File: JavaTableSQLAPI.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Java完成table api&sql功能的开发
 */
public class JavaTableSQLAPI {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        BatchTableEnvironment tableEnv = BatchTableEnvironment.getTableEnvironment(env);

        String filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\data\\06\\sales.csv";

        // 已经拿到了DataSet
        DataSource<Sales> csv = env.readCsvFile(filePath)
                .ignoreFirstLine()
                .pojoType(Sales.class, "transactionId", "customerId", "itemId", "amountPaid");
        // csv.print();  // 读出来是地址值：com.imooc.flink.course06.JavaTableSQLAPI$Sales@11841b15

        // DataSet==>Table
        Table saleTable = tableEnv.fromDataSet(csv);
        // Table==>table
        tableEnv.registerTable("sales", saleTable);
        // sql
        Table resultTable = tableEnv.sqlQuery("select customerId,sum(amountPaid) as money " +
                "from sales group by customerId order by customerId");

        DataSet<Row> result = tableEnv.toDataSet(resultTable, Row.class);
        result.print();
    }

    public static class Sales {
        public String transactionId;
        public String customerId;
        public String itemId;
        public Double amountPaid;
    }
}
