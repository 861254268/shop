package com.imooc.flink.KafkaAndEsTest;

import org.apache.commons.collections.map.HashedMap;
import org.apache.flink.annotation.Public;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch6.ElasticsearchSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.common.protocol.types.Field;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Requests;
import org.elasticsearch.client.RestClientBuilder;

import java.util.*;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/6 21:16
 * @File: JavaDataToEs.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 将Kafka数据写入ES中
 */
public class JavaDataToEs {

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStream<String> streram = readfromkafka(env);
        sendtoes(streram);
        env.execute("JavaToEs");
    }

    //从kafka读取数据
    public static DataStream<String> readfromkafka(StreamExecutionEnvironment env) {
        String topic = "topictest01";
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");
        properties.setProperty("group.id", "com.gree");

        FlinkKafkaConsumer consumer = new FlinkKafkaConsumer<String>(topic, new SimpleStringSchema(), properties);

        DataStream<String> stream = env.addSource(consumer);
        return stream;
    }


    //将读取的数据写入es
    public static void sendtoes(DataStream<String> input) {
        List<HttpHost> httphost = new ArrayList<>();
        httphost.add(new HttpHost("localhost", 9200, "http"));
        ElasticsearchSinkFunction<String> indexlog = new ElasticsearchSinkFunction<String>() {
            public IndexRequest createindexrequest(String element) {
                String[] data = element.split("\t");
                Map<String, String> esjosn = new HashMap<>();
                esjosn.put("company", data[0]);
                esjosn.put("yuming", data[1]);
                esjosn.put("time", data[2]);
                //System.out.println(esjosn);
                return Requests.indexRequest()
                        .index("180867_0805")
                        .source(esjosn);
            }

            @Override
            public void process(String element, RuntimeContext runtimeContext, RequestIndexer requestIndexer) {
                requestIndexer.add(createindexrequest(element));
            }
        };
        ElasticsearchSink.Builder<String> esSink = new ElasticsearchSink.Builder<>(httphost, indexlog);


        //设置用户名和密码
        esSink.setRestClientFactory
                (
                        restClientBuilder ->
                        {
                            restClientBuilder.setHttpClientConfigCallback(new RestClientBuilder.HttpClientConfigCallback() {
                                @Override
                                public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpAsyncClientBuilder) {
                                    CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                                    // credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials("elastic", "123456"));
                                    credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials("",""));
                                    return httpAsyncClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                                }
                            });
                        }

                );
        esSink.setBulkFlushMaxActions(1);
        input.addSink(esSink.build());
    }

}