package com.imooc.flink.KafkaAndEsTest;

import org.apache.kafka.clients.producer.KafkaProducer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/6 20:50
 * @File: JavaDataToKafkaApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 写数据到Kafka
 */
public class JavaDataToKafkaApp {
    public static void main(String[] args) throws Exception {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", StringSerializer.class.getName());
        String topic = "topictest01";
        KafkaProducer producer = new KafkaProducer(properties);
        while(true)
        {
            StringBuilder builder = new StringBuilder();
            builder.append("gree").append("\t").append("com").append("\t")
                    .append((new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"))
                            .format(new Date())).append("\t");
            producer.send(new ProducerRecord(topic, builder.toString()));
            System.out.println(builder.toString());
            Thread.sleep(2000L);
        }

    }
}