package com.imooc.flink.window;


import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.Tumble;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.types.Row;

import static org.apache.flink.table.api.Expressions.$;
import static org.apache.flink.table.api.Expressions.lit;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 21:47
 * @File: WindowApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Flink Table API结合Window及EventTime编程
 */
public class WindowApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env);

        /**
         * 窗口大小10s,wm允许是0
         *
         * 0000-9999  pk:205    zs:6
         * 10000-19999  pk:45
         * */
        SingleOutputStreamOperator<Tuple4<Long, String, String, Double>> input = env.fromElements( // 时间(eventtime),用户名,购买的商品,价格
                "1000,pk,spark,75",
                "2000,pk,flink,65",
                "2000,zs,kuangquanshui,3",
                "3000,pk,cdh,65",
                "9999,zs,xuebi,3",
                "19999,pk,hive,45"
        ).map(new MapFunction<String, Tuple4<Long, String, String, Double>>() {
            @Override
            public Tuple4<Long, String, String, Double> map(String s) throws Exception {
                String[] splits = s.split(",");
                Long time = Long.parseLong(splits[0]);
                String user = splits[1];
                String book = splits[2];
                Double money = Double.parseDouble(splits[3]);

                return Tuple4.of(time, user, book, money);
            }
        })
                .assignTimestampsAndWatermarks(
                        new BoundedOutOfOrdernessTimestampExtractor<Tuple4<Long, String, String, Double>>(Time.seconds(0)) {
                            @Override
                            public long extractTimestamp(Tuple4<Long, String, String, Double> element) {
                                return element.f0;
                            }
                        }
                );
//        input.print();

        apiWindowEventTime(tEnv, input);    // api
        // sqlWindowEventTime(tEnv, input);    // sql

        env.execute("WindowApp");
    }

    public static void sqlWindowEventTime(StreamTableEnvironment tEnv, SingleOutputStreamOperator<Tuple4<Long, String, String, Double>> input) {
        tEnv.createTemporaryView("access", input, $("time"), $("user_id"), $("book"), $("money"), $("rowtime").rowtime());
        Table resultTable = tEnv.sqlQuery("select user_id, sum(money), TUMBLE_START(rowtime, interval '10' second) as win_start,TUMBLE_END(rowtime, interval '10' second) as win_end from access group by TUMBLE(rowtime, interval '10' second), user_id");
        tEnv.toRetractStream(resultTable, Row.class).filter(x -> x.f0).print();
    }

    public static void apiWindowEventTime(StreamTableEnvironment tEnv, SingleOutputStreamOperator<Tuple4<Long, String, String, Double>> input) {
        Table table = tEnv.fromDataStream(input, $("time"), $("user_id"), $("book"), $("money"), $("rowtime").rowtime());
        Table resultTable = table.window(Tumble.over(lit(10).seconds()).on($("rowtime")).as("win"))
                .groupBy($("user_id"), $("win"))
                .select($("user_id"), $("money").sum().as("total"), $("win").start(), $("win").end());

        tEnv.toRetractStream(resultTable, Row.class).filter(x -> x.f0).print();
        // tEnv.toRetractStream(table, Row.class).print();
    }
}