package com.imooc.flink.connector;

import org.apache.flink.calcite.shaded.com.fasterxml.jackson.core.StreamWriteFeature;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.descriptors.Csv;
import org.apache.flink.table.descriptors.FileSystem;
import org.apache.flink.table.descriptors.Schema;
import org.apache.flink.types.Row;

import static org.apache.flink.table.api.Expressions.$;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 20:24
 * @File: ConnectorApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: SQL FileSystem Connector读取数据/写出数据
 */
public class ConnectorApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment().setParallelism(2);
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env);

        tEnv.connect(new FileSystem().path("data/access.log"))
                .withFormat(new Csv())
                .withSchema(new Schema()
                        .field("timestamp", DataTypes.BIGINT())
                        .field("domain", DataTypes.STRING())
                        .field("traffic", DataTypes.DOUBLE())
                ).createTemporaryTable("access_ods");

        Table accessOds = tEnv.from("access_ods");
        Table resultTable = accessOds
                .select($("domain"), $("traffic"))
                .where($("domain").isNotEqual("imooc.com"));
        tEnv.toAppendStream(resultTable, Row.class)
                .print();

        // 写入操作
        tEnv.connect(new FileSystem().path("data/connector/out"))
                .withFormat(new Csv())
                .withSchema(new Schema()
                        .field("domain", DataTypes.STRING())
                        .field("traffic", DataTypes.DOUBLE())
                ).createTemporaryTable("fileoutput");

        resultTable.executeInsert("fileoutput");

        env.execute("ConnectorApp");
    }
}
