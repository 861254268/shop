package com.imooc.flink.utils;

import java.io.Serializable;

public class IPUtil implements Serializable {

	public static IPUtil getInstance() {
		return null;
	}
	public String[] getInfos(String ip) {

		return null;
	}
}