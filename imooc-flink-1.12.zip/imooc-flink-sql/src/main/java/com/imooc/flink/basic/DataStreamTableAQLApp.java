package com.imooc.flink.basic;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.types.Row;

import static org.apache.flink.table.api.Expressions.$;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 20:12
 * @File: DataStreamTableAQLApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Flink SQL整合DataStream编程
 * @descirption: Flink SQL整合DataStream编程
 */
public class DataStreamTableAQLApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        StreamTableEnvironment tableEnv = StreamTableEnvironment.create(env);

        // sqlRowOrAccess(tableEnv, env); //sqlRowOrAccess
        // tableAPI(tableEnv, env);  //tableAPI
        sql_toRetractStream(tableEnv, env);  //sql_toRetractStream

        env.execute("DataStreamTableSQLApp");
    }

    public static void sql_toRetractStream(StreamTableEnvironment tableEnv, StreamExecutionEnvironment env) {
        // 获取数据源
        DataStreamSource<String> source = env.readTextFile("data/access.log");

        SingleOutputStreamOperator<Access> stream = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String s) throws Exception {
                String[] splits = s.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });
        // stream.print();

        // DataStream ==> Table
        Table table = tableEnv.fromDataStream(stream);
        tableEnv.createTemporaryView("access", table);
        Table resultTable = tableEnv.sqlQuery("select domain,sum(traffic) as traffics from access group by domain");
        // tableEnv.toAppendStream(resultTable, Row.class).print("Row:");
        // 报错：toAppendStream doesn't support consuming update changes
        // which is produced by node GroupAggregate(groupBy=[domain], select=[domain, SUM(traffic) AS traffics])
        /**
         * toRetractStream
         * 第一个字段boolean类型表示
         * true: 最新的数据
         * false: 过期的数据
         * */
        tableEnv.toRetractStream(resultTable, Row.class)
                .filter(x->x.f0)// 过滤留下true的数据
                .print("Row:");
    }

    public static void tableAPI(StreamTableEnvironment tableEnv, StreamExecutionEnvironment env) {
        // 获取数据源
        DataStreamSource<String> source = env.readTextFile("data/access.log");

        SingleOutputStreamOperator<Access> stream = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String s) throws Exception {
                String[] splits = s.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });
        // stream.print();

        // DataStream ==> Table
        Table table = tableEnv.fromDataStream(stream);

        // Table resultTable = table.select("*").where("domain='imooc.com'"); // 该select和where已过时
        Table resultTable = table.select($("domain"), $("traffic"))
                .where($("domain").isGreaterOrEqual("imooc.com"));
        tableEnv.toAppendStream(resultTable, Row.class).print();
    }

    public static void sqlRowOrAccess(StreamTableEnvironment tableEnv, StreamExecutionEnvironment env) {
        // 获取数据源
        DataStreamSource<String> source = env.readTextFile("data/access.log");

        SingleOutputStreamOperator<Access> stream = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String s) throws Exception {
                String[] splits = s.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });
        // stream.print();

        // DataStream ==> Table
        Table table = tableEnv.fromDataStream(stream);
        tableEnv.createTemporaryView("access", table);
        Table resultTable = tableEnv.sqlQuery("select * from access where domain='imooc.com'");
        // Table ==> DataStream
        //对比Row与Access的输出：
        DataStream<Row> rowDataStream = tableEnv.toAppendStream(resultTable, Row.class);
        rowDataStream.print("Row:");
        DataStream<Access> stream1 = tableEnv.toAppendStream(resultTable, Access.class);
        stream1.print("Access:");


    }
}
