package com.imooc.flink.basic;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 20:12
 * @File: Access.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class Access {
    private Long time;
    private String domain;
    private Double traffic;

    // 生成无参的构造器
    public Access() {

    }

    public Access(Long time, String domain, Double traffic) {
        this.time = time;
        this.domain = domain;
        this.traffic = traffic;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public Double getTraffic() {
        return traffic;
    }

    public void setTraffic(Double traffic) {
        this.traffic = traffic;
    }

    @Override
    public String toString() {
        return "Access{" +
                "time=" + time +
                ", domain='" + domain + '\'' +
                ", traffic=" + traffic +
                '}';
    }
}
