package com.imooc.flink;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/27 22:46
 * @File: WindowWMApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 老版本VM的用法
 */
public class WindowWMApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 时间语义：1.10以及之前的旧版本该时间语义一定要写
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);

        // 1000,a,1
        env.socketTextStream("localhost", 9999)
                .assignTimestampsAndWatermarks( // 过时的方法,在1.10是不过时的
                        new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) {
                            // Time.seconds(0): 不允许延迟的
                            // Time.seconds(2):允许2s延迟
                            @Override
                            public long extractTimestamp(String element) {
                                return Long.parseLong(element.split(",")[0]);
                            }
                        }
                )
                .map(new MapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> map(String value) throws Exception {
                        String[] splits = value.split(",");
                        return Tuple2.of(splits[1].trim(), Integer.parseInt(splits[2].trim()));
                    }
                })
                .keyBy(x -> x.f0)
                .window(TumblingEventTimeWindows.of(Time.seconds(5)))
                .sum(1)
                .print();
        env.execute();
    }
}
