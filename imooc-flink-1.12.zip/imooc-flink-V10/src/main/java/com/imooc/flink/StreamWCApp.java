package com.imooc.flink;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

import java.util.Arrays;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/27 22:45
 * @File: StreamWCApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 老版本keyBy的用法
 */
public class StreamWCApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        List<String> data = Arrays.asList("pk,pk,pk", "flink,flink");

        env.fromCollection(data)
                .flatMap((String line, Collector<String> col) -> {
                    Arrays.stream(line.split(",")).forEach(col::collect);
                })
                // 报错：The generic type parameters of 'Collector' are missing.
                // 的解决方案:
                // returs()
                .returns(Types.STRING)
                .map(x -> Tuple2.of(x, 1))
                .returns(Types.TUPLE(Types.STRING, Types.INT))
//                .keyBy(0)    // ①
//                .keyBy(x -> x.f0)     // ②
//                .keyBy(new KeySelector<Tuple2<String, Integer>, String>() {   // ③
//                    @Override
//                    public String getKey(Tuple2<String, Integer> value) throws Exception {
//                        return value.f0;
//                    }
//                })
                .keyBy(0)
                .sum(1)
                .print();

        env.execute();

    }
}