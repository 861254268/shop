package basic.com.imooc.flink

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/1 20:07
  * @File: ScalaBatchWCApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 基于Flink第一个批处理快速入门案例
  */
object ScalaBatchWCApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    val source = env.readTextFile("data/wc.txt")
    source.flatMap(_.split(","))
      .map((_, 1))
      .groupBy(0)
      .sum(1)
      .print()
  }
}