package basic.com.imooc

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/1 20:14
  * @File: ScalaStreamingWCApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 基于Flink第一个实时处理快速入门案例
  */
object ScalaStreamingWCApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val text = env.socketTextStream("localhost", 9999)
    text.flatMap(_.split(","))
      //.filter(_.nonEmpty)
      .filter(!_.equals("pk"))
      .map((_, 1))
      .keyBy(0)
      .timeWindow(Time.seconds(5))
      .sum(1)
      .print().setParallelism(1)

    env.execute()
  }

}
