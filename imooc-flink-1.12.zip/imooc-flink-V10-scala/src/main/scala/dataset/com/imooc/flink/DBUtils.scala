package dataset.com.imooc.flink

import scala.util.Random

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/7 23:14
  * @File: DBUtils.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 新建一个数据库工具类，用来连接数据库
  */
object DBUtils {
  def getConnection() = {
    //获取数据库连接
    new Random().nextInt(10)
  }

  def returnConnection(connection: String) = {
    //把数据存到数据库
  }
}