package dataset.com.imooc.flink

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.configuration.Configuration
// 导入隐式转换
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/7 19:53
  * @File: ScalaSourceApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
object ScalaSourceApp {

  case class MyCaseClass(name: String, age: Int)

  def main(args: Array[String]): Unit = {

    val env: ExecutionEnvironment = ExecutionEnvironment.getExecutionEnvironment
    // csvFile(env)
    // fromCollection(env)
    // readCompress(env) // 读压缩文件
    readRecursiveFiles(env) // 遍历子目录的数据
  }

  def readRecursiveFiles(env: ExecutionEnvironment): Unit = {
    val filePath = "data/nest"
    env.readTextFile(filePath).print()
    println("~~~华丽的分割线~~~")

    val parameters = new Configuration
    parameters.setBoolean("recursive.file.enumeration", true) // 递归的关键
    env.readTextFile(filePath).withParameters(parameters).print()
  }

  def readCompress(env: ExecutionEnvironment): Unit = {
    val source = env.readTextFile("data/wc.txt.gz")
    source.print()
  }

  def fromCollection(env: ExecutionEnvironment): Unit = {
    val data = 1 to 10
    env.fromCollection(data)
      .filter(_ >= 5)
      .print()
  }

  def csvFile(env: ExecutionEnvironment): Unit = {
    val filePath = "data/people.csv"
    // Tuple方式实现
    println("~~~Tuple方式~~~")
    env.readCsvFile[(String, Int)](filePath, fieldDelimiter = ";", ignoreFirstLine = true).print() // 读出两列
    env.readCsvFile[(Int, String)](filePath, fieldDelimiter = ";", ignoreFirstLine = true, includedFields = Array(1, 2)).print()

    // case class实现
    println("~~~case class方式~~~")
    env.readCsvFile[MyCaseClass](filePath, fieldDelimiter = ";", ignoreFirstLine = true, includedFields = Array(0, 1)).print()
    //POJO实现
    println("~~~pojo方式~~~")
    env.readCsvFile[Person](filePath, fieldDelimiter = ";", ignoreFirstLine = true, pojoFields = Array("name", "age", "work")).print()
    env.readCsvFile[Person](filePath, fieldDelimiter = ";", ignoreFirstLine = true, pojoFields = Array("name", "work")).print() // 对比结果

  }
}
