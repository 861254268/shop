package dataset.com.imooc.flink

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.api.scala._

import scala.collection.mutable.ListBuffer

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/7 22:58
  * @File: ScalaTransformationApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: transformation函数之map/mapPartition
  */
object ScalaTransformationApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    val students = new ListBuffer[String]
    for (i <- 1 to 100) {
      students.append("student " + i)
    }

    val data: DataSet[String] = env.fromCollection(students).setParallelism(4)
    // data.print()
    // map(data)
    mapPartitionFunction(data)
    // 现在的情况是: 使用map会请求100次，使用mapPartition 会请求4次，大大降低数据库的压力。
  }

  def mapPartitionFunction(data: DataSet[String]): Unit = {
    val resultMapPartition: DataSet[String] = data.mapPartition(x => {
      val connection = DBUtils.getConnection()
      println(connection + "......")
      x
    })
    resultMapPartition.print()
  }


  def map(data: DataSet[String]): Unit = {
    val resultMap: DataSet[Unit] = data.map(x => {
      //每一个元素要存储到数据库中,肯定要先获取到一个connection
      val connection = DBUtils.getConnection() + "......"
      println("conncetion: [ " + connection + " ]")
      // 把数据保存到DB
      DBUtils.returnConnection(connection)
      x
    })
    resultMap.print()
  }
}
