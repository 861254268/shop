package dataset.com.imooc.flink

import java.lang

import org.apache.flink.api.scala.{DataSet, ExecutionEnvironment}
import org.apache.flink.api.scala._
import org.apache.flink.core.fs.FileSystem.WriteMode
import org.apache.flink.util.NumberSequenceIterator

import scala.collection.mutable.ListBuffer

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/7 21:13
  * @File: ScalaSinkApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Sink,其实写入的到底是文件还是文件夹是与并行度有很大关系的
  */
object ScalaSinkApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    // val data = 1 to 10
    val data: ListBuffer[Int] = new ListBuffer[Int]
    for (i <- 1 to 10) {
      data.append(i)
    }

    writeToFile(env, data) // 写入文件
    writeToDir(env) // 写入文件夹

    // 此处的env.execute()需要特别注意
    env.execute()
  }

  def writeToDir(env: ExecutionEnvironment): Unit = {
    env.setParallelism(2)
    val source2: DataSet[lang.Long] = env.fromParallelCollection(new NumberSequenceIterator(1, 20))
    // 此时写入的out2是文件夹
    println("source2:" + source2.getParallelism)
    source2.writeAsText("out2", WriteMode.OVERWRITE)
  }

  def writeToFile(env: ExecutionEnvironment, data: ListBuffer[Int]): Unit = {
    val source: DataSet[Int] = env.fromCollection(data)
    println("source:" + source.getParallelism)  // 1
    // source.print()
    source.writeAsText("out1", WriteMode.OVERWRITE)
  }
}
