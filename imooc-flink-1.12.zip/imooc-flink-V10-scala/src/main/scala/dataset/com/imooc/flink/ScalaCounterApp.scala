package dataset.com.imooc.flink

import org.apache.flink.api.common.JobExecutionResult
import org.apache.flink.api.common.accumulators.LongCounter
import org.apache.flink.api.common.functions.RichMapFunction
import org.apache.flink.api.scala.{ExecutionEnvironment, _}
import org.apache.flink.configuration.Configuration
import org.apache.flink.core.fs.FileSystem.WriteMode

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/8 20:12
  * @File: ScalaCounterApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 基于flink编程的计数器之Scala实现
  *
  */
object ScalaCounterApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment

    val data = env.fromElements("hadoop", "spark", "storm", "flink", "pyspark")

    /**
      * 要实现一个ETL的功能：
      * 数据清洗：ip=>省份 、地市、运营商之类    一个字段拆分成多个字段
      *
      * 数据类型的转换：
      * 流量   关键的字段，必须是一个数值类型。
      * 但是有可能进来的是字符串类型，需要转换成数值类型的才可以。
      *
      **/

    val info: DataSet[String] = data.map(new RichMapFunction[String, String] {
      val counter = new LongCounter()

      override def open(parameters: Configuration): Unit = {
        getRuntimeContext.addAccumulator("ele-counts-scala", counter)
      }

      override def map(value: String): String = {
        /**
          * TODO... 数据清洗功能　&　计数功能
          *
          * 很有可能遇到不符合規則的數據
          **/
        counter.add(1)
        //                try {
        //
        //                } catch {
        //                    // 记录错误数据的计数器+1
        //                }

        value
      }
    })

    val filePath = "data/out"
    info.writeAsText(filePath, WriteMode.OVERWRITE).setParallelism(3)

    val result: JobExecutionResult = env.execute()
    // step:获取计数器
    // 此处的[Long]需要特别注意
    val num: Long = result.getAccumulatorResult[Long]("ele-counts-scala")
    println("num:" + num)
  }
}
