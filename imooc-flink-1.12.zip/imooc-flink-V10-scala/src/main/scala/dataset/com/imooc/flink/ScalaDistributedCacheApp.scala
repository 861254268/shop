package dataset.com.imooc.flink

import java.io.File
import java.nio.charset.Charset
import java.util

import org.apache.commons.io.FileUtils
import org.apache.flink.api.common.functions.RichMapFunction
import org.apache.flink.api.scala.{DataSet, ExecutionEnvironment, _}
import org.apache.flink.configuration.Configuration

import scala.collection.JavaConverters._


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/8 19:51
  * @File: ScalaDistributedCacheApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 基于flink的分布式缓存(DistributedCache)功能的Scala实现
  *
  */
object ScalaDistributedCacheApp {
  def main(args: Array[String]): Unit = {
    val env: ExecutionEnvironment = ExecutionEnvironment.getExecutionEnvironment

    // 把对应的数据注册到分布式缓存中
    val filePath = "data/wc.txt"
    env.registerCachedFile(filePath, "sc-pk-dc")
    val data: DataSet[String] = env.fromElements("hadoop", "spark", "storm", "flink", "pyspark")
    data.flatMap(_.split(","))
      .map(new RichMapFunction[String, String] {

        private val list: util.ArrayList[String] = new util.ArrayList[String]()
        // var list: List[(String)] = _

        override def open(parameters: Configuration): Unit = {
          val file: File = getRuntimeContext.getDistributedCache.getFile("sc-pk-dc")
          val lines = FileUtils.readLines(file, Charset.defaultCharset()) // java实现
          for (line <- lines.asScala) {
            list.add(line)
            println("line = [" + line + "]")
          }
        }

        override def map(value: String): String = {
          value
        }
      }).print()
  }
}
