package dataset.com.imooc.flink

import org.apache.flink.api.common.functions.RichMapFunction
import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.configuration.Configuration
import scala.io.Source
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/8 19:55
  * @File: ScalaFlinkCacheApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
object ScalaFlinkCacheApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(3)
    // 注册缓存的文件,里面有数据hello jason
    env.registerCachedFile("data/wc2.txt", "testfile")
    val stream = env.fromElements("flink", "pk", "hello", "jim", "flink", "pk")
    val result = stream
      .flatMap(_.split(","))
      .map(new RichMapFunction[String, String] {
        var list: List[(String)] = _

        override def open(parameters: Configuration): Unit = {
          super.open(parameters)
          // 获取缓存的数据
          val file = getRuntimeContext.getDistributedCache.getFile("testfile")
          val lines = Source.fromFile(file.getAbsoluteFile).getLines()
          list = lines.toList
        }

        override def map(value: String): String = {
          var middle: String = ""
          if (list(0).contains(value)) {
            middle = value
          }
          middle
        }
      })
      .map((_, 1L))
      .filter(_._1.nonEmpty)
      .groupBy(0)
      .sum(1)
    result.print()
  }
}
