package datastream.com.imooc.flink.basic.window

import java.lang
import java.lang.Math.max

import org.apache.flink.api.common.functions.{MapFunction, ReduceFunction, RichReduceFunction}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/2 22:57
  * @File: ScalaWindowApp2.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: WindowFunction之ReduceFunction/ProcessWindowFunction实战
  */
object ScalaWindowApp2 {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    // test01(env) // reduceFunction
    test02(env) // ProcessWindowFunction
    // test03(env); // AggregateFunction 可以自己实现。。。

    env.execute()
  }

  def test02(env: StreamExecutionEnvironment): Unit = {
    env.socketTextStream("localhost", 9999)
      .map(new MapFunction[String, (String, Int)] {
        override def map(value: String): (String, Int) = {
          val splits = value.split(",")
          (splits(0).trim, splits(1).trim.toInt)
        }
      })
      .keyBy(_._1)
      .window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
      //.process(new PKProcessWindowFunction())
      //.process(new ScProcessWindowFunction)

//    class ScProcessWindowFunction extends ProcessWindowFunction[(String, Integer), String, String, TimeWindow] {
//      override def process(key: String, context: ProcessWindowFunction[(String, Integer), String, String, TimeWindow]#Context, elements: lang.Iterable[(String, Integer)], out: Collector[String]): Unit = {
//        println("----process invoked ...----") // 输出一次为全量，多次为增量
//
//        var maxValue = Integer.MIN_VALUE
//        import scala.collection.JavaConversions._
//        for (element <- elements) {
//          maxValue = max(element._2, maxValue)
//        }
//
//        println(context.window.getStart)
//        println(context.window.getEnd)
//        out.collect("当前窗口的最大值是：" + maxValue)
//      }
//    }

  }



  def test01(env: StreamExecutionEnvironment): Unit = {
    // HADOOP,1 spark,1
    env.socketTextStream("localhost", 9999)
      .map(new MapFunction[String, (String, Int)] {
        override def map(value: String): (String, Int) = {
          val splits = value.split(",")
          (splits(0).trim, splits(1).trim.toInt)
        }
      })
      .keyBy(_._1)
      .window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
      .reduce((x, y) => (x._1, x._2 + y._2))
      .print()
  }

}

