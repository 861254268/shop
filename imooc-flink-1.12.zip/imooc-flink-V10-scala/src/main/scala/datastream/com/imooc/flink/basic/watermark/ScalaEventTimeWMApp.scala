package datastream.com.imooc.flink.basic.watermark

import org.apache.commons.lang.time.FastDateFormat
import org.apache.flink.api.common.functions.{MapFunction, ReduceFunction}
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.{DataStream, OutputTag, StreamExecutionEnvironment}
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.scala.function.ProcessWindowFunction
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/3 19:52
  * @File: ScalaEventTimeWMApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
object ScalaEventTimeWMApp {
  /**
    * <p>
    * 1) 基于EventTime和WaterMark结合滚动窗口综合案例之没有延迟
    * <p>
    * 2) 基于EventTime和WaterMark结合滚动窗口综合案例之有延迟
    * <p>
    * 3) 基于EventTime和WaterMark结合滚动窗口综合案例之延迟数据丢失
    * <p>
    * 4) 基于EventTime和WaterMark结合滚动窗口综合案例之捕获到延迟数据
    * 输入数据的格式：时间字段，单词，次数
    **/

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    // flink1.0 及以前需要指定时间类型，这个需要特别注意

    // test01(env) // sum:基于EventTime和WaterMark结合滚动窗口综合案例之没有延迟
    // test02(env) // reduce:基于EventTime和WaterMark结合滚动窗口综合案例之有延迟
    // test03(env) // reduce:基于EventTime和WaterMark结合滚动窗口综合案例之延迟数据丢失
    test04(env) // reduce:基于EventTime和WaterMark结合滚动窗口综合案例之捕获到延迟数据
    env.execute()
  }

  def test04(env: StreamExecutionEnvironment): Unit = {
    /**
      * 分配WaterMark的两种方式：
      * 1) 接入数据的时候创建(推荐使用);
      * 2) 处理的时候创建。
      *
      * WM其实就是延迟触发的一种机制：
      * WM=数据所携带的时间(窗口中最大的时间)-延迟执行的时间
      * WM >= 上一个窗口的执行边界 就会触发窗口的执行
      * eg: 6999 - 2000 = 4999 >= 上一个窗口的边界
      **/
    val outputTag: OutputTag[(String, Int)] = new OutputTag[Tuple2[String, Int]]("late_data") {

    }

    val lines = env.socketTextStream("localhost", 9999)
      .assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[String](Time.seconds(0)) {
        override def extractTimestamp(element: String): Long = {
          element.split(",")(0).toLong
        }
      })
    val windowStream: DataStream[String] = lines.map(x => (x.split(",")(1).trim, x.split(",")(2).trim.toInt))
      // [1000,5000) [5000,10000)
      .keyBy(_._1)
      .window(TumblingEventTimeWindows.of(Time.seconds(5)))
      // 基于EventTime和WaterMark结合滚动窗口综合案例之捕获到延迟数据
      .sideOutputLateData(outputTag)
      .reduce(
        new ReduceFunction[(String, Int)] { // 第一个参数：增量
          override def reduce(value1: (String, Int), value2: (String, Int)): (String, Int) = {
            println("---reduce involed---" + value1._1 + "==>" + (value1._2 + value2._2))
            Tuple2.apply(value1._1, value1._2 + value2._2)
          }
        }

        , new ProcessWindowFunction[Tuple2[String, Int], String, String, TimeWindow] { // 第二个参数：全量
          // 时间格式化
          val format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")

          override def process(key: String, context: Context, elements: Iterable[(String, Int)], out: Collector[String]): Unit = {
            for (element <- elements) {
              println(format.format(context.currentWatermark)) // 当前时间
              out.collect("[" + format.format(context.window.getStart) + "==>"
                + format.format(context.window.getEnd) + "]" + element._1 + "==>" + element._2)
            }
          }
        })
    windowStream.print() // 主流的数据
    val sideOutput: DataStream[(String, Int)] = windowStream.getSideOutput(outputTag)
    sideOutput.print("sideOutput:") // 侧流的数据：将延迟的数据标记为红色，便于观察


  }

  def test03(env: StreamExecutionEnvironment): Unit = {
    /**
      * 分配WaterMark的两种方式：
      * 1) 接入数据的时候创建(推荐使用);
      * 2) 处理的时候创建。
      *
      * WM其实就是延迟触发的一种机制：
      * WM=数据所携带的时间(窗口中最大的时间)-延迟执行的时间
      * WM >= 上一个窗口的执行边界 就会触发窗口的执行
      * eg: 6999 - 2000 = 4999 >= 上一个窗口的边界
      **/

    val lines = env.socketTextStream("localhost", 9999)
      .assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[String](Time.seconds(0)) {
        override def extractTimestamp(element: String): Long = {
          element.split(",")(0).toLong
        }
      })
    val resultStream: DataStream[String] = lines.map(x => (x.split(",")(1).trim, x.split(",")(2).trim.toInt))
      .keyBy(_._1)
      .window(TumblingEventTimeWindows.of(Time.seconds(5)))
      .reduce(
        new ReduceFunction[(String, Int)] { // 第一个参数
          override def reduce(value1: (String, Int), value2: (String, Int)): (String, Int) = {
            println("---reduce involed---" + value1._1 + "==>" + (value1._2 + value2._2))
            Tuple2.apply(value1._1, value1._2 + value2._2)
          }
        }
        , new ProcessWindowFunction[Tuple2[String, Int], String, String, TimeWindow] { // 第二个参数
          // 时间格式化
          val format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")

          override def process(key: String, context: Context, elements: Iterable[(String, Int)], out: Collector[String]): Unit = {
            for (element <- elements) {
              println(format.format(context.currentWatermark)) // 当前时间
              out.collect("[" + format.format(context.window.getStart) + "==>"
                + format.format(context.window.getEnd) + "]" + element._1 + "==>" + element._2)
            }
          }
        }

      )
    resultStream.print()

  }

  def test02(env: StreamExecutionEnvironment): Unit = {
    /**
      * 分配WaterMark的两种方式：
      * 1) 接入数据的时候创建(推荐使用);
      * 2) 处理的时候创建。
      *
      * WM其实就是延迟触发的一种机制：
      * WM=数据所携带的时间(窗口中最大的时间)-延迟执行的时间
      * WM >= 上一个窗口的执行边界 就会触发窗口的执行
      * eg: 6999 - 2000 = 4999 >= 上一个窗口的边界
      **/
    val lines: DataStream[String] = env.socketTextStream("localhost", 9999)
      .assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[String](Time.seconds(2)) { // Time.seconds(2): 允许延迟2s

        override def extractTimestamp(element: String): Long = {
          element.split(",")(0).toLong
        }
      })
    val resultStream: DataStream[String] = lines.map(x => (x.split(",")(1).trim, x.split(",")(2).trim.toInt))
      .keyBy(_._1)
      .window(TumblingEventTimeWindows.of(Time.seconds(5)))
      // 此处处理机制不同
      .reduce(
      new ReduceFunction[Tuple2[String, Int]] { // 第一个参数
        override def reduce(value1: (String, Int), value2: (String, Int)): (String, Int) = {
          println("---reduce involed---" + value1._1 + "==>" + (value1._2 + value2._2))
          Tuple2.apply(value1._1, value1._2 + value2._2)
        }
      }
      , new ProcessWindowFunction[Tuple2[String, Int], String, String, TimeWindow]() { // 第二个参数
        // 时间格式化
        val format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")

        override def process(key: String, context: Context, elements: Iterable[(String, Int)], out: Collector[String]): Unit = {
          for (element <- elements) {
            println(format.format(context.currentWatermark)) // 当前时间
            out.collect("[" + format.format(context.window.getStart) + "==>"
              + format.format(context.window.getEnd) + "]" + element._1 + "==>" + element._2)
          }

        }
      })
    resultStream.print()
  }

  def test01(env: StreamExecutionEnvironment): Unit = {
    /**
      * 分配WaterMark的两种方式：
      * 1) 接入数据的时候创建(推荐使用);
      * 2) 处理的时候创建。
      **/
    val lines: DataStream[String] = env.socketTextStream("localhost", 9999)
      .assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[String](Time.seconds(0)) { //// Time.seconds(0): 不允许延迟的

        override def extractTimestamp(element: String): Long = {
          element.split(",")(0).toLong
        }
      })
    lines.map(x => (x.split(",")(1).trim, x.split(",")(2).trim.toInt))
      //      .map(new MapFunction[String, Tuple2[String, Int]] {
      //      override def map(value: String): (String, Int) = {
      //        val splits = value.split(",")
      //        Tuple2.apply(splits(1).trim, splits(2).trim.toInt)
      //      }
      //    })
      .keyBy(_._1)
      .window(TumblingEventTimeWindows.of(Time.seconds(5)))
      .sum(1)
      .print()
  }
}