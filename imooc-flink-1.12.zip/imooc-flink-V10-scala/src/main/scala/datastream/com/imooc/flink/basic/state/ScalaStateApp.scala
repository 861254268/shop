package datastream.com.imooc.flink.basic.state
import java.util
import java.util.{ArrayList, UUID}

import org.apache.flink.api.common.functions.RichFlatMapFunction
import org.apache.flink.api.common.state.{MapState, MapStateDescriptor, ValueState, ValueStateDescriptor}
import org.apache.flink.api.common.typeinfo.TypeInformation
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}

import scala.collection.mutable.ArrayBuffer
import org.apache.flink.api.scala._
import org.apache.flink.api.scala.typeutils.Types
import org.apache.flink.configuration.Configuration
import org.apache.flink.shaded.guava18.com.google.common.collect.Lists
import org.apache.flink.util.Collector
/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/4 22:51
  * @File: ScalaStateApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 使用 ValueState/MapState 完成求平均数功能
  */
object ScalaStateApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // mapStateAvg(env) //使用 MapState实现平均数
    valueStateAvg(env) //使用 ValueState实现平均数
    env.execute()
  }

  // 使用 ValueState实现平均数
  def valueStateAvg(env: StreamExecutionEnvironment): Unit = {
    val list: DataStream[(Long, Long)] = env.fromCollection(List(
      (1L, 3L),
      (1L, 7L),
      (2L, 4L),
      (1L, 5L),
      (2L, 2L),
      (2L, 5L)
    ))
    list.keyBy(_._1)
      .flatMap(new AvgWithValueState)
      .print()
  }


  class AvgWithValueState extends RichFlatMapFunction[(Long, Long), (Long, Double)] {
    // 求平均数：记录条数  总和
    private var sum: ValueState[(Long, Long)] = _

    override def open(parameters: Configuration): Unit = {
      // scala实现
      val descriptor: ValueStateDescriptor[(Long, Long)] = new ValueStateDescriptor[(Long, Long)]("avg", TypeInformation.of(classOf[(Long, Long)]))
      sum = getRuntimeContext.getState(descriptor) // 描述器
    }


    override def flatMap(value: (Long, Long), out: Collector[(Long, Double)]): Unit = {
      // TODO...  ==> state  次数 和 总和
      var currentState: (Long, Long) = sum.value()
      // var newState: (Long, Long) = (0L, 0L)
      if (null == currentState) {
        currentState = (0L, 0L)
      }

      // println(currentState._1.getClass.getSimpleName)
      var newState: (Long, Long) = (currentState._1 + 1L, currentState._2 + value._2)

      sum.update(newState)

      // 到达3条数据 ==> 求平均数 clear
      if (newState._1 >= 3) {
        out.collect((value._1, newState._2 / newState._1.toDouble))
        sum.clear()
      }
    }
  }

  // 使用 MapState实现平均数
  def mapStateAvg(env: StreamExecutionEnvironment): Unit = {
    val list = new ArrayBuffer[(Long, Long)]()
    list.append((1L, 3L))
    list.append((1L, 7L))
    list.append((2L, 4L))
    list.append((1L, 5L))
    list.append((2L, 2L))
    list.append((2L, 5L))

    env.fromCollection(list)
      .keyBy(_._1)
      //.sum(1)
      .flatMap(new AvgWithMapState) // MapState
      .print()

  }

  class AvgWithMapState extends RichFlatMapFunction[(Long, Long), (Long, Double)] {
    private var mapState: MapState[String, Long] = _

    override def open(parameters: Configuration): Unit = {
      //      val descriptor: MapStateDescriptor[String, Long] = new MapStateDescriptor[String, Long]("avg",
      //        TypeInformation.of(classOf[(String, Long)]))
      //      val descriptor: MapStateDescriptor[String, Long] = new MapStateDescriptor[String, Long]("avg",
      //        (String, Long))
      // java实现
      val descriptor: MapStateDescriptor[String, Long] = new MapStateDescriptor[String, Long]("avg", classOf[String], classOf[Long])
      mapState = getRuntimeContext.getMapState(descriptor)
    }

    override def flatMap(value: (Long, Long), out: Collector[(Long, Double)]): Unit = {
      mapState.put(UUID.randomUUID().toString, value._2)
      //val elements: util.ArrayList[Long] = Lists.newArrayList(mapState.values())    // java：.values()
      val elements: util.ArrayList[Long] = Lists.newArrayList(mapState.values) // scala：.values
      if (elements.size() == 3) {
        var count = 0L
        var sum = 0L


        /**
          * for (element <- elements) { //scala的语法
          * 此时会出先一个异常：java集合和scala集合不兼容的问题
          * 解决方法：导包，转换
          *
          * 这个很重要：
          * import scala.collection.JavaConverters._
          *
          * for (ele <- lines.asScala) { //scala的语法
          * println(ele)
          * }
          *
          * import scala.collection.JavaConversions._ 与区别：
          *
          * for (ele <- lines) { //scala的语法
          * println(ele)
          * }
          **/
        import scala.collection.JavaConverters._
        for (element <- elements.asScala) {
          count += 1
          sum += element
        }
        val avg = sum / count.doubleValue()
        out.collect(Tuple2.apply(value._1, avg))
        mapState.clear()
      }
    }
  }

}