package datastream.com.imooc.flink.basic.source

import org.apache.flink.streaming.api.functions.source.SourceFunction

import scala.util.Random

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/1 20:27
  * @File: ScalaAccessSource.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
class ScalaAccessSource extends SourceFunction[Access] {
  var running = true

  override def run(ctx: SourceFunction.SourceContext[Access]): Unit = {
    val domains = List("a.com", "b.com", "imooc.com")
    val random = new Random

    while (running) {
      for (i <- 1 to 10) {
        val access = new Access()
        access.setTime(1234567L)
        access.setDomain(domains(random.nextInt(domains.length)))
        access.setTraffic(random.nextDouble() + 100)
        ctx.collect(access)

      }

      Thread.sleep(5000)
    }
  }

  override def cancel(): Unit = {
    running = false
  }
}
