package datastream.com.imooc.flink.basic.window

import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows
import org.apache.flink.streaming.api.windowing.time.Time


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/2 21:38
  * @File: ScalaWindowApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 基于ProcessingTime的Non-Keyed/keyed滚动窗口实战
  */
object ScalaWindowApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // noKey(env) // 不带key的
    keyed(env) // 带keyed的
    env.execute()
  }

  def keyed(env: StreamExecutionEnvironment): Unit = {
    // HADOOP,1 spark,1
    env.socketTextStream("localhost", 9999)
      .map(new MapFunction[String, Tuple2[String, Int]] {
        override def map(value: String): (String, Int) = {
          val splits = value.split(",")
          (splits(0).trim, splits(1).trim.toInt)
        }
      })
      .keyBy(_._1)
      .window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
      .sum(1)
      .print()
  }

  def noKey(env: StreamExecutionEnvironment): Unit = {
    // env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime)
    // flink1.10 默认是ProcessingTime
    env.socketTextStream("localhost", 9999)
      .map(_.toInt)
      .timeWindowAll(Time.seconds(5))
      .sum(0)
      .print()

  }


}
