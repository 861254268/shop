package datastream.com.imooc.flink.basic.partitioner

import datastream.com.imooc.flink.basic.source.{Access, ScalaAccessSourceV2}
import org.apache.flink.api.common.functions.{MapFunction, Partitioner}
import org.apache.flink.api.java.functions.KeySelector
import org.apache.flink.api.java.tuple
import org.apache.flink.streaming.api.datastream.DataStreamSource
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/2 19:39
  * @File: ScalaPartitionerApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: partitioner分区
  */
object ScalaPartitionerApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(3)
    val source: DataStreamSource[Access] = env.addSource(new ScalaAccessSourceV2)
    println(source.getParallelism)
    val mapStream = source.map(new MapFunction[Access, tuple.Tuple2[String, Access]] {
      // 此处的Tuple2导包需要注意：应该导入java的
      // tuple.Tuple2[String, Access]
      override def map(value: Access): tuple.Tuple2[String, Access] = {
        tuple.Tuple2.of(value.getDomain, value)
        // 等价于 java 的return Tuple2.of(value.getDomain(), value);

      }
    })


    // mapStream.print()
    // 自定义分区器
    class ScalaPKPartitioner extends Partitioner[String] {
      override def partition(key: String, numPartitions: Int): Int = {
        println("numPartitions: " + numPartitions)
        if ("imooc.com".equals(key)) {
          0
        } else if ("a.com".equals(key)) {
          1
        } else {
          2
        }
      }
    }

    // 新版本使用
    mapStream.partitionCustom(new ScalaPKPartitioner, new KeySelector[tuple.Tuple2[String, Access], String] {
      override def getKey(value: tuple.Tuple2[String, Access]): String = {
        println("current thread id is: " + Thread.currentThread().getId() + ",value is: " + value.f1)
        value.f1.toString
      }
    }).print()

    // 老版本使用
    //    mapStream.partitionCustom(new ScalaPKPartitioner, 0)
    //      .map(new MapFunction[tuple.Tuple2[String, Access], Access] {
    //        override def map(value: tuple.Tuple2[String, Access]): Access = {
    //          println("current thread id is: " + Thread.currentThread().getId() + ",value is: " + value.f1)
    //          value.f1
    //        }
    //      })
    // .print()


    env.execute()
  }

}
