package datastream.com.imooc.flink.basic.transformation

import datastream.com.imooc.flink.basic.{source, transformation}
import datastream.com.imooc.flink.basic.source.{Access, AccessSource}
import org.apache.flink.streaming.api.scala.{ConnectedStreams, DataStream, StreamExecutionEnvironment}
import org.apache.flink.api.scala._
import org.apache.flink.api.common.functions.{FlatMapFunction, GroupReduceFunction, MapFunction, ReduceFunction, RichGroupReduceFunction, RichReduceFunction}
import org.apache.flink.configuration.Configuration
import org.apache.flink.streaming.api.functions.co.{CoFlatMapFunction, CoMapFunction}
import org.apache.flink.util.Collector

import scala.collection.mutable.ListBuffer

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/1 20:44
  * @File: ScalaTransformationApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Transformation算子之map/richMap
  */
object ScalaTransformationApp {

  // case class Access(domain: String, time: Long, traffic: Double)

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // map(env)   // map
    // mapFilter(env)  // mapFilter
    // mapKeyBy(env) // mapKeyBy
    // reduce(env)   // reduce
    // union(env)   // union
    connect(env) //connect
    // coMap(env)  // CoMapFunction
    // coFlatMap(env) // coFlatMap
    env.execute()
  }


  def coFlatMap(env: StreamExecutionEnvironment): Unit = {
    val stream1 = env.fromElements("a b c", "d e f")
    val stream2 = env.fromElements("1,2,3", "4,5,6")

    val connected = stream1.connect(stream2)

    class CoFlatMap extends CoFlatMapFunction[String, String, String] {
      override def flatMap1(in1: String, out: Collector[String]): Unit = {
        val splits = in1.split(" ")
        for (split <- splits) { // foreach
          out.collect(split.toUpperCase)
        }
      }

      override def flatMap2(in2: String, out: Collector[String]): Unit = {
        val splits = in2.split(",")
        for (split <- splits) {
          out.collect(split.toInt * 10 + 1 + "")
        }
      }

    }
    connected.flatMap(new CoFlatMap).print()
  }

  def coMap(env: StreamExecutionEnvironment): Unit = {
    val stream1 = env.socketTextStream("localhost", 9999)
    val stream2 = env.socketTextStream("localhost", 8888) // 数值类型
      .map(_.toInt)

    val connected = stream1.connect(stream2)
    class MyCoMap extends CoMapFunction[String, Int, String] {
      override def map1(in1: String): String = {
        in1.toUpperCase()
      }

      override def map2(in2: Int): String = {
        in2 * 10 + ""
      }
    }

    val result = connected.map(new MyCoMap)
    result.print()

  }


  /**
    * union 多流合并    数据结构必须相同
    * connect 双流        数据结构可以不同，更加灵活
    **/
  def connect(env: StreamExecutionEnvironment): Unit = {

    val stream1: DataStream[Access] = env.addSource(new AccessSource)
    val stream2: DataStream[(String, Access)] = env.addSource(new AccessSource).map(("pk", _))
    val connected: ConnectedStreams[Access, (String, Access)] = stream1.connect(stream2)

    class MyCoMapFunction extends CoMapFunction[Access, (String, Access), String] {
      override def map1(in1: Access): String = {
        in1.toString
      }

      override def map2(in2: (String, Access)): String = {
        in2._1 + "==>" + in2._2
      }
    }

    connected.map(new MyCoMapFunction).print()
  }

  def union(env: StreamExecutionEnvironment): Unit = {
    val text1 = env.socketTextStream("localhost", 9999)
    val text2 = env.socketTextStream("localhost", 8888)
    val union = text1.union(text2)
    union.print()
  }


  def reduce(env: StreamExecutionEnvironment): Unit = {
    val text = env.socketTextStream("localhost", 9999)
    text.flatMap(_.split(","))
      .map((_, 1))
      .keyBy(_._1)
      // .reduce((x, y) => (x._1, x._2 + y._2)) // ①reduce算子
      .reduce(new RichReduceFunction[(String, Int)] { //②自定义reduce function
      override def open(parameters: Configuration): Unit = super.open(parameters)

      override def reduce(value1: (String, Int), value2: (String, Int)): (String, Int) = {
        (value1._1, value1._2 + value2._2)
      }
    })
      .print()


  }

  def mapKeyBy(env: StreamExecutionEnvironment): Unit = {
    val source = env.readTextFile("data/access.log")
    val mapSource: DataStream[(Long, String, Int)] = source.map(x => (x.split(",")(0).toLong, x.split(",")(1).trim, x.split(",")(2).toInt))
    mapSource.keyBy(_._2).sum(2).print()
  }

  def mapFilter(env: StreamExecutionEnvironment): Unit = {
    val students = new ListBuffer[Int]
    for (i <- 1 to 10) {
      students.append(i)
    }
    // 加载数据源
    val data = env.fromCollection(students)
      .map((_ * 2 + 1))
      .filter(_ >= 6)
      .print()
      .setParallelism(6)
  }

  def map(env: StreamExecutionEnvironment): Unit = {
    val source = env.readTextFile("data/access.log")
    val mapSource = source.map(x => (x.split(",")(0).toLong, x.split(",")(1).trim, x.split(",")(2).toInt))
    mapSource.print()
  }

}


