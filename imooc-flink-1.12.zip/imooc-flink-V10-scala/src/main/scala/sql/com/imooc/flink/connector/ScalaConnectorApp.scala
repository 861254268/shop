package sql.com.imooc.flink.connector

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.table.descriptors.FileSystem

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/6 20:17
  * @File: ScalaConnectorApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: SQL FileSystem Connector读取数据/写出数据
  */
object ScalaConnectorApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val tEnv: StreamTableEnvironment = StreamTableEnvironment.create(env)
    // 此处后期继续钻研
    // tEnv.connect(new FileSystem.path)

    env.execute()

  }

}
