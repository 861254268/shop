package sql.com.imooc.flink.window

import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.table.api.{Table, Tumble}
import org.apache.flink.types.Row


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/6 20:00
  * @File: ScalaWindowApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Flink Table API结合Window及EventTime编程
  */
object ScalaWindowApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val tEnv: StreamTableEnvironment = StreamTableEnvironment.create(env)

    /**
      * 窗口大小10s,wm允许是0
      *
      * 0000-9999  pk:205    zs:6
      * 10000-19999  pk:45
      **/

    val input: DataStream[(Long, String, String, Double)] = env.fromElements( // 时间(eventtime),用户名,购买商品,价格
      "1000,pk,spark,75",
      "2000,pk,flink,65",
      "2000,zs,kuangquanshui,3",
      "3000,pk,cdh,65",
      "9999,zs,xuebi,3",
      "19999,pk,hive,45"
    ).map(new MapFunction[String, (Long, String, String, Double)] {
      override def map(value: String): (Long, String, String, Double) = {
        val splits: Array[String] = value.split(",")
        val time = splits(0).toLong
        val user = splits(1)
        val book = splits(2)
        val money = splits(3).toDouble
        (time, user, book, money)
      }
    })
      .assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[(Long, String, String, Double)](Time.seconds(0)) {
        override def extractTimestamp(element: (Long, String, String, Double)): Long = {
          element._1
        }
      })
    // input.print()

    // apiWindowEventTime(tEnv, input) // api【该方法的使用是有问题的】
    sqlWindowEventTime(tEnv, input) // sql

    env.execute()
  }

  // sql
  def sqlWindowEventTime(tEnv: StreamTableEnvironment, input: DataStream[(Long, String, String, Double)]): Unit = {
    val table: Table = tEnv.fromDataStream(input)
    tEnv.createTemporaryView("access", table)
    val resultTable: Table = tEnv.sqlQuery("select user,sum(money) as total from access group by user")
    // tEnv.toAppendStream(resultTable).print()
    tEnv.toRetractStream[Row](resultTable).print()
    //tEnv.toRetractStream(resultTable, Row.class).filter(x -> x.f0).print()
  }

  // api
  def apiWindowEventTime(tEnv: StreamTableEnvironment, input: DataStream[(Long, String, String, Double)]): Unit = {
    tEnv.createTemporaryView("access", input)
    val tableData: Table = tEnv.from("access")
    val resultTable: Table = tableData
      // .window(Tumble.over(lit(10).seconds()).on($("rowtime")).as("win"))  // 新版本
      .filter("user!='abc'")
      .groupBy("user")
      .aggregate("sum(money) as total") //　聚合
      .select("user,total")

    tEnv.toRetractStream[Row](resultTable).print()
  }
}