package sql.com.imooc.flink.basic

import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.table.api.Table
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/6 19:56
  * @File: ScalaDataStreamTableAQLApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Flink SQL整合DataStream编程
  */
object ScalaDataStreamTableAQLApp {

  case class Access(time: Long, domain: String, traffic: Double) {
  }

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val tEnv = StreamTableEnvironment.create(env)

    val source = env.readTextFile("data/access.log")
    val stream: DataStream[Access] = source.map(new MapFunction[String, Access] {
      override def map(value: String): Access = {
        val splits = value.split(",")
        val time = splits(0).trim.toLong
        val domain = splits(1).trim
        val traffic = splits(2).trim.toDouble
        new Access(time, domain, traffic)
      }
    })

    // sqlRowOrAccess(tEnv, stream) //sqlRowOrAccess
    // tableAPI(tEnv, stream) //tableAPI
    sql_toRetractStream(tEnv, stream) //sql_toRetractStream
    env.execute()
  }

  def sql_toRetractStream(tEnv: StreamTableEnvironment, stream: DataStream[Access]): Unit = {
    val table: Table = tEnv.fromDataStream(stream)
    tEnv.createTemporaryView("access", table)
    val resultTable: Table = tEnv.sqlQuery("select domain,sum(traffic) as traffics from access group by domain")
    // tEnv.toAppendStream[Row](resultTable).print("Row:")  //
    // 报错：Table is not an append-only table. Use the toRetractStream() in order to handle add and retract messages.
    /**
      * toRetractStream
      * 第一个字段boolean类型表示
      * true: 最新的数据
      * false: 过期的数据
      **/
    tEnv.toRetractStream[Row](resultTable)
      .filter(_._1) // 过滤留下true的数据
      .print("Row:")
  }

  def tableAPI(tEnv: StreamTableEnvironment, stream: DataStream[Access]): Unit = {
    val table: Table = tEnv.fromDataStream(stream)
    val resultTable: Table = table.select("domain,traffic")
      .where("domain='imooc.com'")
    tEnv.toAppendStream[Row](resultTable).print()
  }

  def sqlRowOrAccess(tEnv: StreamTableEnvironment, stream: DataStream[Access]): Unit = {

    // stream.print()
    // DataStream ==> Table
    val table: Table = tEnv.fromDataStream(stream)
    tEnv.createTemporaryView("access", table)
    val resultTable: Table = tEnv.sqlQuery("select * from access where domain='imooc.com'")
    // Table ==> DataStream
    //对比Row与Access的输出：
    val RowDataStream: DataStream[Row] = tEnv.toAppendStream[Row](resultTable)
    RowDataStream.print("Row:")
    val AccessDataStream: DataStream[Access] = tEnv.toAppendStream[Access](resultTable)
    AccessDataStream.print("Access:")
  }
}
