//package mysql.com.imooc.flink.basic.sink6_mysql
//
//import java.sql.{DriverManager, PreparedStatement}
//
//import mysql.com.imooc.flink.basic.source6_mysql.Student
//import org.apache.flink.configuration.Configuration
//import org.apache.flink.streaming.api.functions.sink.{RichSinkFunction, SinkFunction}
//
///**
//  * -*- coding: utf-8 -*-
//  *
//  * @Author: Mr.Jia
//  * @Create Time: 2021/9/6 22:33
//  * @File: MySQLSink.scala/java
//  * @Software: IntelliJ IDEA 2018.2.4
//  * @descirption:
//  */
//class MySQLSink extends RichSinkFunction[Student] {
//  private var conn = _
//  private val insertStmt: PreparedStatement = _
//  private val updateStmt: PreparedStatement = _
//
//  override def open(parameters: Configuration): Unit = {
//    super.open(parameters)
//    Class.forName("com.mysql.jdbc.Driver") // 加载数据库驱动
//    conn = DriverManager.getConnection( // 获取连接
//      "jdbc:mysql://localhost:3306/demodb?serverTimezone=GMT%2B8&useSSL=false", // 数据库URL
//      "root", // 用户名
//      "123456"); // 登录密码
//
////    insertStmt = conn.prepareStatement( // 获取执行语句
////      "insert into t_student(id,name,age) values (?,?,?)") // 插入数据
////    updateStmt = conn.prepareStatement( // 获取执行语句
////      "update t_student set name=?,age=? where id=?") // 更新数据
//  }
//
//  override def invoke(value: Student, context: SinkFunction.Context[_]): Unit = {
//    // 每条数据到来后，直接执行更新语句
//    updateStmt.setString(1, value.getName()) // 与占位符(?)对应的参数
//    updateStmt.setInt(2, value.getAge())
//    updateStmt.setInt(3, value.getId())
//    updateStmt.execute(); // 执行更新语句
//
//    // 如果更新数为0，则执行插入语句
//    if (updateStmt.getUpdateCount() == 0) {
//      insertStmt.setInt(1, value.getId())
//      insertStmt.setString(2, value.getName())
//      insertStmt.setInt(3, value.getAge())
//      insertStmt.execute(); // 执行插入语句
//    }
//  }
//
//  override def close(): Unit = {
//    if (conn != null) conn.close()
//    if (insertStmt != null) insertStmt.close()
//    if (updateStmt != null) updateStmt.close()
//  }
//}
