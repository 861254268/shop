package mysql.com.imooc.flink.basic.sink6_mysql

import com.imooc.flink.Sink6_MySQL.MySQLSink
import org.apache.flink.api.scala._
import mysql.com.imooc.flink.basic.source6_mysql.Student
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/6 22:25
  * @File: ScalaMySQLSinkFunction.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 继承 RichSinkFunction
  */
object ScalaMySQLSinkFunction {
  def main(args: Array[String]): Unit = {

    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val dataInput = env.fromCollection(List(
      new Student(100, "Nancy", 22),
      new Student(101, "Mary", 53),
      new Student(102, "Scala", 32)
    ))
    dataInput.print()
    //      .addSink(new MySQLSink)
    env.execute()
    println("MySQL写入成功！")
  }
}
