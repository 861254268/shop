package mysql.com.imooc.flink.basic.source6_mysql

import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.api.common.typeinfo.BasicTypeInfo
import org.apache.flink.api.java.io.jdbc.JDBCInputFormat
import org.apache.flink.api.java.typeutils.RowTypeInfo
import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/4 22:54
  * @File: ScalaSourceMySQLApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 直接使用 JDBCInputFormat
  */
object ScalaSourceMySQLApp {

  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    // ToDo 1.source
    val dataInput: DataSet[Row] = env.createInput(JDBCInputFormat.buildJDBCInputFormat()
      .setDBUrl("jdbc:mysql://localhost:3306/demodb?serverTimezone=GMT%2B8&useSSL=false")
      .setDrivername("com.mysql.jdbc.Driver")
      .setUsername("root")
      .setPassword("123456")
      .setQuery("select id,name,age from t_student")
      .setRowTypeInfo(new RowTypeInfo( // 设置查询的列的类型
        BasicTypeInfo.INT_TYPE_INFO, // id：Int类型
        BasicTypeInfo.STRING_TYPE_INFO, // name：String类型
        BasicTypeInfo.INT_TYPE_INFO)) // age：Int类型
      .finish)
    // ToDo 2.transformation
    val dataMap=dataInput.map(x=>(x.getField(0),x.getField(1),x.getField(2)))

    // ToDo 3.sink
    dataMap.print()
  }

  case class Student(id: Int, name: String, age: Int) {}

}

