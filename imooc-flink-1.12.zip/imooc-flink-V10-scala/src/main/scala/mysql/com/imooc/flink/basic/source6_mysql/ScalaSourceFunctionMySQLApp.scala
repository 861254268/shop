//package mysql.com.imooc.flink.basic.source6_mysql
//
//import java.sql.DriverManager
//
//import com.mysql.jdbc.PreparedStatement
//import mysql.com.imooc.flink.basic.source6_mysql.ScalaSourceMySQLApp.Student
//import org.apache.flink.streaming.api.functions.source.{RichSourceFunction, SourceFunction}
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.api.scala._
//import org.apache.flink.configuration.Configuration
//
//
///**
//  * -*- coding: utf-8 -*-
//  *
//  * @Author: Mr.Jia
//  * @Create Time: 2021/9/6 20:49
//  * @File: ScalaSourceFunctionMySQLApp.scala/java
//  * @Software: IntelliJ IDEA 2018.2.4
//  * @descirption:
//  */
//object ScalaSourceFunctionMySQLApp {
//  def main(args: Array[String]): Unit = {
//    val env = StreamExecutionEnvironment.getExecutionEnvironment
//    val dataInput = env.addSource(new MySQLSource())
//    dataInput.print()
//
//    env.execute()
//  }
//}
