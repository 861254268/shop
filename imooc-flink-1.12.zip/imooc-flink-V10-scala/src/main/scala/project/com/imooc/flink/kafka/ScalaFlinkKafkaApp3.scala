package project.com.imooc.flink.kafka

import org.apache.flink.api.common.functions.{FlatMapFunction, MapFunction}
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.api.java.utils.ParameterTool
import org.apache.flink.streaming.api.datastream
import org.apache.flink.streaming.api.datastream.{DataStream, SingleOutputStreamOperator}
import org.apache.flink.util.Collector

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/16 21:02
  * @File: ScalaFlinkKafkaApp3.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Flink对接Kafka数据入门
  */
object ScalaFlinkKafkaApp3 {
  def main(args: Array[String]): Unit = {
    //    // F:\study\Flink\scala.properties


    // val tool: ParameterTool = ParameterTool.fromPropertiesFile(args(0))
    // val kafkaStreamV1: datastream.DataStream[String] = FlinkUtils.createKafkaStreamV1(tool)
    val kafkaStreamV3: DataStream[String] = FlinkUtils.createKafkaStreamV3(args, classOf[SimpleStringSchema])
    // kafkaStreamV3.print()

    val mapStream: SingleOutputStreamOperator[(String, Int)] = kafkaStreamV3.flatMap(new FlatMapFunction[String, String] {
      override def flatMap(value: String, out: Collector[String]): Unit = {
        val splits: Array[String] = value.split(",")
        for (elem <- splits) {
          out.collect(elem)
        }
      }
    }).map(new MapFunction[String, (String, Int)] {
      override def map(value: String): (String, Int) = {
        Tuple2.apply(value, 1)
      }
    })
    mapStream.print()

    FlinkUtils.env.execute()
    // test01(env)
    // env.execute()
  }
}