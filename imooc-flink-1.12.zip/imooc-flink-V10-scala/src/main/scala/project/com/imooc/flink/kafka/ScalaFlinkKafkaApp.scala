package project.com.imooc.flink.kafka

import java.util.Properties
import java.util.concurrent.TimeUnit

import org.apache.flink.api.common.functions.{FlatMapFunction, MapFunction}
import org.apache.flink.api.scala._
import org.apache.flink.api.common.restartstrategy.RestartStrategies
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.api.common.time.Time
import org.apache.flink.runtime.state.filesystem.FsStateBackend
import org.apache.flink.streaming.api.environment.CheckpointConfig
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer
import org.apache.flink.util.Collector

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/15 23:04
  * @File: ScalaFlinkKafkaApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Flink对接Kafka数据入门
  */
object ScalaFlinkKafkaApp {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    test01(env)
    env.execute()
  }

  def test01(env: StreamExecutionEnvironment): Unit = {
    // kafka相关参数
    val properties: Properties = new Properties()
    properties.setProperty("bootstrap.servers", "localhost:9092")
    // properties.setProperty("bootstrap.servers", "localhost:9092,localhost:9093,localhost:9094")
    properties.setProperty("group.id", "test")
    properties.setProperty("enable.auto.commit", "false") // 不让自动提交
    properties.setProperty("auto.offset.reset", "earliest")
    val topic = "test1"

    // checkpoint相关参数
    env.enableCheckpointing(5000)
    env.setStateBackend(new FsStateBackend("file:///./data/state"))
    env.getCheckpointConfig.enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION)
    env.setRestartStrategy(RestartStrategies.fixedDelayRestart(2, Time.of(5, TimeUnit.SECONDS)))

    val kafkaConsumer: FlinkKafkaConsumer[String] = new FlinkKafkaConsumer[String](topic, new SimpleStringSchema(), properties)
    val stream: DataStream[(String, Int)] = env.addSource(kafkaConsumer)
      .flatMap(new FlatMapFunction[String, String] {
        override def flatMap(value: String, out: Collector[String]): Unit = {
          val splits: Array[String] = value.split(",")
          for (elem <- splits) {
            out.collect(elem)
          }
        }
      }).map((_, 1))
      .keyBy(0)
      .sum(1)
    stream.print("wc统计：")

    // 容错
    val mapStream: DataStream[String] = env.socketTextStream("localhost", 9999)
      .map(new MapFunction[String, String] {
        override def map(value: String): String = {
          if (value.contains("pk")) new RuntimeException("把PK哥拉黑。。。")
          value.toUpperCase
        }
      })
    mapStream.print("from socket(nc):")
  }
}
