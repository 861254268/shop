package project.com.imooc.flink.kafka

import org.apache.flink.streaming.api.datastream


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/16 21:04
  * @File: ScalaKafkaTest.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
object ScalaKafkaTest {
  // F:\study\Flink\pk.properties
  def main(args: Array[String]): Unit = {
    val source: datastream.DataStream[(String, String)] = FlinkUtils.createKafkaStreamV4(args, classOf[ScalaPKKafkaDeserializationSchema])
    source.print()
    FlinkUtils.env.execute()
  }
}