package project.com.imooc.flink.dataskew

import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
import org.apache.flink.api.java.tuple.Tuple
import org.apache.flink.streaming.api.functions.KeyedProcessFunction
import org.apache.flink.util.Collector

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/14 21:36
  * @File: MyprocessFunction.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 根据key分类，统计每个key进来的数据量，定期统计数量，如果数量为0则预警
  */
class MyprocessFunction extends KeyedProcessFunction[Tuple, (String, String), String] {
  // 统计时间间隔
  val delayTime: Long = 1000 * 10
  lazy val state: ValueState[(String, Long)] = getRuntimeContext.getState[(String, Long)](new ValueStateDescriptor[(String, Long)]("cjcount", classOf[(String, Long)]))

  override def onTimer(timestamp: Long, ctx: KeyedProcessFunction[Tuple, (String, String), String]#OnTimerContext, out: Collector[String]): Unit = {
    printf("定时器触发,时间为：%d,状态为：%s,key为：%s\n", timestamp, state.value(), ctx.getCurrentKey)
    if (state.value()._2 == 0) {
      //该时间段数据为0,进行预警
      printf("类型为:%s,数据为0,预警\n", state.value()._1)
    }
    //定期数据统计完成后，清零
    state.update(state.value()._1, 0)
    //再次注册定时器执行
    val currentTime: Long = ctx.timerService().currentProcessingTime()
    ctx.timerService().registerProcessingTimeTimer(currentTime + delayTime)
  }

  /**
    * 代码中使用ValueState记录了状态信息，每次来商品都会进行总额度累加；
    * 商品第一次进入的时候会注册一个定时器，每隔十秒执行一次，定时器做预警功能，
    * 如果十秒内商品销售等于0，我们则进行预警。
    **/
  override def processElement(value: (String, String), ctx: KeyedProcessFunction[Tuple, (String, String), String]#Context, out: Collector[String]): Unit = {
    printf("状态值：%s,state是否为空：%s\n", state.value(), (state.value() == null))
    if (state.value() == null) {
      // 获取时间
      val currentTime: Long = ctx.timerService().currentProcessingTime()
      // 注册定时器10秒后触发
      ctx.timerService().registerProcessingTimeTimer(currentTime + delayTime)
      printf("定时器注册时间：%d\n", currentTime + 10000L)
      state.update(value._1, value._2.toInt)
    } else {
      // 统计数据
      val key: String = state.value()._1
      var count: Long = state.value()._2
      count += value._2.toInt
      // 更新state值
      state.update((key, count))
    }
    println(getRuntimeContext.getTaskNameWithSubtasks + "==>" + value)
    printf("状态值：%s\n", state.value())
    //返回处理后结果
    out.collect("处理后返回数据->" + value)
  }
}



