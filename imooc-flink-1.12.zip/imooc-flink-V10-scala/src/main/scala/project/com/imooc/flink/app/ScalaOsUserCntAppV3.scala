package project.com.imooc.flink

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.JSON._
import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
import org.apache.flink.api.common.typeinfo.{TypeHint, TypeInformation}
import org.apache.flink.configuration.Configuration
import org.apache.flink.shaded.guava18.com.google.common.hash.{BloomFilter, Funnels}
import org.apache.flink.streaming.api.functions.KeyedProcessFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.util.Collector

import scala.util.parsing.json.JSON

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/8 20:32
  * @File: package.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 新老用户的统计分析
  */
object ScalaOsUserCntAppV3 {
  /**
    * 该段代码是对OsUserCntAppV2.java的改进
    * <p>
    * 原来是根据数据中的某个字段
    * 现在我们是根据每个device来进行判断是否是新老用户
    * <p>
    * 思考：device放到state里面去呢???
    * <p>
    * 我们的实现：状态 + 布隆过滤器
    * BloomFilter：
    * 导包需注意：import org.apache.flink.shaded.guava18.com.google.common.hash.BloomFilter;
    **/

  import org.apache.flink.api.scala._

  case class Access(Shop_ID: String, Yunhuo_Person: String, hz_name: String, hz_area: String, hz_area2: String, hz_province: String, hz_city: String, Plan_num: String, at_time: String, at_stamp: Long)

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val cleanStream: DataStream[Access] =
      env.readTextFile("data/access.json").map(new MapFunction[String, Access] {
        override def map(value: String): Access = {
          // TODO...  json ==> Access01

          // 注意事项：一定要考虑解析的容错性
          try
            parseObject(value, classOf[Access])

          catch {
            case e: Exception =>
              e.printStackTrace() // 写到某个地方
              null
          }
        }
      }).filter(_ != null)
        .filter(_.Plan_num != "null")
    // cleanStream.print()

    val bloomFilterStream: DataStream[Access] = cleanStream.keyBy(_.hz_area)
      .process(keyedProcessFunction = new KeyedProcessFunction[String, Access, Access] {
        // 调用生命周期方法
        // 创建布隆过滤器
        private var state: ValueState[BloomFilter[String]] = _

        override def open(parameters: Configuration): Unit = {
          val valueStateDescriptor: ValueStateDescriptor[BloomFilter[String]] =
            new ValueStateDescriptor("s", TypeInformation.of(new TypeHint[BloomFilter[String]] {}))

          state = getRuntimeContext.getState(valueStateDescriptor)
        }

        override def processElement(value: Access, ctx: KeyedProcessFunction[String, Access, Access]#Context, out: Collector[Access]): Unit = {
          val device: String = value.hz_area
          var bloomFilter = state.value
          if (bloomFilter == null) {
            bloomFilter = BloomFilter.create(Funnels.unencodedCharsFunnel(), 100000)
          }
          // mightContain()：可能包含    ! :取反,则肯定不包含
          if (!bloomFilter.mightContain(device)) {
            bloomFilter.put(device)
            // value.hz_area="America"  // 此处有问题，需要解决
            state.update(bloomFilter)
          }
          out.collect(value)
        }
      })
    bloomFilterStream.print()
    env.execute()
  }
}


