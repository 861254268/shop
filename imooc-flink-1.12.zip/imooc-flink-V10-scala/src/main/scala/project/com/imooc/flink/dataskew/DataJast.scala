package project.com.imooc.flink.dataskew

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/14 22:35
  * @File: DataJast.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
case class DataJast(key: String, count: Long)

