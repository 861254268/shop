package project.com.imooc.flink.domain

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/9 21:45
  * @File: EventCatagoryProductCount.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
class EventCatagoryProductCount(hz_name: String, hz_area: String, yunhuo_Person: String, count: Long, start: Long, end: Long)

