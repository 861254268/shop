package project.com.imooc.flink.udf

import org.apache.flink.streaming.api.scala.function.WindowFunction
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector
import project.com.imooc.flink.domain.EventCatagoryProductCount

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/9 21:42
  * @File: ScalaTopNWindowFunction.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
class ScalaTopNWindowFunction extends WindowFunction[Long, EventCatagoryProductCount, (String, String, String), TimeWindow] {
  override def apply(key: (String, String, String), window: TimeWindow, input: Iterable[Long], out: Collector[EventCatagoryProductCount]): Unit = {
    val event: String = key._1
    val catagory: String = key._2
    val product: String = key._3

    val count: Long = input.iterator.next()
    val start: Long = window.getStart
    val end: Long = window.getEnd

    out.collect(new EventCatagoryProductCount(event, catagory, product, count, start, end))
  }
}

//case class EventCatagoryProductCount(
//                                      hz_name: String,
//                                      hz_area: String,
//                                      yunhuo_Person: String,
//                                      count: Long,
//                                      start: Long,
//                                      end: Long
//                                    )
