package project.com.imooc.flink.app

import org.apache.flink.api.common.functions.FilterFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment, _}
import org.apache.flink.streaming.connectors.redis.RedisSink
import org.apache.flink.streaming.connectors.redis.common.config.{FlinkJedisClusterConfig, FlinkJedisPoolConfig}
import org.apache.flink.streaming.connectors.redis.common.mapper.{RedisCommand, RedisCommandDescription, RedisMapper}

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/8 21:30
  * @File: ScalaOsUserCntAppV2.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 新老用户的统计分析
  */

object ScalaOsUserCntAppV2 {
  // 由于数据源的缺失及json数据格式问题，此处使用csv/txt数据进行相应的计算和处理
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val streamSource = env.readTextFile("data/access.txt")
    val cleanStream: DataStream[String] = streamSource.filter(_ != null)
      .filter(new FilterFunction[String] {
        override def filter(value: String): Boolean = {
          // 此处过滤货主名称不是“刘维国”的数据
          !"刘国维".equals(value.split(",")(4))
        }
      })
    // cleanStream.print()
    // TODO... 新老用户 ==> WC
    // 此处统计货主地区 ==> WC
    val result = cleanStream
      .map(_.split(",")(5))
      .map((_, 1))
      .keyBy(_._1).sum(1)
    // result.print("货主地区：").setParallelism(1)

    // 把数据结果sink到Redis
    val conf = new FlinkJedisPoolConfig.Builder().setHost("127.0.0.1").build()
    result.addSink(new RedisSink[(String, Int)](conf, new MyRedisMapper))

    class MyRedisMapper extends RedisMapper[(String, Int)] {
      override def getCommandDescription: RedisCommandDescription = {
        //把传感器id和温度值保存成哈希表: HSET key field value
        new RedisCommandDescription(RedisCommand.HSET, "os_user-cnt:123")
      }

      override def getKeyFromData(data: (String, Int)): String = {
        data._1
      }

      override def getValueFromData(data: (String, Int)): String = {
        data._2.toString
      }
    }
    env.execute()
  }
}
