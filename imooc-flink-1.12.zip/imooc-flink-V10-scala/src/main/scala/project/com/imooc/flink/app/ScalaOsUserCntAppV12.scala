package project.com.imooc.flink.app

import com.alibaba.fastjson.JSON.parseObject
import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment
// import project.com.imooc.flink.app.ScalaOsUserCntAppV3.Access

import scala.util.parsing.json.JSON

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/9 20:37
  * @File: ScalaOsUserCntAppV12.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 按照操作系统维度进行新老用户的统计分析
  **/
// 此处使用json格式数据进行处理，创建样例类
object ScalaOsUserCntAppV12 {

  case class Access1(table: String, current_ts: String, pos: String)

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val cleanStream: SingleOutputStreamOperator[Access1] = env.readTextFile("data/access11.json")
      .map(new MapFunction[String, Access1] {
        override def map(value: String): Access1 = {
          // TODO...  json ==> Access01
          // 注意事项：一定要考虑解析的容错性
          try
            parseObject(value, classOf[Access1])

          catch {
            case e: Exception =>
              e.printStackTrace() // 写到某个地方
              null
          }
        }
      })
    cleanStream.print()
    env.execute()
  }
}
