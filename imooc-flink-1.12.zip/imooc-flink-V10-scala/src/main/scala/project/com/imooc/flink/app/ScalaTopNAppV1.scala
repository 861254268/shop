//package project.com.imooc.flink.app
//
//import com.alibaba.fastjson.JSON._
//import org.apache.flink.api.common.functions.MapFunction
//import org.apache.flink.api.java.functions.KeySelector
//import org.apache.flink.api.java.tuple.Tuple3
//import org.apache.flink.streaming.api.scala.{DataStream, KeySelectorWithType, StreamExecutionEnvironment, WindowedStream}
//import org.apache.flink.api.scala._
//import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
//import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows
//import org.apache.flink.streaming.api.windowing.time.Time
//import org.apache.flink.streaming.api.windowing.windows.TimeWindow
//import project.com.imooc.flink.udf.{ScalaTopNAggregateFunction, ScalaTopNWindowFunction}
//
///**
//  * -*- coding: utf-8 -*-
//  *
//  * @Author: Mr.Jia
//  * @Create Time: 2021/9/9 20:53
//  * @File: ScalaTopNAppV1.scala/java
//  * @Software: IntelliJ IDEA 2018.2.4
//  * @descirption: 统计五分钟内的不同event(加购物车 、 浏览...)类型、类别、商品的TopN访问量
//  */
//object ScalaTopNAppV1 {
//
//  case class Access(Shop_ID: String, Yunhuo_Person: String, hz_name: String, hz_area: String, hz_area2: String, hz_province: String, hz_city: String, Plan_num: String, at_time: String, at_stamp: Long)
//
//  def main(args: Array[String]): Unit = {
//    val env = StreamExecutionEnvironment.getExecutionEnvironment
//    val cleanStream: DataStream[Access] =
//      env.readTextFile("data/access.json").map(new MapFunction[String, Access] {
//        override def map(value: String): Access = {
//          // TODO...  json ==> Access01
//
//          // 注意事项：一定要考虑解析的容错性
//          try
//            parseObject(value, classOf[Access])
//
//          catch {
//            case e: Exception =>
//              e.printStackTrace() // 写到某个地方
//              null
//          }
//        }
//      }).filter(_ != null)
//
//        // 加上WaterMark
//        .assignTimestampsAndWatermarks(
//        new BoundedOutOfOrdernessTimestampExtractor[Access](Time.seconds(20)) {
//          override def extractTimestamp(element: Access): Long = {
//            element.at_stamp
//          }
//        }).filter(_.hz_name != "Liuxiansheng")
//
//    val winStream: WindowedStream[Access, Tuple3[String, String, String], TimeWindow] = cleanStream.keyBy(new KeySelector[Access, Tuple3[String, String, String]]() {
//      @throws[Exception]
//      override def getKey(value: Access): Tuple3[String, String, String] = {
//        return Tuple3.of(value.hz_name, value.hz_city, value.Yunhuo_Person)
//      }
//    }).window(SlidingEventTimeWindows.of(Time.minutes(10), Time.minutes(1)))
//
//    // 作用上WindowFunction
//    winStream.aggregate(new ScalaTopNAggregateFunction,new ScalaTopNWindowFunction)
//    //此处有问题需要解决
//
//
//    env.execute()
//  }
//}