package project.com.imooc.flink.dataskew

import org.apache.flink.api.common.functions.AggregateFunction
import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
import org.apache.flink.streaming.api.functions.KeyedProcessFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment, _}
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.util.Collector

import scala.util.Random

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/14 22:21
  * @File: ProcessFunctionScalaV2.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 使用两阶段keyby来解决数据倾斜问题
  */
object ProcessFunctionScalaV2 {
  /**
    * 1.首先将key打散，我们加入将key转化为 key-随机数 ,保证数据散列
    * 2.对打散后的数据进行聚合统计，这时我们会得到数据比如 : (key1-12,1),(key1-13,19),(key1-1,20),(key2-123,11),(key2-123,10)
    * 3.将散列key还原成我们之前传入的key，这时我们的到数据是聚合统计后的结果，不是最初的原数据
    * 4.二次keyby进行结果统计，输出到addSink
    **/
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    env.enableCheckpointing(2000)
    val stream: DataStream[String] = env.socketTextStream("localhost", 9999)
    val typeAndData = stream.map(x => (x.split(",")(0), x.split(",")(1).toLong))
    // 对key进行散列
    val dataStream: DataStream[(String, Long)] = typeAndData.map(x => (x._1 + "-" + Random.nextInt(100), x._2))
    // 设置窗口滚动时间，每隔10秒钟统计一次每个key下的数据总量
    val keyByAgg: DataStream[DataJast] = dataStream.keyBy(_._1)
      .timeWindow(Time.seconds(10))
      .aggregate(new countAggregate())
    keyByAgg.print("第一次keyBy输出")

    // 还原key,并进行二次keyby,对数据总量进行累加
    val result: DataStream[DataJast] = keyByAgg.map(data => {
      val newKey: String = data.key.substring(0, data.key.indexOf("-"))
      println(newKey)
      DataJast(newKey, data.count)
    })
      .keyBy(_.key)
      .process(new MyProcessFunction1())
    result.print()

    env.execute()
  }
}
