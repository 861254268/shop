package project.com.imooc.flink.app

import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/15 22:58
  * @File: ScalaProvinceUserCntAppV1.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 按照操作系统维度进行新老用户的统计分析
  */
object ScalaProvinceUserCntAppV1 {
  // 由于数据源的缺失及json数据格式问题，此处使用csv/txt数据进行相应的计算和处理
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    // 该段代码需要后续进行进一步验证才能使用
    val streamSource: DataStream[String] = env.readTextFile("data/access.txt")
    val cleanStream: DataStream[String] = streamSource.filter(x => x != null)
      .filter(x => x.split(",")(4) != "刘维国")

    // .map(new GaodeLocationMapFunction()) // 这种方法也是可以进行map的，只是由于数据及网络原因
    cleanStream.map(new MyMapResult()).print()
    // 入库Redis的功能此处不再实现。ScalaOsUserCntAppV1.scala部分已实现

    env.execute()
  }

  class MyMapResult extends MapFunction[String, (String, String, Int)]() {
    override def map(value: String): (String, String, Int) = {
      (value.split(",")(4), value.split(",")(5), 1)
    }
  }

}
