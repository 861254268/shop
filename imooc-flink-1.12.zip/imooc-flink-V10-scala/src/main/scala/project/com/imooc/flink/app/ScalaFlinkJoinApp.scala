//package project.com.imooc.flink.app
//
//import org.apache.flink.api.common.eventtime.WatermarkStrategy
//import org.apache.flink.api.common.functions.MapFunction
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.api.scala._
//import org.apache.flink.streaming.api.TimeCharacteristic
//import org.apache.flink.table.shaded.org.joda.time.Duration
//import org.apache.flink.table.sources.wmstrategies.WatermarkStrategy
//
///**
//  * -*- coding: utf-8 -*-
//  *
//  * @Author: Mr.Jia
//  * @Create Time: 2021/9/9 22:44
//  * @File: ScalaFlinkJoinApp.scala/java
//  * @Software: IntelliJ IDEA 2018.2.4
//  * @descirption: 双流JOIN实现之对接数据
//  */
//object ScalaFlinkJoinApp {
//  /**
//    * 业务数据：订单、条目   存储在数据库中
//    * <p>
//    * mysql ==> canal ==> kafka ==> flink
//    */
//  def main(args: Array[String]): Unit = {
//    val env = StreamExecutionEnvironment.getExecutionEnvironment
//    // 时间语义：1.10以及之前的旧版本该时间语义一定要写
//    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
//    // .setParallelism(1)
//
//    // order
//    val orderData = env.socketTextStream("localhost", 9999)
//      .map(new MapFunction[String, (String, Long, Double)] {
//        override def map(value: String): (String, Long, Double) = {
//          val splits = value.split(",")
//          val orderId = splits(0).trim
//          val time = splits(1).trim.toLong
//          val money = splits(2).trim.toDouble
//          Tuple3.apply(orderId, time, money)
//        }
//      })
//      .assignTimestampsAndWatermarks(WatermarkStrategy.[Tuple3]forBoundedOutOfOrderness(Duration))
//
//    env.execute()
//  }
//
//  // case class OrderInfo(orderId:String,time:Long,money:Double)
//
//}
