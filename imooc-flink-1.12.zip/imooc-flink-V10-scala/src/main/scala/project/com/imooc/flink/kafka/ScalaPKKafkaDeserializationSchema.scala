package project.com.imooc.flink.kafka

import java.nio.charset.StandardCharsets

import org.apache.flink.api.common.typeinfo.{TypeHint, TypeInformation}
import org.apache.flink.streaming.connectors.kafka.KafkaDeserializationSchema
import org.apache.kafka.clients.consumer.ConsumerRecord

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/16 21:04
  * @File: ScalaPKKafkaDeserializationSchema.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
class ScalaPKKafkaDeserializationSchema extends KafkaDeserializationSchema[(String, String)] {
  override def isEndOfStream(nextElement: (String, String)): Boolean = {
    false
  }

  override def deserialize(record: ConsumerRecord[Array[Byte], Array[Byte]]): (String, String) = {
    val topic: String = record.topic()
    val partition: Int = record.partition()
    val offset: Long = record.offset()
    val id: String = topic + "_" + partition + "_" + offset
    val value: String = new String(record.value(), StandardCharsets.UTF_8)
    (id, value)
  }

  override def getProducedType: TypeInformation[(String, String)] = {
    TypeInformation.of(new TypeHint[(String, String)] {

    })
  }
}
