package project.com.imooc.flink.dataskew

import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment, _}

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/14 21:34
  * @File: ProcessFuncationScala.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: ProcessFunction使用
  */
object ProcessFuncationScala {
  /**
    * 通过socketTextStream读取9999端口数据，统计在一定时间内不同类型商品的销售总额度，
    * 如果持续销售额度为0，则执行定时器通知老板，是不是卖某种类型商品的员工偷懒了（只做功能演示，根据个人业务来使用，比如统计UV等操作）
    **/
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    // aa,12  // aa,12  // b,10 // b,10 // b,10 // b,10
    val stream: DataStream[String] = env.socketTextStream("localhost", 9999)
    val typeAndData: DataStream[(String, String)] = stream.map(x => (x.split(",")(0), x.split(",")(1)))
      .setParallelism(4)
    typeAndData.keyBy(0).process(new MyprocessFunction()).print("结果")
    env.execute()
  }

}
