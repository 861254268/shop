//package project.com.imooc.flink.udf
//
//import org.apache.flink.api.common.functions.AggregateFunction
//import project.com.imooc.flink.ScalaOsUserCntAppV3.Access
//
///**
//  * -*- coding: utf-8 -*-
//  *
//  * @Author: Mr.Jia
//  * @Create Time: 2021/9/9 21:27
//  * @File: ScalaTopNAggregateFunction.scala/java
//  * @Software: IntelliJ IDEA 2018.2.4
//  * @descirption: 统计五分钟内的不同event(加购物车 、 浏览...)类型、类别、商品的TopN访问量
//  */
//// 由于数据源的缺失及json数据格式问题，此处使用csv/txt数据进行相应的计算和处理
//class ScalaTopNAggregateFunction extends AggregateFunction[Access, Long, Long] {
//  override def createAccumulator(): Long = {
//    0L
//  }
//
//  override def add(value: Access, accumulator: Long): Long = {
//    accumulator + 1
//  }
//
//  override def getResult(accumulator: Long): Long = {
//    accumulator
//  }
//
//  override def merge(a: Long, b: Long): Long = null
//}
