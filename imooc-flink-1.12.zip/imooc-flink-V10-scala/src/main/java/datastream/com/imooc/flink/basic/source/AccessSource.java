package datastream.com.imooc.flink.basic.source;

import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;

import java.util.Random;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/9/2 19:33
 * @File: AccessSource.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class AccessSource implements ParallelSourceFunction<Access> {
    boolean running = true;

    @Override
    public void run(SourceContext<Access> ctx) throws Exception {
        String[] domains = {"a.com", "b.com", "imooc.com"};
        Random random = new Random();

        while (running) {
            for (int i = 0; i < 10; i++) {
                Access access = new Access();
                access.setTime(1234567L);
                access.setDomain(domains[random.nextInt(domains.length)]);
                access.setTraffic(random.nextDouble()+1000);
                ctx.collect(access);
            }

            Thread.sleep(5000);
        }
    }

    @Override
    public void cancel() {
        running = false;
    }
}
