package com.imooc.flink.course05

import org.apache.flink.configuration.Configuration
import org.apache.flink.streaming.api.functions.source.{RichParallelSourceFunction, SourceFunction}

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/17 21:52
  * @File: CustomRichParallelSourceFunction.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 自定义强并行sourcrFunction
  */
class CustomRichParallelSourceFunction extends RichParallelSourceFunction[Long] {
  var isRunning = true
  var count = 0L

  override def run(ctx: SourceFunction.SourceContext[Long]): Unit = {
    while(isRunning){
      ctx.collect(count)
      count+=1
      Thread.sleep(500)
    }
  }

  override def cancel(): Unit = {
    isRunning=false
  }

  override def open(parameters: Configuration): Unit = super.open(parameters)

  override def close(): Unit = super.close()
}
