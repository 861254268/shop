package com.imooc.flink.tablesql

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/3 20:16
  * @File: WC.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
case class WC(word: String, cnt: Int) {

}
