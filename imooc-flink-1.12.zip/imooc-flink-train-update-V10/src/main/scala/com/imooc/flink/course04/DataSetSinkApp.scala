package com.imooc.flink.course04

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.core.fs.FileSystem.WriteMode

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/15 22:31
  * @File: DataSetSinkApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: sink 函数之scala实现
  */
object DataSetSinkApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    //    val data = 1 to 10
    val data = 1.to(10)
    val text = env.fromCollection(data)

    //    val filePath = "F:\\study\\Flink\\imooc\\out\\sink-out-scala"
    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\out\\sink-out-scala"
    text.writeAsText(filePath, WriteMode.OVERWRITE) //.setParallelism(2)
    // 若并行度为1，得到的sink-out是个文件，若并行度大于1，得到的sink-out是文件夹
    env.execute("DataSetSinkApp")
  }
}
