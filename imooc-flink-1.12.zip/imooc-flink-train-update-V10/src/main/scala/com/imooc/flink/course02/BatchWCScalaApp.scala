package com.imooc.flink.course02

import org.apache.flink.api.scala.ExecutionEnvironment

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/11 18:26
  * @File: BatchWCScalaApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 使用Scala API来开发flink的批处理应用程序
  */
object BatchWCScalaApp {

  def main(args: Array[String]): Unit = {

    val input = "D:\\SourceCode2020\\FlinkDemo\\imooc\\input"

    val env = ExecutionEnvironment.getExecutionEnvironment

    val text = env.readTextFile(input)

    // 引入隐式转换
    import org.apache.flink.api.scala._

    // TODO... 1) 参考Scala课程  2）API再来讲
    text.flatMap(_.toLowerCase.split("\t"))
      .filter(_.nonEmpty)
      .map((_, 1))
      .groupBy(0)
      .sum(1).print()

  }

}