package com.imooc.flink.state

import org.apache.flink.api.common.functions.RichFlatMapFunction
import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.configuration.Configuration
import org.apache.flink.util.Collector

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/4 21:49
  * @File: KeyedStateApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: KeyedSatate案例开发
  */
object KeyedStateApp {
  /**
    * 使用KeyedState求平均数
    * 输入的数据结构：<k,v>
    * 每次到达3个元素，我们就求平均数
    * 1) 如何知道到达两个元素了
    * 2) 平均数 = 总数 / 个数
    **/
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.fromCollection(List(
      (1, 3),
      (1, 5),
      (1, 7),
      (1, 4),
      (1, 2),
      (1, 6),
      (1, 9)
    )).keyBy(_._1)
      .flatMap(new RichFlatMapFunction[(Int, Int), (Int, Int)] { // 实现抽象方法

        // 定义State
        var state: ValueState[(Int, Int)] = _

        // 实现open()方法和close()方法
        // 获取state
        override def open(parameters: Configuration): Unit = {
          // 此处赋值一定要注意
          state = getRuntimeContext.getState(
            new ValueStateDescriptor[(Int, Int)]("avg", createTypeInformation[(Int, Int)])
          )
        }

        override def close(): Unit = {

        }

        override def flatMap(in: (Int, Int), collector: Collector[(Int, Int)]): Unit = {
          // 获取state
          val tmpState: (Int, Int) = state.value()
          val currentState = if (null != tmpState) {
            tmpState
          } else {
            (0, 0) // 赋初始值
          }

          // 更新
          val newState = (currentState._1 + 1, currentState._2 + in._2)

          state.update(newState)

          if (newState._1 >= 3) {
            collector.collect((in._1, newState._2 / newState._1))
            // 清除
            state.clear()
          }

        }
      }).print()

    println(this.getClass.getSimpleName)
    env.execute(this.getClass.getSimpleName)
  }
}
