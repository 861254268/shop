package com.imooc.flink.course04

import org.apache.flink.api.scala.ExecutionEnvironment
// 导入隐式转换
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/13 20:56
  * @File: DataSetDataSourceApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 从集合创建dataset
  */
object DataSetDataSourceApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    fromCollection(env)
  }

  def fromCollection(env: ExecutionEnvironment): Unit = {
    val data = 1 to 10
    env.fromCollection(data).print()
  }
}
