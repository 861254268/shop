package com.imooc.flink.tablesql

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.table.api.scala.BatchTableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/3 20:19
  * @File: TableAPIApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: Table API实战
  */
object TableAPIApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    val tEnv = BatchTableEnvironment.create(env)

    val inputDataSet = env.readTextFile("D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\data\\tablesql\\access.log")
    // map操作
    val mapDS = inputDataSet.map(x => {
      val splits = x.split(",")
      Access(splits(0).trim.toLong, splits(1).trim, splits(2).trim.toDouble)
    })

    tEnv.createTemporaryView("table_access", mapDS)
    // API方式处理数据：
    val tableAccess = tEnv.from("table_access")
    //    val resultTable = tableAccess.filter("domain!='imooc.com'").select("domain,traffic")

    // SQL是这样的：select domain,sum(traffic) as traffics from table_access group by domain where domain<>'imooc.com'
    val resultTable = tableAccess.filter("domain!='imooc.com'") //.select("domain,traffic")
      .groupBy("domain") // 分组
      .aggregate("sum(traffic) as traffics") //　聚合
      .select("domain,traffics")
    tEnv.toDataSet[Row](resultTable).print()

  }
}
