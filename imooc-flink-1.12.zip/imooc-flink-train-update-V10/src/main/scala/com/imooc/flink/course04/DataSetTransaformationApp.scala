package com.imooc.flink.course04

import org.apache.flink.api.scala.ExecutionEnvironment

import scala.collection.mutable.ListBuffer
// 导入隐式转换
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/14 21:31
  * @File: DataSetTransaformationApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: transformation函数之scala实现
  */
object DataSetTransaformationApp {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    //    mapFunction(env)
    //    filterFunction(env)
    mapPartitionFunction(env)

  }

  // transformation函数mapPartition之scala实现
  //  DataSource100个元素，把结果存储到数据库中
  def mapPartitionFunction(env: ExecutionEnvironment): Unit = {
    val students = new ListBuffer[String]
    for (i <- 1 to 100) {
      students.append("student: " + i)
    }
    // 加载数据源
    val data = env.fromCollection(students).setParallelism(6)
    //    data.map(x => {
    //      // 每一个元素要存储到数据库中去，肯定需要先获取到一个connection
    //      val connection = DBUtils.getConection()
    //      println(connection + "...")
    //
    //      // TODO... 保存数据到DB
    //      DBUtils.returnConnection(connection)
    //    }).print()

    // transformation函数mapPartition之scala实现
    data.mapPartition(x => {
      val connection = DBUtils.getConection()
      println(connection + "...")
      // TODO... 保存数据到DB
      DBUtils.returnConnection(connection)
      x //返回x
    }).print()
  }


  // transformation函数filter之scala实现
  def filterFunction(env: ExecutionEnvironment): Unit = {
    //    val data=env.fromCollection(List(1,2,3,4,5,6,7,8,9,10))
    //    data.map(_+1).filter(_>5).print()
    val data = env.fromCollection(List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
      .map(_ + 1)
      .filter(_ > 5)
      .print()
  }

  // transformation函数map之scala实现
  def mapFunction(env: ExecutionEnvironment) {
    val data = env.fromCollection(List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
    //    data.print()
    // 对data中的每个元素都进行+1的操作
    //    data.map((x: Int) => x + 1).print()
    //    data.map((x) => x + 1).print()
    //    data.map(x => x + 1).print()
    data.map(_ + 1).print() //这种写法经常用到
  }

}
