package com.imooc.flink.course08

import java.util.Properties

import org.apache.flink.api.scala._
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.CheckpointingMode
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/22 19:41
  * @File: KafkaConnectorConsumerApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: flink对接kafka作为Source使用
  */
object KafkaConnectorConsumerApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    // checkpoint常用参数设置：
    // env.enableCheckpointing(4000) //每隔多久
    //    env.getCheckpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE) //配置checkpoint，模式采用执行一次
    //    env.getCheckpointConfig.setCheckpointTimeout(10000) //设置超时时间
    //    env.getCheckpointConfig.setMaxConcurrentCheckpoints(1) //最大并发

    val topic = "test1"
    val properties = new Properties()

    //hadoop000 必须要求你的idea这台机器的hostname和ip的映射关系必须要配置
    //    properties.setProperty("bootstrap.servers","192.168.199.233:9092")
    properties.setProperty("bootstrap.servers", "localhost:9092")
    properties.setProperty("group.id", "test")

    val data = env.addSource(new FlinkKafkaConsumer[String](topic, new SimpleStringSchema(), properties))
    data.print()

    env.execute("KafkaConnectorConsumerApp")
  }

}
