package com.imooc.flink.course05


import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.windowing.time.Time

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/17 11:44
  * @File: DataStreamSocketApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 从Socket创建datastream之scala实现
  */
object DataStreamSocketApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val text = env.socketTextStream("localhost", 9999)

    text.flatMap(_.toLowerCase.split(",") filter (_.nonEmpty))
      .map((_, 1))
      .keyBy(_._1)
      .timeWindow(Time.seconds(5))
      .sum(1).print()

    env.execute("DataStreamSocketApp")
  }
}

