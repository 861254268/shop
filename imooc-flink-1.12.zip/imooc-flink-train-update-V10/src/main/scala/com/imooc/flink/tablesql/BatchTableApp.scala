package com.imooc.flink.tablesql

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.table.api.scala.BatchTableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/3 20:12
  * @File: BatchTableApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: DataSet整合Table API实战
  */
object BatchTableApp {
  def main(args: Array[String]): Unit = {
    // 创建批处理运行环境
    val env = ExecutionEnvironment.getExecutionEnvironment
    // 创建一个Table运行环境
    val tEnv = BatchTableEnvironment.create(env)
    // 读取数据源
    val inputDataSet = env.readTextFile("D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\data\\tablesql\\access.log")
    // map操作
    val mapBatch = inputDataSet.map(x => {
      val splits = x.split(",")
      Access(splits(0).trim.toLong, splits(1).trim, splits(2).trim.toDouble)

    })
    // DataSet==>Table
    val table = tEnv.fromDataSet(mapBatch)
    // SQL: select domain from xxx where domain='imooc.com'
    val resultTable = table.select("domain").filter("domain='imooc.com'")


    tEnv.toDataSet[Row](resultTable).print()
  }
}

