package com.imooc.flink.course04

import scala.util.Random

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/15 19:56
  * @File: DBUtils.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 工具类
  */
object DBUtils {
  def getConection() = {
    new Random().nextInt(10) + ""
  }

  def returnConnection(connection: String): Unit = {

  }
}


