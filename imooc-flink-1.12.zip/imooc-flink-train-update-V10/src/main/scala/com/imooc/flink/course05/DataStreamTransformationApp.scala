package com.imooc.flink.course05

import java.{lang, util}

import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.collector.selector.OutputSelector
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/17 22:08
  * @File: DataStreamTransformationApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: transformation函数之scala实现
  */
object DataStreamTransformationApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    //    filterFunction(env)
    //    unionFunction(env)
    splitSelectFunction(env)
    env.execute("DataStreamTransformationApp")
  }

  //  transformation函数split和select之scala实现
  //  ********此段代码需要再次联练习*********
  def splitSelectFunction(env: StreamExecutionEnvironment): Unit = {
    import org.apache.flink.api.scala._
    val data = env.addSource(new CustomNonParallelSourceFunction)

    val splits = data.split(new OutputSelector[Long] {
      override def select(value: Long): lang.Iterable[String] = {
        val list = new util.ArrayList[String]()
        if (value % 2 == 0) {
          list.add("even")
        } else {
          list.add("odd")
        }
        list // 返回list
      }
    })

    splits.select("odd","even").print().setParallelism(1)
  }


  // transformation函数union之scala实现
  def unionFunction(env: StreamExecutionEnvironment): Unit = {
    val data1 = env.addSource(new CustomNonParallelSourceFunction).map(x => 2 * x)
    val data2 = env.addSource(new CustomNonParallelSourceFunction).map(x => 3 * x)
    data1.union(data2).print().setParallelism(1)
  }

  // transformation函数map和filter之scala实现
  def filterFunction(env: StreamExecutionEnvironment): Unit = {
    val data = env.addSource(new CustomNonParallelSourceFunction).setParallelism(1)
    data.map(x => {
      println("recived: " + x)
      x
    }).filter(_ % 2 == 0).print().setParallelism(1)
  }


}
