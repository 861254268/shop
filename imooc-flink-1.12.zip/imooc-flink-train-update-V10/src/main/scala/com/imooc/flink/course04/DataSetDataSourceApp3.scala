package com.imooc.flink.course04

import org.apache.flink.api.scala.ExecutionEnvironment

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/14 21:25
  * @File: DataSetDataSourceApp3.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 从压缩文件中创建dataset
  */
object DataSetDataSourceApp3 {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    // fromCollection(env)
    //    textFile(env)
    //    csvFile(env)
    readCompressionFiles(env)
  }

  // 从压缩文件中创建dataset
  def readCompressionFiles(env: ExecutionEnvironment): Unit = {
    //    val filePath="F:\\study\\Flink\\imooc\\flink-train\\Compression"
    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\Compression"
    env.readTextFile(filePath).print()
  }

}
