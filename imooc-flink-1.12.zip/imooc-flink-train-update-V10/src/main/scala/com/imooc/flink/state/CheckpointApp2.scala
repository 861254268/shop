package com.imooc.flink.state

import java.util.concurrent.TimeUnit

import org.apache.flink.api.common.restartstrategy.RestartStrategies
import org.apache.flink.api.common.time.Time
import org.apache.flink.api.scala._
import org.apache.flink.runtime.state.filesystem.FsStateBackend
import org.apache.flink.streaming.api.environment.CheckpointConfig.ExternalizedCheckpointCleanup
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/4 22:07
  * @File: CheckpointApp2.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 开启Checkpoint,StateBackend测试
  */
object CheckpointApp2 {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    env.enableCheckpointing(5000) // 检查时间
    // FsStateBackend
    //env.setStateBackend(new FsStateBackend("file:///D:/SourceCode2020/FlinkDemo/imooc/DataNote/state"))
    env.setStateBackend(new FsStateBackend("file:///D:/SourceCode2020/FlinkDemo/imooc/imooc-flink-train-update1.10/src/main/scala/com/imooc/flink/state"))
    // RocksDBStateBackend
    // env.setStateBackend(new RocksDBStateBackend("", true))

    /*
    * // 设置checkpoint是否保存下来：
    * ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION --保留
    * ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION --删除(默认)
     */
    env.getCheckpointConfig.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION)
    // 设置重启策略
    env.setRestartStrategy(
      RestartStrategies.fixedDelayRestart(2, Time.of(5, TimeUnit.SECONDS))
    )

    env.socketTextStream("localhost", 9999).map(x => {
      if (x.contains("pk")) {
        throw new RuntimeException("出现Bug了...")
      } else {
        x.toLowerCase
      }
    }).flatMap(_.split(","))
      .map((_, 1))
      .keyBy(0)
      .sum(1)
      .print()

    //    val stream = env.socketTextStream("localhost", 9999)
    //    stream.print()


    env.execute(this.getClass.getSimpleName)
  }
}
