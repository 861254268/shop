package com.imooc.flink.tablesql

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/3 20:03
  * @File: Access.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
case class Access(time: Long, domain: String, traffic: Double) {

}
