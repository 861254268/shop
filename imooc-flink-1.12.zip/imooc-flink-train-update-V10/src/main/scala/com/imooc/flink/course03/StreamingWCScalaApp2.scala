package com.imooc.flink.course03

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/11 18:28
  * @File: StreamingWCScalaApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 使用Java API来开发flink的实时处理应用程序。
  * 指定key之key选择器函数
  */
object StreamingWCScalaApp2 {

  def main(args: Array[String]): Unit = {

    val env = StreamExecutionEnvironment.getExecutionEnvironment


    StreamExecutionEnvironment.createLocalEnvironment()

    // 引入隐式转换
    import org.apache.flink.api.scala._

    val text = env.socketTextStream("localhost", 9999)


    text.flatMap(_.split(","))
      .map((x=>WC(x,1)))      // WC(word,count)
      //      .keyBy("word")
      .keyBy(x => x.word)
      // 简化写法：.keyBy(_.word)
      .timeWindow(Time.seconds(5))
      .sum("count")
      .print()
      .setParallelism(1)

    env.execute("StreamingWCScalaApp2")
  }

  case class WC(word: String, count: Int)

}
