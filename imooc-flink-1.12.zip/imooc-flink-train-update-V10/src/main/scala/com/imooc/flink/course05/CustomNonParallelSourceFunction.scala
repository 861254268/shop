package com.imooc.flink.course05

import org.apache.flink.streaming.api.functions.source.SourceFunction

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/17 21:44
  * @File: CustomNonParallelSourceFunction.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 自定义非并行sourceFunction
  */
class CustomNonParallelSourceFunction extends SourceFunction[Long] {
  var count = 0L
  var isRunning = true

  override def run(ctx: SourceFunction.SourceContext[Long]): Unit = {
    while (isRunning) {
      ctx.collect(count)
      count += 1
      Thread.sleep(500)
    }
  }

  override def cancel(): Unit = {
    isRunning = false
  }
}
