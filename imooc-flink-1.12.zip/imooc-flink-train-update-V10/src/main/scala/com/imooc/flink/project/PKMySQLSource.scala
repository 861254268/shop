package com.imooc.flink.project

import java.sql
import java.sql.{DriverManager, PreparedStatement}

import com.mysql.jdbc.Connection
import org.apache.flink.streaming.api.functions.source.{RichParallelSourceFunction, SourceFunction}
import org.apache.flink.api.scala._
import org.apache.flink.configuration.Configuration

import scala.collection.mutable


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/8 16:03
  * @File: PKMySQLSource.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */

/**
object PKMySQLSource extends RichParallelSourceFunction[mutable.HashMap[String, String]] {
  var connection: sql.Connection = null
  var ps: PreparedStatement = null
  var isRunning = true
  //  val counter = 1L

  // open:建立连接
  override def open(parameters: Configuration): Unit = {
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://localhost:3306/imooc_flink"
    val user = "root"
    val password = "123456"
    Class.forName(driver)
    connection = DriverManager.getConnection(url, user, password)

    val sql = "select user_id,domain from user_domain_config"
    ps = connection.prepareStatement(sql)
  }

  // 释放资源
  override def close(): Unit = {
    if (ps != null) {
      ps.close()
    }

    if (connection != null) {
      connection.close()
    }
  }

  // 此处是代码的关键：要从MySQL表中把数据读取出来转成Map进行数据的封装
  override def run(ctx: SourceFunction.SourceContext[mutable.HashMap[String, String]]): Unit = {

    // TODO...
    while (isRunning) {
      ps
    }
  }

  override def cancel(): Unit = {
    isRunning = false
  }
}


  */


