package com.imooc.flink.course07

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.streaming.api.windowing.time.Time

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/19 21:00
  * @File: WindowsApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: time windows详解及Scala编程
  */
object WindowsApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    val text = env.socketTextStream("localhost", 9999)

    text.flatMap(_.split(","))
      .map((_, 1))
      .keyBy(0)
      // .timeWindow(Time.seconds(5)) //滚动窗口:tumbling windows
      .timeWindow(Time.seconds(10), Time.seconds(5)) //滑动窗口：sliding windows
      .sum(1)
      .print().setParallelism(1)

    env.execute("WindowsApp")
  }

}
