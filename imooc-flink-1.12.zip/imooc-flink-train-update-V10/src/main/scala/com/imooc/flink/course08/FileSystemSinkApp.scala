package com.imooc.flink.course08

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.connectors.fs.StringWriter
import org.apache.flink.streaming.connectors.fs.bucketing.{BucketingSink, DateTimeBucketer}

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/20 22:07
  * @File: FileSystemSinkApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: HDFS Connector的使用
  */
object FileSystemSinkApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    val data = env.socketTextStream("localhost", 9999)
    data.print().setParallelism(1)

    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\HDFSsink"
    val sink = new BucketingSink[String](filePath)

    sink.setBucketer(new DateTimeBucketer[String]("yyyy-MM-dd--HHmm"))
    sink.setWriter(new StringWriter())
    sink.setBatchRolloverInterval(20000)
    data.addSink(sink)
    env.execute("FileSystemSinkApp")
  }
}
