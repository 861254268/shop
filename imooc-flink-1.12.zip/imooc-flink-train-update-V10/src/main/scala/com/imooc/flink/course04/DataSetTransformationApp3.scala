package com.imooc.flink.course04

import org.apache.flink.api.scala.ExecutionEnvironment

import scala.collection.mutable.ListBuffer
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/15 21:04
  * @File: DataSetTransformationApp3.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: transformation函数之scala实现
  */
object DataSetTransformationApp3 {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    joinFunction(env)
  }

  // transformation函数join之scala实现
  def joinFunction(env: ExecutionEnvironment): Unit = {
    val info1 = ListBuffer[(Int, String)]() //编号  姓名
    info1.append((1, "PK哥"))
    info1.append((2, "J哥"))
    info1.append((3, "小队长"))
    info1.append((4, "猪头呼"))

    val info2 = ListBuffer[(Int, String)]() //编号  城市
    info2.append((1, "北京"))
    info2.append((2, "上海"))
    info2.append((3, "广州"))
    info2.append((5, "深圳"))

    val data1 = env.fromCollection(info1)
    val data2 = env.fromCollection(info2)

    //内连接
    println("~~内连接~~")
    data1.join(data2).where(0).equalTo(0).apply((first, second) => {
      (first._1, first._2, second._2)
    }).print()

    //左外连接
    println("~~左外连接~~")
    data1.leftOuterJoin(data2).where(0).equalTo(0).apply((first, second) => {
      if (second == null) {
        (first._1, first._2, null)
      } else {
        (first._1, first._2, second._2)
      }
    }).print()

    //右外连接
    println("~~右外连接~~")
    data1.rightOuterJoin(data2).where(0).equalTo(0).apply((first, second) => {
      if (first == null) {
        (second._1, null, second._2)
      } else {
        (first._1, first._2, second._2)
      }
    }).print()

    //全外连接
    println("~~全外连接~~")
    data1.fullOuterJoin(data2).where(0).equalTo(0).apply((first, second) => {
      if (first == null) {
        (second._1, null, second._2)
      } else if (second == null) {
        (first._1, first._2, null)
      } else {
        (first._1, first._2, second._2)
      }
    }).print()

    //union 连接
    println("~~union连接~~")
    data1.union(data2).print()


  }
}
