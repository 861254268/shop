package com.imooc.flink.course04

import org.apache.flink.api.common.operators.Order
import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.api.scala._

import scala.collection.mutable.ListBuffer

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/15 20:52
  * @File: DataSetTransformationApp2.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: transformation函数之scala实现
  */
object DataSetTransformationApp2 {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    //    firstFunction(env)
    //    flatMapFunction(env)
    distinctFunction(env)
  }

  // transformation函数distinct之scala实现
  def distinctFunction(env: ExecutionEnvironment): Unit = {
    val info = ListBuffer[String]();
    info.append("hadoop,spark")
    info.append("hadoop,flink")
    info.append("flink,flink")

    val data = env.fromCollection(info)
    data.flatMap(_.split(",")).distinct().print()
  }


  // transformation函数flatmap之scala实现
  def flatMapFunction(env: ExecutionEnvironment): Unit = {
    val info = ListBuffer[String]()
    info.append("hadoop,spark")
    info.append("hadoop,flink")
    info.append("flink,flink")

    val data = env.fromCollection(info)
    //    data.print()
    //    data.map(_.split(",")).print() //打印出来是地址,如：[Ljava.lang.String;@2e1792e7
    data.flatMap(_.split(",")).map((_, 1)).groupBy(0).sum(1).print()
  }

  //transformation函数first之scala实现
  def firstFunction(env: ExecutionEnvironment): Unit = {
    val info = ListBuffer[(Int, String)]()
    info.append((1, "hadoop"))
    info.append((1, "spark"))
    info.append((1, "flink"))
    info.append((2, "java"))
    info.append((2, "python"))
    info.append((3, "linux"))
    info.append((3, "windows"))
    info.append((4, "VUE"))

    val data = env.fromCollection(info)
    //    data.first(3).print()
    //    data.groupBy(0).first(2).print()
    data.groupBy(0).sortGroup(1, Order.DESCENDING).first(2).print()
  }

}

