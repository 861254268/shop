package com.imooc.flink.course02;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: 180867
 * @Create Time: 2021/7/13 14:35
 * @File: BatchWCJavaApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 使用Java API来开发flink的批处理应用程序。
 */

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;

public class BatchWCJavaApp {
    public static void main(String[] args) throws Exception {
        String input = "D:\\SourceCode2020\\FlinkDemo\\imooc\\input";
//        String input= "D:\\Spark\\flink-train-java\\src\\main\\java\\com\\imooc\\flink\\java\\course02\\input";

        // step1：获取运行/执行环境
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        // step2：read data
        DataSource<String> text = env.readTextFile(input);
        text.print();
        // step3：transform

        text.flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
            // 快捷键： alt+shift+enter
            @Override
            public void flatMap(String value, Collector<Tuple2<String, Integer>> collector) throws Exception {
                String[] tokens = value.toLowerCase().split("\t");
                for (String token : tokens) {
                    if (token.length() > 0) {
                        collector.collect(new Tuple2<String, Integer>(token, 1));
                    }
                }

            }
        }).groupBy(0).sum(1).print();
    }

}
