package com.imooc.flink.course03;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/11 11:39
 * @File: StreamWCJavaApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 使用Java API来开发flink的实时处理应用程序。
 * <p>
 * 指定key之key选择器函数
 * <p>
 * WC统计的数据我们源自于socket
 */
public class StreamWCJavaApp4 {
    public static void main(String[] args) throws Exception {
        // step1：获取执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        //step2：读取数据
        DataStreamSource<String> text = env.socketTextStream("localhost", 9999);

        //step3：transform
        // 指定转换函数 Rich function
        text.flatMap(new RichFlatMapFunction<String, WC>() {
            public void flatMap(String value, Collector<WC> collector) throws Exception {
                String[] tokens = value.toLowerCase().split(",");
                for (String token : tokens) {
                    if (token.length() > 0) {
                        collector.collect(new WC(token.trim(), 1));
                        // token.trim()：键去空格
                    }
                }
            }
        })
//                .keyBy("word")
                .keyBy(new KeySelector<WC, String>() {

                    @Override
                    public String getKey(WC wc) throws Exception {
                        return wc.word;
                    }
                })
                .timeWindow(Time.seconds(5))
                .sum("count").print()
                .setParallelism(1);

        // 执行
        env.execute("SreeamWCJavaApp4");
    }


    public static class MyFlatMapFunction implements FlatMapFunction<String, WC> {

        @Override
        public void flatMap(String value, Collector<WC> collector) throws Exception {
            String[] tokens = value.toLowerCase().split(",");
            for (String token : tokens) {
                if (token.length() > 0) {
                    collector.collect(new WC(token.trim(), 1));
                    // token.trim()：键去空格
                }
            }
        }
    }

    public static class WC {
        private String word;
        private long count;


        // 构造器，构造方法
        //构造无参的构造器

        public WC() {
        }


        public WC(String word, long count) {
            this.word = word;
            this.count = count;
        }

        @Override
        public String toString() {
            return "WC{" +
                    "word='" + word + '\'' +
                    ", count=" + count +
                    '}';
        }

        public String getWord() {
            return word;
        }

        public void setWord(String word) {
            this.word = word;
        }

        public long getCount() {
            return count;
        }

        public void setCount(long count) {
            this.count = count;
        }
    }

}