package com.imooc.flink.course05;

import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/17 23:19
 * @File: JavaCustomRichParallelSourceFunction.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class JavaCustomRichParallelSourceFunction extends RichParallelSourceFunction<Long> {
    // rich是抽象类
    boolean isRunning = true;
    long count = 0L;

    @Override
    public void run(SourceContext<Long> ctx) throws Exception {
        while (isRunning) {
            ctx.collect(count);
            count += 1;
            Thread.sleep(500);
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
    }

    @Override
    public void close() throws Exception {
        super.close();
    }
}
