package com.imooc.flink.hbase;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/26 20:28
 * @File: JavaPKHBaseSink.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class JavaPKHBaseSink {
    public static void main(String[] args) {
        System.out.println("请看Scala代码的实现，后期会进行java的实现......");
    }
}
