package com.imooc.flink.course04;

import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.core.fs.FileSystem;

import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/15 20:34
 * @File: JavaDataSetSinkApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: sink 函数之java实现
 */
public class JavaDataSetSinkApp {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        List<Integer> list = new ArrayList<Integer>();
        for (int i = 1; i <= 10; i++) {
            list.add(i);
        }
        DataSource<Integer> data = env.fromCollection(list);

//        String filePath = "F:\\study\\Flink\\imooc\\out\\sink-out-java";
        String filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\out\\sink-out-java";
        // 如果并行度为1，则生成一个名为sink-out-java的文件；如果并行度大于1，则生成一个名为sink-out-java的文件夹。
        data.writeAsText(filePath, FileSystem.WriteMode.OVERWRITE).setParallelism(2);
        env.execute("JavaDataSetSinkApp");
    }
}



