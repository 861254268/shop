package com.imooc.flink.course04;

import org.apache.flink.api.common.operators.Order;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple2;

import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/15 19:59
 * @File: JavaDataSetTransaformationApp4.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: transformation函数first之java实现
 */
public class JavaDataSetTransaformationApp4 {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        firstFunction(env);
    }

    public static void firstFunction(ExecutionEnvironment env) throws Exception {
        List<Tuple2<Integer, String>> info = new ArrayList<Tuple2<Integer, String>>();
        info.add(new Tuple2(1, "hadoop"));
        info.add(new Tuple2(1, "spark"));
        info.add(new Tuple2(1, "flink"));
        info.add(new Tuple2(2, "java"));
        info.add(new Tuple2(2, "python"));
        info.add(new Tuple2(3, "linux"));
        info.add(new Tuple2(3, "windows"));
        info.add(new Tuple2(4, "VUE"));

        DataSource<Tuple2<Integer, String>> data = env.fromCollection(info);
        data.first(3).print();
        System.out.println("~~~~~~~~~~");
        data.groupBy(0).first(2).print();
        System.out.println("~~~~~~~~~~");
        data.groupBy(0).sortGroup(1, Order.DESCENDING).first(2).print();
    }
}

