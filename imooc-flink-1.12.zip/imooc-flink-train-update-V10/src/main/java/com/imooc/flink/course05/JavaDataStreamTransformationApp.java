package com.imooc.flink.course05;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/17 23:36
 * @File: JavaDataStreamTransformationApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: transformation函数map和filter之java实现
 */
public class JavaDataStreamTransformationApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//        filterFunction(env);
        unionFunction(env);

        env.execute("JavaDataStreamTransformationApp");
    }

    public static void unionFunction(StreamExecutionEnvironment env) {
        SingleOutputStreamOperator<Long> data1 = env.addSource(new JavaCustomNonParallelSourceFunction()).map(new MapFunction<Long, Long>() {
            @Override
            public Long map(Long value) throws Exception {
                return value * 2;
            }
        }).setParallelism(1);

        SingleOutputStreamOperator<Long> data2 = env.addSource(new JavaCustomNonParallelSourceFunction()).map(new MapFunction<Long, Long>() {
            @Override
            public Long map(Long value) throws Exception {
                return value * 3;
            }
        }).setParallelism(1);

        data1.union(data2).print().setParallelism(1);


    }

    public static void filterFunction(StreamExecutionEnvironment env) {
        DataStreamSource<Long> data = env.addSource(new JavaCustomNonParallelSourceFunction()).setParallelism(1);
        data.map(new MapFunction<Long, Long>() {
            @Override
            public Long map(Long value) throws Exception {
                System.out.println("recived: " + value);
                return value;
            }
        }).filter(new FilterFunction<Long>() {
            @Override
            public boolean filter(Long value) throws Exception {
                return value % 2 == 0;
            }
        }).print().setParallelism(1);
    }
}
