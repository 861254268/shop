package com.imooc.flink.course08;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/22 23:01
 * @File: JavaKafkaConnectorConsumerApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: flink对接kafka作为Source使用
 */
public class JavaKafkaConnectorConsumerApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        String topic = "test1";
        Properties properties = new Properties();

        //hadoop000 必须要求你的idea这台机器的hostname和ip的映射关系必须要配置
        //    properties.setProperty("bootstrap.servers","192.168.199.233:9092")
        properties.setProperty("bootstrap.servers", "localhost:9092");
        properties.setProperty("group.id", "test");
        DataStreamSource<String> data = env.addSource(new FlinkKafkaConsumer<String>(topic, new SimpleStringSchema(), properties));
        data.print();

        env.execute("JavaKafkaConnectorConsumerApp");
    }
}
