package com.imooc.flink.course04;

import org.apache.flink.api.java.ExecutionEnvironment;

import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/13 21:08
 * @File: JavaDataSetDataSourceApp2.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 从文件或者文件夹创建dataset
 */
public class JavaDataSetDataSourceApp2 {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
//        fromCollection(env);
        textFile(env);
    }

    public static void csvFile() {

    }

    public static void textFile(ExecutionEnvironment env) throws Exception {
        //    String filePath = "file:///User/rocky/data/04/hello.txt"
//        String filePath="F:\\study\\Flink\\imooc\\words.txt";
//        String filePath="F:\\study\\Flink\\imooc\\flink-train\\note";
        String filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\note";
        env.readTextFile(filePath).print();
    }

    public static void fromCollection(ExecutionEnvironment env) throws Exception {
        List<Integer> list = new ArrayList<Integer>();
        for (int i = 1; i <= 10; i++) {
            list.add(i);
        }
        env.fromCollection(list).print();
    }

}
