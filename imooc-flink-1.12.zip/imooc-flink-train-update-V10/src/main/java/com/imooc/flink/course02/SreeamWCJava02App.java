package com.imooc.flink.course02;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/11 11:40
 * @File: SreeamWCJava02App.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 使用Java API来开发flink的实时处理应用程序。
 *
 * WC统计的数据我们源自于socket
 */
public class SreeamWCJava02App {

    public static void main(String[] args) throws Exception {
        // 获取参数
        int port = 0;
        // 异常处理
        try {
            ParameterTool tool = ParameterTool.fromArgs(args);
            port = tool.getInt("port");
        } catch (Exception e) {
            System.err.println("端口未设置，使用默认端口9999");
            port = 9999;
        }

        // step1：获取执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        //step2：读取数据
        DataStreamSource<String> text = env.socketTextStream("localhost", port);

        //step3：transform
        text.flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public void flatMap(String value, Collector<Tuple2<String, Integer>> collector) throws Exception {
                String[] tokens = value.toLowerCase().split(",");
                for (String token : tokens) {
                    if (token.length() > 0) {
                        collector.collect(new Tuple2<String, Integer>(token, 1));
                    }
                }

            }
        }).keyBy(0).timeWindow(Time.seconds(5)).sum(1).print().setParallelism(1);
        // 设置并行度为1：setParallelism(1)

        // 执行
        env.execute("SreeamWCJavaApp");
    }
}
