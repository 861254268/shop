package com.imooc.flink.course05;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/17 11:30
 * @File: JavaDataStreamSourceApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 从Socket创建datastream之java实现
 */
public class JavaDataStreamSourceApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> textStream = env.socketTextStream("localhost", 9999);

//        socketFunction(env);
//        nonParallelSourceFunction(env);
//        parallelSourceFunction(env);
        richParallelSourceFunction(env);

        env.execute("JavaDataStreamSourceApp");

    }

    public static void richParallelSourceFunction(StreamExecutionEnvironment env) {
        DataStreamSource<Long> data = env.addSource(new JavaCustomRichParallelSourceFunction()).setParallelism(2);
        data.print().setParallelism(1);
    }

    public static void parallelSourceFunction(StreamExecutionEnvironment env) {
        DataStreamSource<Long> data = env.addSource(new JavaCustomParallelSourceFunction()).setParallelism(2);
        data.print().setParallelism(1);
    }


    public static void nonParallelSourceFunction(StreamExecutionEnvironment env) {
        DataStreamSource<Long> data = env.addSource(new JavaCustomNonParallelSourceFunction()).setParallelism(1);
        data.print().setParallelism(1);

    }

    // 从Socket创建datastream之java实现
    public static void socketFunction(StreamExecutionEnvironment env) {
        System.out.println("~~~~~~~~~~~~~~~~~~~从此处开始学习.......~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        DataStreamSource<String> data = env.socketTextStream("localhost", 9999);
        // data.setParallelism(1).print();
        // 两种方式输出效果是不一样的
        data.print().setParallelism(1);

    }
}