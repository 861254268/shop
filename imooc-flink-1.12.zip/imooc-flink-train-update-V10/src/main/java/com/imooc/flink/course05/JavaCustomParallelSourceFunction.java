package com.imooc.flink.course05;

import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/17 23:17
 * @File: JavaCustomParallelSourceFunction.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 自定义并行SourceFunction
 */
public class JavaCustomParallelSourceFunction implements ParallelSourceFunction<Long> {
    boolean isRunning = true;
    long count = 0L;

    @Override
    public void run(SourceContext<Long> ctx) throws Exception {
        while (isRunning) {
            ctx.collect(count);
            count += 1;
            Thread.sleep(500);
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }
}
