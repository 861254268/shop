package com.imooc.flink.course02;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: 180867
 * @Create Time: 2021/7/13 14:45
 * @File: SreeamWCJavaApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class SreeamWCJavaApp {
    public static void main(String[] args) {
        System.out.println("yep!");
    }
}
