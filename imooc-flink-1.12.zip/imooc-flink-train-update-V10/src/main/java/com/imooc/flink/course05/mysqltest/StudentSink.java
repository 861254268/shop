package com.imooc.flink.course05.mysqltest;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/18 13:46
 * @File: StudentSink.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class StudentSink {
    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        //并行度为1
        env.setParallelism(1);

        List<Studentt> list = new ArrayList<Studentt>();
        list.add(new Studentt("aaa", 11));
        list.add(new Studentt("bbb", 12));
        list.add(new Studentt("ccc", 13));
        list.add(new Studentt("ddd", 14));
        list.add(new Studentt("eee", 15));
        list.add(new Studentt("fff", 16));

        env.fromCollection(list)
                .addSink(new MySQLSinkFunction())
                .disableChaining();

        env.execute("sink demo : customize mysql obj");
    }
}