package com.imooc.flink.course05;

import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/18 13:34
 * @File: SinkToMySQL.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 自定义MySQL Sink
 * <p>
 * 自定义sink总结：
 * 1） RichSinkFunction<T> T就是你想要写入对象的类型</>
 * 2） 重写方法
 * open/close  生命周期方法
 * invoke      每条记录执行一次
 */

public class SinkToMySql extends RichSinkFunction<Student>{

    Connection connection;
    PreparedStatement pstmt;


    private Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3306/imooc_flink";

            conn = DriverManager.getConnection(url,"root","123456");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;
    }

    /**
     * 在open方法中建立connection
     * @param parameters
     * @throws Exception
     */
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        connection = getConnection();
        String sql = "insert into student(id,name,age) values (?,?,?)";
        pstmt = connection.prepareStatement(sql);


        System.out.println("open");

    }

    // 每条记录插入时调用一次
    public void invoke(Student value, Context context) throws Exception {
        System.out.println("invoke~~~~~~~~~");
        // 未前面的占位符赋值
        pstmt.setInt(1, value.getId());
        pstmt.setString(2, value.getName());
        pstmt.setInt(3, value.getAge());

        pstmt.executeUpdate();

    }

    /**
     * 在close方法中要释放资源
     * @throws Exception
     */
    @Override
    public void close() throws Exception {
        super.close();

        if(pstmt != null) {
            pstmt.close();
        }

        if(connection != null) {
            connection.close();
        }
    }
}

//public class SinkToMySql extends RichSinkFunction<Student> {
//
//    PreparedStatement preparedStatement;
//
//    private Connection connection;
//
//    private ReentrantLock reentrantLock = new ReentrantLock();
//
//    /**
//     * 在open方法中建立connection
//     *
//     * @param parameters
//     * @throws
//     */
//
//    @Override
//    public void open(Configuration parameters) throws Exception {
//        super.open(parameters);
//
//        //准备数据库相关实例
//        buildPreparedStatement();
//    }
//
//    @Override
//    public void close() throws Exception {
//        super.close();
//
//        try {
//            if (null != preparedStatement) {
//                preparedStatement.close();
//                preparedStatement = null;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        try {
//            if (null != connection) {
//                connection.close();
//                connection = null;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public void invoke(Student value, Context context) throws Exception {
//        preparedStatement.setString(1, value.getName());
//        preparedStatement.setInt(2, value.getAge());
//        preparedStatement.executeUpdate();
//    }
//
//    /**
//     * 准备好connection和preparedStatement
//     * 获取mysql连接实例，考虑多线程同步，
//     * 不用synchronize是因为获取数据库连接是远程操作，耗时不确定
//     *
//     * @return
//     */
//    private void buildPreparedStatement() {
//        if (null == connection) {
//            boolean hasLock = false;
//            try {
//                hasLock = reentrantLock.tryLock(10, TimeUnit.SECONDS);
//
//                if (hasLock) {
//                    Class.forName("com.mysql.jdbc.Driver");
//                    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/imooc_flink?useUnicode=true&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC", "root", "123456");
//                }
//
//                if (null != connection) {
//                    preparedStatement = connection.prepareStatement("insert into student (name, age) values (?, ?)");
//                }
//            } catch (Exception e) {
//                //生产环境慎用
//                e.printStackTrace();
//            } finally {
//                if (hasLock) {
//                    reentrantLock.unlock();
//                }
//            }
//        }
//    }
//}