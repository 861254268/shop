package com.imooc.flink.course05;

import org.apache.flink.streaming.api.functions.source.SourceFunction;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/17 23:10
 * @File: JavaCustomNonParallelSourceFunction.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 自定义非并行的SourceFunction
 */
public class JavaCustomNonParallelSourceFunction implements SourceFunction<Long> {
    boolean isRunning = true;
    long count = 0L;

    @Override
    public void run(SourceContext<Long> ctx) throws Exception {
        while (isRunning) {
            ctx.collect(count);
            count += 1;
            Thread.sleep(500);
        }

    }

    @Override
    public void cancel() {
        isRunning = false;
    }
}
