package com.imooc.flink.course08;


import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer;
import org.apache.flink.streaming.connectors.kafka.internals.KeyedSerializationSchemaWrapper;
//import org.apache.flink.streaming.util.serialization.KeyedSerializationSchemaWrapper;

import java.util.Properties;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/22 23:11
 * @File: JavaKafkaConnectorProducerApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: flink对接kafka作为sink使用
 */
public class JavaKafkaConnectorProducerApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // 从socket接收数据，通过flink，将数据sink到kafka
        DataStreamSource<String> data = env.socketTextStream("localhost", 9999);

        String topic = "test1";
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");

        FlinkKafkaProducer<String> kafkaSink = new FlinkKafkaProducer<String>(topic, new KeyedSerializationSchemaWrapper<String>(new SimpleStringSchema()), properties);
        data.addSink(kafkaSink).setParallelism(2);
        env.execute("JavaKafkaConnectorProducerApp");
    }
}
