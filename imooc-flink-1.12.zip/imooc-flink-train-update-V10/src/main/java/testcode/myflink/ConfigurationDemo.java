package testcode.myflink;

import org.apache.flink.api.common.functions.RichFilterFunction;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.configuration.Configuration;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/31 0:02
 * @File: ConfigurationDemo.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Configuration类来存储参数
 */
public class ConfigurationDemo {
    public static void main(String[] args) throws Exception {

        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();

        DataSource<Integer> input = env.fromElements(1, 2, 3, 5, 10, 12, 15, 16);
        // Configuration类来存储参数
        Configuration configuration = new Configuration();
        configuration.setInteger("limit", 5);
        input.filter(new RichFilterFunction<Integer>() {
            private int limit;

            @Override
            public void open(Configuration configuration) throws Exception {
                limit = configuration.getInteger("limit", 0);
            }

            @Override
            public boolean filter(Integer value) throws Exception {
                return value > limit;
            }
        }).withParameters(configuration)
                .print();
    }
}