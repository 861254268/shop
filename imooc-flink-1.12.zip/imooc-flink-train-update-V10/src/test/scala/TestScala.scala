/**
  * Author: Michael PK
  */
object TestScala {

  def main(args: Array[String]): Unit = {
    println("hello scala....")
  }

}
