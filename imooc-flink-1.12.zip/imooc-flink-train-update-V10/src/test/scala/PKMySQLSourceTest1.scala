//import com.imooc.flink.project.PKMySQLSource
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/8 16:36
  * @File: PKMySQLSourceTest1.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
//object PKMySQLSourceTest1 {
//  def main(args: Array[String]): Unit = {
//    val env = StreamExecutionEnvironment.getExecutionEnvironment
//    val data = env.addSource(PKMySQLSource).setParallelism(1)
//    data.print()
//    env.execute("PKMySQLSourceTest1")
//  }
//}
