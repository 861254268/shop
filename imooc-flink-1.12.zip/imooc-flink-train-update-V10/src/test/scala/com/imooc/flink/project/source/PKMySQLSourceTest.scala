//package com.imooc.flink.project.source
//
//import com.imooc.flink.project.PKMySQLSource
//import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
//import org.apache.flink.api.scala._
//// import com.imooc.flink.project.PKMySQLSource

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/8 16:39
  * @File: PKMySQLSourceTest.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: MySQL测试
  */
object PKMySQLSourceTest {
  def main(args: Array[String]): Unit = {
//    val env = StreamExecutionEnvironment.getExecutionEnvironment
//    val data=env.addSource(new PKMySQLSource)
//    env.execute("PKMySQLSourceTest")
  }
}
