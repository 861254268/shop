package com.imooc.flink.project.source

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/9 22:59
  * @File: StreamTest.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: test
  */
object StreamTest {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val stream = env.socketTextStream("localhost", 9999)
    stream.print()
    env.execute()
  }

}
