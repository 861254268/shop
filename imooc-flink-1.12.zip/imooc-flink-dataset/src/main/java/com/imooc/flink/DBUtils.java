package com.imooc.flink;

import java.util.Random;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 19:34
 * @File: DBUtils.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class DBUtils {
    public static String getConnection() {
        return new Random().nextInt(100)+"";
    }
    public static void releaseConnection(String connection) {
    }

}
