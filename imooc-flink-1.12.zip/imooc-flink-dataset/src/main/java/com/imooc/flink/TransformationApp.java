package com.imooc.flink;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.MapPartitionFunction;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.util.Collector;

import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 19:40
 * @File: TransformationApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: transformation函数之map/mapPartition
 */
public class TransformationApp {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();

        DataSet<Long> ds = env.generateSequence(1, 36).setParallelism(2);
        ds.mapPartition(new MyMapPartitionFunction()).print();

        // ------------------------
        List<String> list = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            list.add("student:" + i);
        }

        DataSource<String> data = env.fromCollection(list).setParallelism(5);

        // System.out.println("并行度：" + data.getParallelism());    // 默认并行度为1
        data.mapPartition(new MapPartitionFunction<String, String>() {
            @Override
            public void mapPartition(Iterable<String> values, Collector<String> out) throws Exception {
                String connection = DBUtils.getConnection();
                System.out.println("connection:" + connection);  // 输出一个connection

                // TODO... 业务逻辑处理

                DBUtils.releaseConnection(connection);
            }
        }); //.print();
        // -----------------------------


        // 该需求小量数据map()是可以的，如果数据量很大是不行的。需要使用mapPartition()
        data.map(new MapFunction<String, String>() {
            /**
             * 假设：进来一条数据，要与业务库中的数据进行相关操作
             * Connection
             * */
            @Override
            public String map(String value) throws Exception {
                String connection = DBUtils.getConnection();
                System.out.println("connection:" + connection); // 输出100个connection

                // TODO... 业务逻辑处理

                DBUtils.releaseConnection(connection);
                return value;
            }
        }); //.print();


    }

    public static class MyMapPartitionFunction implements MapPartitionFunction<Long, Long> {
        @Override
        public void mapPartition(Iterable<Long> values, Collector<Long> out) throws Exception {
            long count = 0;
            for (Long value : values) {
                count++;
            }
            out.collect(count);
        }
    }
}
