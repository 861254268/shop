package com.imooc.flink;

import org.apache.commons.io.FileUtils;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.configuration.Configuration;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 19:35
 * @File: DistributedCacheApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 基于flink的分布式缓存(DistributedCache)功能的java实现
 */
public class DistributedCacheApp {
    public static <list> void main(String[] args) throws Exception {


        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();

        // 把对应的数据注册到分布式缓存中
        String filePath = "data/wc.txt";
        // step1：注册一个本地/HDFS文件
        env.registerCachedFile(filePath, "pk-wc-dc");

        DataSource<String> data = env.fromElements("hadoop", "spark", "storm", "flink", "pyspark");

        data.map(new RichMapFunction<String, String>() {
            List<String> list = new ArrayList<String>();

            // 在open()方法中如何去获取到分布式缓存中的数据
            @Override
            public void open(Configuration parameters) throws Exception {
                // super.open(parameters);
                File file = getRuntimeContext().getDistributedCache().getFile("pk-wc-dc");
                //List<String> lines = FileUtils.readLines(file);
                List<String> lines = FileUtils.readLines(file, Charset.defaultCharset());

                // 增强for循环
                for (String line : lines) {
                    list.add(line);
                    System.out.println("line = [" + line + "]");
                }
                // System.out.println(list);

            }

            @Override
            public String map(String value) throws Exception {
                return value;
            }
        }).print();

    }
}
