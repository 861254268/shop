package com.imooc.flink;

import org.apache.flink.api.common.JobExecutionResult;
import org.apache.flink.api.common.accumulators.LongCounter;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.core.fs.FileSystem;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 19:29
 * @File: CounterApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 基于flink编程的计数器之java实现
 * <p>
 * Flink中计数器/累加器的使用
 * MR、Spark
 */
public class CounterApp {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        DataSource<String> data = env.fromElements("hadoop", "spark", "storm", "flink", "pyspark");

        /**
         * 要实现一个ETL的功能：
         * 数据清洗：ip=>省份 、地市、运营商之类    一个字段拆分成多个字段
         *
         * 数据类型的转换：
         * 流量   关键的字段，必须是一个数值类型。
         * 但是有可能进来的是字符串类型，需要转换成数值类型的才可以。
         *
         * */

        DataSet<String> info = data.map(new RichMapFunction<String, String>() {
            LongCounter counter = new LongCounter();

            @Override
            public void open(Configuration parameters) throws Exception {
                super.open(parameters);

                getRuntimeContext().addAccumulator("ele-counts-java", counter);
            }

            @Override
            public String map(String value) throws Exception {
                /**
                 * TODO... 数据清洗功能　&　计数功能
                 *
                 * 很有可能遇到不符合規則的數據
                 * */
                counter.add(1);

//                try {
//
//                } catch {
//                    // 记录错误数据的计数器+1
//                }

                return value;
            }
        });

        String filePath = "data/out";
        info.writeAsText(filePath, FileSystem.WriteMode.OVERWRITE).setParallelism(3);
        // env.execute("CounterApp");
        JobExecutionResult jobResult = env.execute("CounterApp");

        // step:获取计数器
        long num = jobResult.getAccumulatorResult("ele-counts-java");

        System.out.println("num: " + num);

    }
}
