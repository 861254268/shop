package com.imooc.flink;

import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.io.CsvReader;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;


/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/25 22:43
 * @File: SourceApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class SourceApp {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        // readCSV(env);
        // readCompress(env);  // 读压缩文件
        readSubPath(env);   // 遍历子目录的数据

    }

    public static void readSubPath(ExecutionEnvironment env) throws Exception {
        Configuration configuration = new Configuration();
        configuration.setBoolean("recursive.file.enumeration", true);

        DataSource<String> source = env.readTextFile("data/nest");
        source.withParameters(configuration).print();

    }

    public static void readCompress(ExecutionEnvironment env) throws Exception {
        // DataSource<String> source = env.readTextFile("data/wc.txt");
        // codec
        DataSource<String> source = env.readTextFile("data/wc.txt.gz");
        source.print();

    }

    public static void readCSV(ExecutionEnvironment env) throws Exception {
        CsvReader csvReader = env.readCsvFile("data/people.csv");
        DataSource<Tuple3<String, Integer, String>> source = csvReader
                .fieldDelimiter(";")   // 列指定分隔符
                .ignoreFirstLine()     // 忽略首行
                .types(String.class, Integer.class, String.class);
        source.print();
    }
}
