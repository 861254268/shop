package com.imooc.flink;

import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.util.NumberSequenceIterator;

import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 19:37
 * @File: SinkApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Sink
 * <p>
 * 其实写入的到底是文件还是文件夹是与并行度有很大关系的
 */
public class SinkApp {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        List<Integer> data = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            data.add(i);
        }

        // DataSource<Integer> source = env.fromCollection(data);
        // // 一般写入的out是个文件夹，flink中out却是个文件
        // // System.out.println(source.getParallelism());   // 1
        // source.writeAsText("out");

        env.setParallelism(2);
        DataSource<Long> source = env.fromParallelCollection(new NumberSequenceIterator(1, 20), Long.class);
        // 此时写入的out是文件夹
        source.writeAsText("out1", FileSystem.WriteMode.OVERWRITE);
        // FileSystem.WriteMode.OVERWRITE：文件存在就重写

        // 此处的env.execute()需要特别注意
        env.execute("SinkApp");
    }
}
