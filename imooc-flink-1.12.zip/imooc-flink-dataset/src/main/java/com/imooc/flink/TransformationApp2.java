package com.imooc.flink;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.operators.Order;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.operators.FlatMapOperator;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;

import java.util.ArrayList;
import java.util.List;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/26 19:42
 * @File: TransformationApp2.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: transformation函数之distinct/first_n
 */
public class TransformationApp2 {
    public static void main(String[] args) throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        // distinct(env);
        firstNFunction(env);

    }

    public static void firstNFunction(ExecutionEnvironment env) throws Exception {
        List<Tuple2<Integer, String>> info = new ArrayList<Tuple2<Integer, String>>();
        info.add(new Tuple2(1, "hadoop"));
        info.add(new Tuple2(1, "spark"));
        info.add(new Tuple2(1, "flink"));
        info.add(new Tuple2(2, "java"));
        info.add(new Tuple2(2, "python"));
        info.add(new Tuple2(3, "linux"));
        info.add(new Tuple2(3, "windows"));
        info.add(new Tuple2(4, "VUE"));

        DataSource<Tuple2<Integer, String>> data = env.fromCollection(info);
        System.out.println("~~~~~first-n~~~~~");
        data.first(3).print();
        System.out.println("~~~~~group==>first-n~~~~~");
        data.groupBy(0).first(2).print();
        System.out.println("~~~~~group==>sort==>first-n~~~~~");
        data.groupBy(0).sortGroup(1, Order.DESCENDING).first(2).print();
    }

    public static void distinct(ExecutionEnvironment env) throws Exception {
        List<String> list = new ArrayList<>();
        list.add("hadoop,spark");
        list.add("hadoop,flink");
        list.add("flink,flink");

        DataSource<String> data = env.fromCollection(list);
        FlatMapOperator<String, String> flatMapSource = data.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public void flatMap(String value, Collector<String> out) throws Exception {
                String[] splits = value.split(",");
                for (String split : splits) {
                    out.collect(split);
                }
            }
        });
        flatMapSource.distinct().print();

    }
}
