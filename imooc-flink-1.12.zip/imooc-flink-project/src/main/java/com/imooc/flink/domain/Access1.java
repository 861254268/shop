package com.imooc.flink.domain;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/19 19:36
 * @File: Access1.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:用戶行为日志类定义 <p>
 * POJO类
 */
public class Access1 {
    private String table;
    private String current_ts;
    private String pos;

    public Access1() {
    }

    public Access1(String table, String current_ts, String pos) {
        this.table = table;
        this.current_ts = current_ts;
        this.pos = pos;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public String getCurrent_ts() {
        return current_ts;
    }

    public void setCurrent_ts(String current_ts) {
        this.current_ts = current_ts;
    }

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }

    @Override
    public String toString() {
        return "Access1{" +
                "table='" + table + '\'' +
                ", current_ts='" + current_ts + '\'' +
                ", pos='" + pos + '\'' +
                '}';
    }
}
