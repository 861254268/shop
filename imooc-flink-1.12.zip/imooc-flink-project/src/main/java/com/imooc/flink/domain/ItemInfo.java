package com.imooc.flink.domain;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/28 22:07
 * @File: ItemInfo.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Item数据
 */
public class ItemInfo {
    public int itemId;
    public String orderId; // 作为join的条件
    public long time;
    public String sku;
    public double amount;
    public double money;

    @Override
    public String toString() {
        return "ItemInfo{" +
                "itemId=" + itemId +
                ", orderId='" + orderId + '\'' +
                ", time=" + time +
                ", sku='" + sku + '\'' +
                ", amount=" + amount +
                ", money=" + money +
                '}';
    }
}
