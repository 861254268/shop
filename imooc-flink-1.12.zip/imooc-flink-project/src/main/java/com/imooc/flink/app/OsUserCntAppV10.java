package com.imooc.flink.app;

import com.alibaba.fastjson.JSONObject;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/19 19:32
 * @File: OsUserCntAppV10.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:  按照操作系统维度进行新老用户的统计分析
 * <p>
 *  此处使用json格式数据进行处理
 */
public class OsUserCntAppV10 {

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // 该段代码需要后续进行进一步的验证才能使用
        DataStream<String> mapStream = env.readTextFile("data/acc.json")
                .map(new MapFunction<String, String>() {
                    @Override
                    public String map(String value) throws Exception {
                        JSONObject jsonObject = JSONObject.parseObject(value);
                        String city_id = jsonObject.getString("city_id");
                        String code_full = jsonObject.getString("code_full");
                        return city_id + "==>" + code_full;
                    }
                });
        mapStream.print();

        env.execute("OsUserCntAppV10");
    }
}