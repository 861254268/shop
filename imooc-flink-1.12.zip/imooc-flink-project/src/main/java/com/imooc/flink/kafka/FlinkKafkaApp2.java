package com.imooc.flink.kafka;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.util.Collector;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/20 21:00
 * @File: FlinkKafkaApp2.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Flink对接Kafka数据入门
 */
public class FlinkKafkaApp2 {
    public static void main(String[] args) throws Exception {
//      // D:\SourceCode2020\FlinkDemo\coding510-learn\pk.properties
//        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//
//        ParameterTool tool = ParameterTool.fromPropertiesFile(args[0]);
//        String groupId = tool.get("group.id", "test");
//        String servers = tool.getRequired("bootstrap.servers");
//        List<String> topics = Arrays.asList(tool.getRequired("kafka.input.topics").split(","));
//        String autoCommit = tool.get("enable.auto.commit", "false");
//        String offsetReset = tool.get("auto.offset.reset", "earliest");
//
//        // kafka相关参数
//        Properties properties = new Properties();
//        properties.setProperty("bootstrap.servers", servers);
//        properties.setProperty("group.id", groupId);
//        properties.setProperty("enable.auto.commit", autoCommit);  // 不让自动提交
//        properties.setProperty("auto.offset.reset", offsetReset);
//        // String topic = "test1";


        //
//        FlinkKafkaConsumer<String> kafkaConsumer = new FlinkKafkaConsumer<>(topics, new SimpleStringSchema(), properties);
//        //DataStream<String> stream =
//        SingleOutputStreamOperator<Tuple2<String, Integer>> stream = env.addSource(kafkaConsumer)
//                .flatMap(new FlatMapFunction<String, String>() {
//                    @Override
//                    public void flatMap(String value, Collector<String> out) throws Exception {
//                        String[] splits = value.split(",");
//                        for (String split : splits) {
//                            out.collect(split);
//                        }
//                    }
//                })
//                .map(new MapFunction<String, Tuple2<String, Integer>>() {
//                    @Override
//                    public Tuple2<String, Integer> map(String value) throws Exception {
//                        return Tuple2.of(value, 1);
//                    }
//                })
//                .keyBy(x -> x.f0)
//                .sum(1);
//        stream.print("wc统计;");
//
//        int checkpointInterval = tool.getInt("checkpoint.interval", 5000);
//        String checkpointPath = tool.get("checkpoint.path", "file:///F:/study/Flink/coding510-learn/imooc-flink/state");
//
//        // checkpoint相关参数
//        env.enableCheckpointing(checkpointInterval);
//        env.setStateBackend(new FsStateBackend(checkpointPath));
//        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
//        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(2, Time.of(5, TimeUnit.SECONDS)));


        ParameterTool tool = ParameterTool.fromPropertiesFile(args[0]);
        DataStream<String> kafkaStreamV1 = FlinkUtils.createKafkaStreamV1(tool);
        kafkaStreamV1.print();

        FlinkUtils.env.execute();
//        test01(env);
//        env.execute("FlinkKafkaApp2");
    }

    public static void test01(StreamExecutionEnvironment env) {

        //　容错
        SingleOutputStreamOperator<String> mapStream = env.socketTextStream("localhost", 9999)
                .map(new MapFunction<String, String>() {
                    @Override
                    public String map(String value) throws Exception {
                        if (value.contains("pk")) throw new RuntimeException("把PK哥拉黑。。。");
                        return value.toUpperCase();
                    }
                });
        mapStream.print("from socket(nc):");

    }
}