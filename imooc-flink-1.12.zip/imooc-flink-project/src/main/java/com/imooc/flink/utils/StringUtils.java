package com.imooc.flink.utils;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/14 20:02
 * @File: StringUtils.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class StringUtils {
    public static final String GAODE_KEY = "studying";
}
