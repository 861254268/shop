package com.imooc.flink.app;

import com.imooc.flink.domain.ItemInfo;
import com.imooc.flink.domain.OrderInfo;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.CoGroupFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

import java.time.Duration;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/28 22:13
 * @File: FlinkJoinApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 双流JOIN实现之对接数据
 */
public class FlinkJoinApp {
    /**
     * 业务数据：订单、条目   存储在数据库中
     * <p>
     * mysql ==> canal ==> kafka ==> flink
     */
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment()
                .setParallelism(1);
        // order
        SingleOutputStreamOperator<OrderInfo> orderData = env.socketTextStream("localhost", 9999)
                .map(new MapFunction<String, OrderInfo>() {
                    @Override
                    public OrderInfo map(String value) throws Exception {
                        String[] splits = value.split(",");
                        OrderInfo info = new OrderInfo();
                        info.orderId = splits[0].trim();
                        info.time = Long.parseLong(splits[1].trim());
                        info.money = Double.parseDouble(splits[2].trim());
                        return info;
                    }
                })
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy.<OrderInfo>forBoundedOutOfOrderness(Duration.ofSeconds(0)) // 延迟时间
                                .withTimestampAssigner(new SerializableTimestampAssigner<OrderInfo>() {
                                    @Override
                                    public long extractTimestamp(OrderInfo element, long recordTimestamp) {
                                        return element.time;
                                    }
                                })
                );
//        orderData.print("order:");

        // item
        SingleOutputStreamOperator<ItemInfo> itemData = env.socketTextStream("localhost", 8888)
                .map(new MapFunction<String, ItemInfo>() {
                    @Override
                    public ItemInfo map(String value) throws Exception {
                        String[] splits = value.split(",");
                        ItemInfo info = new ItemInfo();
                        info.itemId = Integer.parseInt(splits[0].trim());
                        info.orderId = splits[1].trim();
                        info.time = Long.parseLong(splits[2].trim());
                        info.sku = splits[3].trim();
                        info.amount = Double.parseDouble(splits[4].trim());
                        info.money = Double.parseDouble(splits[5].trim());
                        return info;
                    }
                })
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy.<ItemInfo>forBoundedOutOfOrderness(Duration.ofSeconds(0)) // 延迟时间
                                .withTimestampAssigner(new SerializableTimestampAssigner<ItemInfo>() {
                                    @Override
                                    public long extractTimestamp(ItemInfo element, long recordTimestamp) {
                                        return element.time;
                                    }
                                })
                );

        orderData.print("order:");
        itemData.print("item:");

        /**
         * TODO... 两个流的join操作
         *
         * item作为左边,order作为右边
         * 理想化：没有延迟
         *
         * (item,null) ==> API 查询业务库    RichXXXFunction
         * (迟到了,...) 对应于延迟到达的这种item,就丢失了...
         *      outputtag ==> item
         *      union
         * */

        DataStream<Tuple2<ItemInfo, OrderInfo>> joinStream = itemData.coGroup(orderData)
                .where(x -> x.orderId) // item
                .equalTo(y -> y.orderId)  //order
                .window(TumblingEventTimeWindows.of(Time.seconds(5)))
                .apply(new CoGroupFunction<ItemInfo, OrderInfo, Tuple2<ItemInfo, OrderInfo>>() {
                    @Override
                    public void coGroup(Iterable<ItemInfo> first, Iterable<OrderInfo> second, Collector<Tuple2<ItemInfo, OrderInfo>> out) throws Exception {
                        for (ItemInfo itemInfo : first) {
                            boolean flag = false;
                            for (OrderInfo orderInfo : second) {
                                out.collect(Tuple2.of(itemInfo, orderInfo));
                                flag = true;
                            }
                            if (!flag) {
                                out.collect(Tuple2.of(itemInfo, null));
                            }
                        }

                    }
                });
        joinStream.print();

        env.execute("FlinkJoinApp");
    }
}
