package com.imooc.flink.app;

import com.alibaba.fastjson.JSON;
import com.imooc.flink.domain.Access;
import com.imooc.flink.domain.EventCatagoryProductCount;
import com.imooc.flink.udf.TopNAggregateFunction;
import com.imooc.flink.udf.TopNWindowFunction;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.shaded.guava18.com.google.common.collect.Lists;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.util.ArrayList;
import java.util.List;


/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/17 20:08
 * @File: TopNAppV1.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 统计五分钟内的不同event(加购物车 、 浏览...)类型、类别、商品的TopN访问量
 * * <p>
 */
public class TopNAppV1 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//        env.setParallelism(1);
        SingleOutputStreamOperator<Access> cleanStream = env.readTextFile("data/access.json")
                .map(new MapFunction<String, Access>() {
                    @Override
                    public Access map(String value) throws Exception {
                        // TODO...  json ==> Access01

                        // 注意事项：一定要考虑解析的容错性
                        try {
                            return JSON.parseObject(value, Access.class);
                        } catch (Exception e) {
                            e.printStackTrace(); // 写到某个地方
                            return null;
                        }

                    }
                }).filter(x -> x != null)

                // 加上WaterMark
                .assignTimestampsAndWatermarks( // 过时的方法
                        new BoundedOutOfOrdernessTimestampExtractor<Access>(Time.seconds(20)) {
                            @Override
                            public long extractTimestamp(Access element) {
                                return element.getAt_stamp();
                            }
                        }
                )
                .filter(new FilterFunction<Access>() {
                    @Override
                    public boolean filter(Access value) throws Exception {
                        return !"Liuxiansheng".equals(value.getHz_name());
                    }
                });
        WindowedStream<Access, Tuple3<String, String, String>, TimeWindow> windowedStream = cleanStream.keyBy(new KeySelector<Access, Tuple3<String, String, String>>() {
            @Override
            public Tuple3<String, String, String> getKey(Access value) throws Exception {
                return Tuple3.of(value.getHz_name(), value.getHz_city(), value.getYunhuo_Person());
            }
        })
                .window(SlidingEventTimeWindows.of(Time.minutes(10), Time.minutes(1)));
        // 作用上WindowFunction

        SingleOutputStreamOperator<EventCatagoryProductCount> aggregateStream = windowedStream.aggregate(new TopNAggregateFunction(), new TopNWindowFunction());
//        aggregateStream.print();

        // 求TopN的过程
        SingleOutputStreamOperator<List<EventCatagoryProductCount>> Top3Result = aggregateStream.keyBy(new KeySelector<EventCatagoryProductCount, Tuple4<String, String, Long, Long>>() {
            @Override
            public Tuple4<String, String, Long, Long> getKey(EventCatagoryProductCount value) throws Exception {
                return Tuple4.of(value.hz_name, value.hz_area, value.start, value.end);
            }
        }).process(new KeyedProcessFunction<Tuple4<String, String, Long, Long>, EventCatagoryProductCount, List<EventCatagoryProductCount>>() {


            // 维护状态
            private transient ListState<EventCatagoryProductCount> listState;

            // open方法,完成初始化
            @Override
            public void open(Configuration parameters) throws Exception {
                listState = getRuntimeContext().getListState(new ListStateDescriptor<EventCatagoryProductCount>("cnt-state", EventCatagoryProductCount.class));

            }

            @Override
            public void processElement(EventCatagoryProductCount value, Context ctx, Collector<List<EventCatagoryProductCount>> out) throws Exception {
                listState.add(value);

                // 定义(注册一个)定时器
                ctx.timerService().registerEventTimeTimer(value.end + 1);

            }

            // 在这里完成TopN操作
            @Override
            public void onTimer(long timestamp, OnTimerContext ctx, Collector<List<EventCatagoryProductCount>> out) throws Exception {
                ArrayList<EventCatagoryProductCount> list = Lists.newArrayList(listState.get());

                list.sort((x, y) -> Long.compare(y.count, x.count));

                ArrayList<EventCatagoryProductCount> sorted = new ArrayList<>();

                // Top3:若list.size()不足三个，则取list.size()
                for (int i = 0; i < Math.min(3, list.size()); i++) {
                    EventCatagoryProductCount bean = list.get(i);
                    sorted.add(bean);
                }

                out.collect(sorted);
            }
        });
        Top3Result.print().setParallelism(1);
        env.execute("TopNAppV1");
    }
}
