package com.imooc.flink.ClickHouseTest;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/25 22:28
 * @File: HelloWorld.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class HelloWorld {
    public static void main(String[] args) {

        System.out.println("Mr.Jia");
    }
}
