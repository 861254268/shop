package com.imooc.flink.udf;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.imooc.flink.domain.Access01;
import com.imooc.flink.utils.StringUtils;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/14 19:59
 * @File: GaodeLocationMapFunction.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class GaodeLocationMapFunction extends RichMapFunction<Access01, Access01> {
    CloseableHttpClient httpClient;

    @Override
    public void open(Configuration parameters) throws Exception {
        httpClient = HttpClients.createDefault();

    }

    @Override
    public void close() throws Exception {
        if (httpClient != null) httpClient.close();
    }


    @Override
    public Access01 map(Access01 value) throws Exception {
        String url = "https://restapi.amap.com/v3/ip?ip=" + value.getIp() + "&output=json&key=" + StringUtils.GAODE_KEY; // value.get订单ID()该值应该是value中的ip

        CloseableHttpResponse response = null;
        String province = "-";
        String city = "-";

        try {
            HttpGet httpGet = new HttpGet();
            response = httpClient.execute(httpGet);
            int statusCode = response.getStatusLine().getStatusCode();
            if(statusCode == 200) {
                HttpEntity entity = response.getEntity();
                String result = EntityUtils.toString(entity, "UTF-8");
//                System.out.println(statusCode);
//                System.out.println(entity);
                System.out.println(result);
                JSONObject jsonObject = JSON.parseObject(result);
                province = jsonObject.getString("province");
                city = jsonObject.getString("city");
                System.out.println(province + "\t" + city);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            response.close();
            value.province = province;
            value.city = city;
        }

        return null;
    }

}