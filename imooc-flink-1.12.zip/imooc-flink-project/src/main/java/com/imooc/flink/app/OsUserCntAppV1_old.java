package com.imooc.flink.app;

import com.imooc.flink.domain.Access01;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple3;


/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/13 20:08
 * @File: OsUserCntAppV1_old.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 按照操作系统维度进行新老用户的统计分析
 * <p>
 * 由于数据源的缺失及json数据格式问题，此处使用csv/txt数据进行相应的计算和处理
 */
public class OsUserCntAppV1_old {
    public static void main(String[] args) throws Exception {

        // StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        DataSource<Access01> cleanStream = env.readCsvFile("data/access.csv")
                //fieldDelimiter设置分隔符，默认的是","
                .fieldDelimiter(",")
                //忽略第一行
                .ignoreFirstLine()
                //设置选取哪几列，这里是第2列不选取的。
                //.includeFields(true, false, true)
                //pojoType和后面字段名，就是对应列。字段名是不需要对应原始文件header字段名，
                //但必须与POJO里的字段名一一对应
                .pojoType(Access01.class, "订单ID", "bi_xddt", "bi_fhdt", "运货商", "货主名称", "bi_dept", "bi_areaname", "货主城市", "tdsct091_oqua");
//        cleanStream.print();
        // TODO ... 操作系统维度 新老用户 ==>　wc
        cleanStream.map(new MapFunction<Access01, Tuple3<String, String, Integer>>() {

            @Override
            public Tuple3<String, String, Integer> map(Access01 value) throws Exception {
                return Tuple3.of(value.getBi_dept(), value.get货主名称(), 1);
            }
        }).print();

    }

/**
 * 该段代码需要后续进行进一步的验证才能使用
 * SingleOutputStreamOperator<Access01> cleanStream = env.readTextFile("data/regions.json")
 * .map(new MapFunction<String, Access01>() {
 *
 * @Override public Access01 map(String value) throws Exception {
 * // TODO...  json ==> Access01
 * <p>
 * // 注意事项：一定要考虑解析的容错性
 * try {
 * return JSON.parseObject(value, Access01.class);
 * } catch (Exception e) {
 * e.printStackTrace(); // 写到某个地方
 * return null;
 * }
 * <p>
 * }
 * })
 * <p>
 * <p>
 * .filter(x -> x != null)
 * .filter(new FilterFunction<Access01>() {
 * @Override public boolean filter(Access01 value) throws Exception {
 * return "453".equals(value.city_id);
 * }
 * });
 * cleanStream.print();
 * env.execute("OsUserCntAppV1");
 * }
 */

}