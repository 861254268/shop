package com.imooc.flink.kafka;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.util.Collector;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/20 21:00
 * @File: FlinkKafkaApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Flink对接Kafka数据入门
 */
public class FlinkKafkaApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        test01(env);
        env.execute("FlinkKafkaApp");
    }

    public static void test01(StreamExecutionEnvironment env) {

        /**
         * 官网默认的
         Properties properties = new Properties();
         properties.setProperty("bootstrap.servers", "localhost:9092");
         // properties.setProperty("bootstrap.servers", "localhost:9092,localhost:9093,localhost:9094");
         properties.setProperty("group.id", "test");
         DataStream<String> stream = env
         .addSource(new FlinkKafkaConsumer<>("test1", new SimpleStringSchema(), properties));
         */

        // kafka相关参数
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");
        // properties.setProperty("bootstrap.servers", "localhost:9092,localhost:9093,localhost:9094");
        properties.setProperty("group.id", "test");
        properties.setProperty("enable.auto.commit", "false");  // 不让自动提交
        properties.setProperty("auto.offset.reset", "earliest");
        String topic = "test1";

        // checkpoint相关参数
        env.enableCheckpointing(5000);
        env.setStateBackend(new FsStateBackend("file:///F:/study/Flink/coding510-learn/imooc-flink/state"));
        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(2, Time.of(5, TimeUnit.SECONDS)));

        FlinkKafkaConsumer<String> kafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), properties);
        //DataStream<String> stream =
        SingleOutputStreamOperator<Tuple2<String, Integer>> stream = env.addSource(kafkaConsumer)
                .flatMap(new FlatMapFunction<String, String>() {
                    @Override
                    public void flatMap(String value, Collector<String> out) throws Exception {
                        String[] splits = value.split(",");
                        for (String split : splits) {
                            out.collect(split);
                        }
                    }
                })
                .map(new MapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> map(String value) throws Exception {
                        return Tuple2.of(value, 1);
                    }
                })
                .keyBy(x -> x.f0)
                .sum(1);
        stream.print("wc统计;");

        //　容错
        SingleOutputStreamOperator<String> mapStream = env.socketTextStream("localhost", 9999)
                .map(new MapFunction<String, String>() {
                    @Override
                    public String map(String value) throws Exception {
                        if (value.contains("pk")) throw new RuntimeException("把PK哥拉黑。。。");
                        return value.toUpperCase();
                    }
                });
        mapStream.print("from socket(nc):");

    }
}
