package com.imooc.flink.app;


import com.imooc.flink.udf.GaodeLocationMapFunction;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.redis.RedisSink;
import org.apache.flink.streaming.connectors.redis.common.config.FlinkJedisPoolConfig;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommand;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommandDescription;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisMapper;

import javax.crypto.MacSpi;
import java.util.Map;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: 180867
 * @Create Time: 2021/8/12 15:58
 * @File: ProvinceUserCntAppV1.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 按照省份维度进行新老用户的统计分析
 * <p>
 * 由于数据源的缺失及json数据格式问题，此处使用csv/txt数据进行相应的计算和处理
 */
public class ProvinceUserCntAppV1 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> streamSource = env.readTextFile("data/access.txt");
        SingleOutputStreamOperator<String> cleanStream = streamSource
                .filter(x -> x != null)
                .filter(new FilterFunction<String>() {
                    @Override
                    public boolean filter(String value) throws Exception {
                        // return "1998".equals((value.split(",")[2].substring(0,4)));
                        return !"刘维国".equals(value.split(",")[4]);
                        // 此处过滤货主名称不是“刘维国”的数据
                    }
                });
        // .map(new GaodeLocationMapFunction()) // 这种方法也是可以进行map的，只是由于数据及网络原因
        // 下面是进行了方法的重构
        cleanStream.map(new MapResult())
                .print();
        // 入库Redis的功能此处不再实现。OsUserCntAppV1.java部分已实现
        env.execute("OsUserCntAppV1");
    }
}

class MapResult implements MapFunction<String, Tuple3<String, String, Integer>> {


    @Override
    public Tuple3<String, String, Integer> map(String value) throws Exception {
        return Tuple3.of(value.split(",")[4], value.split(",")[5], 1);
    }
}
