package com.imooc.flink.domain;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/19 21:36
 * @File: Access.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class Access {
    private String Shop_ID;
    private String Yunhuo_Person;
    private String hz_name;
    private String hz_area;
    // 新增字段
    private String hz_area2;
    private String hz_province;
    private String hz_city;
    private String Plan_num;
    private String at_time;
    private long at_stamp;

    public Access() {
    }

    public Access(String shop_ID, String yunhuo_Person, String hz_name, String hz_area, String hz_area2, String hz_province, String hz_city, String plan_num, String at_time, long at_stamp) {
        Shop_ID = shop_ID;
        Yunhuo_Person = yunhuo_Person;
        this.hz_name = hz_name;
        this.hz_area = hz_area;
        this.hz_area2 = hz_area2;
        this.hz_province = hz_province;
        this.hz_city = hz_city;
        Plan_num = plan_num;
        this.at_time = at_time;
        this.at_stamp = at_stamp;
    }

    public String getShop_ID() {
        return Shop_ID;
    }

    public void setShop_ID(String shop_ID) {
        Shop_ID = shop_ID;
    }

    public String getYunhuo_Person() {
        return Yunhuo_Person;
    }

    public void setYunhuo_Person(String yunhuo_Person) {
        Yunhuo_Person = yunhuo_Person;
    }

    public String getHz_name() {
        return hz_name;
    }

    public void setHz_name(String hz_name) {
        this.hz_name = hz_name;
    }

    public String getHz_area() {
        return hz_area;
    }

    public void setHz_area(String hz_area) {
        this.hz_area = hz_area;
    }

    public String getHz_area2() {
        return hz_area2;
    }

    public void setHz_area2(String hz_area2) {
        this.hz_area2 = hz_area2;
    }

    public String getHz_province() {
        return hz_province;
    }

    public void setHz_province(String hz_province) {
        this.hz_province = hz_province;
    }

    public String getHz_city() {
        return hz_city;
    }

    public void setHz_city(String hz_city) {
        this.hz_city = hz_city;
    }

    public String getPlan_num() {
        return Plan_num;
    }

    public void setPlan_num(String plan_num) {
        Plan_num = plan_num;
    }

    public String getAt_time() {
        return at_time;
    }

    public void setAt_time(String at_time) {
        this.at_time = at_time;
    }

    public long getAt_stamp() {
        return at_stamp;
    }

    public void setAt_stamp(long at_stamp) {
        this.at_stamp = at_stamp;
    }

    @Override
    public String toString() {
        return "Access{" +
                "Shop_ID='" + Shop_ID + '\'' +
                ", Yunhuo_Person='" + Yunhuo_Person + '\'' +
                ", hz_name='" + hz_name + '\'' +
                ", hz_area='" + hz_area + '\'' +
                ", hz_area2='" + hz_area2 + '\'' +
                ", hz_province='" + hz_province + '\'' +
                ", hz_city='" + hz_city + '\'' +
                ", Plan_num='" + Plan_num + '\'' +
                ", at_time='" + at_time + '\'' +
                ", at_stamp=" + at_stamp +
                '}';
    }
}
