package com.imooc.flink.app;

import com.alibaba.fastjson.JSON;
import com.imooc.flink.domain.Access1;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/19 19:35
 * @File: OsUserCntAppV12.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 按照操作系统维度进行新老用户的统计分析
 * * <p>
 * * 此处使用json格式数据进行处理，创建样例类
 */
public class OsUserCntAppV12 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 该段代码需要后续进行进一步的验证才能使用
        SingleOutputStreamOperator<Access1> cleanStream = env.readTextFile("data/access11.json")
                .map(new MapFunction<String, Access1>() {
                    @Override
                    public Access1 map(String value) throws Exception {
                        // TODO...  json ==> Access01

                        // 注意事项：一定要考虑解析的容错性
                        try {
                            return JSON.parseObject(value, Access1.class);
                        } catch (Exception e) {
                            e.printStackTrace(); // 写到某个地方
                            return null;
                        }
                    }
                }).filter(x -> x != null);
        cleanStream.print();
        env.execute("OsUserCntAppV1");
    }

}
