package com.imooc.flink.domain;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/28 22:01
 * @File: OrderInfo.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Order数据
 */
public class OrderInfo {
    public String orderId;
    public long time;
    public double money;

    @Override
    public String toString() {
        return "OrderInfo{" +
                "orderId='" + orderId + '\'' +
                ", time=" + time +
                ", money=" + money +
                '}';
    }
}
