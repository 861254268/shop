package com.imooc.flink.kafka;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.KafkaDeserializationSchema;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/20 21:00
 * @File: FlinkKafkaApp3.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Flink对接Kafka数据入门
 */
public class FlinkKafkaApp3 {
    public static void main(String[] args) throws Exception {

        // 版本2
        // DataStream<String> stream = FlinkUtils.createKafkaStreamV2(args);
        //版本3
        DataStream<String> stream = FlinkUtils.createKafkaStreamV3(args, SimpleStringSchema.class);

        stream.print();

        FlinkUtils.env.execute();
//        test01(env);
//        env.execute("FlinkKafkaApp3");
    }

}