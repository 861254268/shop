package com.imooc.flink.udf;

import com.imooc.flink.domain.Access;
import org.apache.flink.api.common.functions.AggregateFunction;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/17 20:08
 * @File: TopNAggregateFunction.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 统计五分钟内的不同event(加购物车 、 浏览...)类型、类别、商品的TopN访问量
 * <p>
 * 由于数据源的缺失及json数据格式问题，此处使用csv/txt数据进行相应的计算和处理
 */

public class TopNAggregateFunction implements AggregateFunction<Access, Long, Long> {
    @Override
    public Long createAccumulator() {
        return 0L;
    }

    @Override
    public Long add(Access value, Long accumulator) {
        return accumulator + 1;
    }

    @Override
    public Long getResult(Long accumulator) {
        return accumulator;
    }

    @Override
    public Long merge(Long a, Long b) {
        return null;
    }
}
