package com.imooc.flink.app;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.redis.RedisSink;
import org.apache.flink.streaming.connectors.redis.common.config.FlinkJedisPoolConfig;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommand;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommandDescription;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisMapper;


/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/12 20:08
 * @File: OsUserCntAppV1.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 按照操作系统维度进行新老用户的统计分析
 * * <p>
 * * 由于数据源的缺失及json数据格式问题，此处使用csv/txt数据进行相应的计算和处理
 */
public class OsUserCntAppV1 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> streamSource = env.readTextFile("data/access.txt");
        SingleOutputStreamOperator<String> cleanStream = streamSource
                .filter(x -> x != null)
                .filter(new FilterFunction<String>() {
                    @Override
                    public boolean filter(String value) throws Exception {
                        // return "1998".equals((value.split(",")[2].substring(0,4)));
                        return !"刘维国".equals(value.split(",")[4]);
                        // 此处过滤货主名称不是“刘维国”的数据
                    }
                });
        // cleanStream.print();

/**
 * 该段代码需要后续进行进一步的验证才能使用
 *  SingleOutputStreamOperator<Access01> cleanStream = env.readTextFile("data/access.json")
 .map(new MapFunction<String, Access01>() {
@Override public Access01 map(String value) throws Exception {
// TODO...  json ==> Access01

// 注意事项：一定要考虑解析的容错性
try {
return JSON.parseObject(value, Access01.class);
} catch (Exception e) {
e.printStackTrace(); // 写到某个地方
return null;
}

}
}).filter(x -> x != null)
 .filter(new FilterFunction<Access01>() {
@Override public boolean filter(Access01 value) throws Exception {
return "453".equals(value.city_id);
}
});
 cleanStream.print();
 env.execute("OsUserCntAppV1");
 }
 */

        // TODO... 操作系统维度 新老用户 ==> WC
        // 此处统计货主地区     货主名称==> WC
        SingleOutputStreamOperator<Tuple3<String, String, Integer>> result = cleanStream.map(new MapFunction<String, Tuple3<String, String, Integer>>() {
            @Override
            public Tuple3<String, String, Integer> map(String value) throws Exception {
                return Tuple3.of(value.split(",")[4], value.split(",")[5], 1);
            }
        })
                .keyBy(new KeySelector<Tuple3<String, String, Integer>, Tuple2<String, String>>() {
                    @Override
                    public Tuple2<String, String> getKey(Tuple3<String, String, Integer> value) throws Exception {
                        return Tuple2.of(value.f0, value.f1);
                    }
                })
                .sum(2);//.print().setParallelism(1);
        // result.print();
        // (方先生,浙江,13)

        // 把数据结果sink到Redis
        FlinkJedisPoolConfig conf = new FlinkJedisPoolConfig.Builder().setHost("127.0.0.1").build();

        result.addSink(new RedisSink<Tuple3<String, String, Integer>>(conf, new RedisExampleMapper()));

        env.execute("OsUserCntAppV1");

    }


    static class RedisExampleMapper implements RedisMapper<Tuple3<String, String, Integer>> {

        @Override
        public RedisCommandDescription getCommandDescription() {
            return new RedisCommandDescription(RedisCommand.HSET, "os-user-cnt:20301002");
        }

        @Override
        public String getKeyFromData(Tuple3<String, String, Integer> data) {
            return data.f0 + "_" + data.f1;
        }

        @Override
        public String getValueFromData(Tuple3<String, String, Integer> data) {
            return data.f2 + "";
        }

    }
}
