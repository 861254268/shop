package com.imooc.flink.domain;

public class EventCatagoryProductCount {

    public String hz_name;
    public String hz_area;
    public String Yunhuo_Person;
    public long count;
    public long start;
    public long end;

    public EventCatagoryProductCount() {
    }

    public EventCatagoryProductCount(String hz_name, String hz_area, String yunhuo_Person, long plan_num, long start, long end) {
        this.hz_name = hz_name;
        this.hz_area = hz_area;
        Yunhuo_Person = yunhuo_Person;
        count = plan_num;
        this.start = start;
        this.end = end;
    }

    @Override
    public String toString() {
//        return "EventCatagoryProductCount{" +
//                "hz_name='" + hz_name + '\'' +
//                ", hz_city='" + hz_city + '\'' +
//                ", Yunhuo_Person='" + Yunhuo_Person + '\'' +
//                ", Plan_num='" + count + '\'' +
//                ", start=" + start +
//                ", end=" + end +
//                '}';
        return Yunhuo_Person + "\t" + hz_name + "\t" + hz_area + "\t" + count + "\t" + start + "\t" + end;
    }
}
