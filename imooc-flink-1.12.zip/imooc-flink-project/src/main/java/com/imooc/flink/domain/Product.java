package com.imooc.flink.domain;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/12 20:08
 * @File: Product.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 浏览器复杂数据类型
 */
public class Product {
    public String Agent; //浏览器代理信息
    public boolean BoxModel;
    public String Browser;
    public String Version;
    public String terminal;

    @Override
    public String toString() {
        return "Product{" +
                "Agent='" + Agent + '\'' +
                ", BoxModel=" + BoxModel +
                ", Browser='" + Browser + '\'' +
                ", Version='" + Version + '\'' +
                ", terminal='" + terminal + '\'' +
                '}';
    }
}
