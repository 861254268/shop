package com.imooc.flink.domain;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/12 20:06
 * @File: Access01.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 用戶行为日志类定义
 * <p>
 * POJO类
 */
public class Access01 {
    private String 订单ID;
    private String bi_xddt;
    private String bi_fhdt;
    private String 运货商;
    private String 货主名称;
    private String bi_dept;
    private String bi_areaname;
    private String ip;
    private String 货主城市;
    private Integer tdsct091_oqua;
    public String province;
    public String city;

    public Access01() {
    }

    public Access01(String 订单ID, String bi_xddt, String bi_fhdt, String 运货商, String 货主名称, String bi_dept, String bi_areaname, String ip, String 货主城市, Integer tdsct091_oqua, String province, String city) {
        this.订单ID = 订单ID;
        this.bi_xddt = bi_xddt;
        this.bi_fhdt = bi_fhdt;
        this.运货商 = 运货商;
        this.货主名称 = 货主名称;
        this.bi_dept = bi_dept;
        this.bi_areaname = bi_areaname;
        this.ip = ip;
        this.货主城市 = 货主城市;
        this.tdsct091_oqua = tdsct091_oqua;
        this.province = province;
        this.city = city;
    }

    public String get订单ID() {
        return 订单ID;
    }

    public void set订单ID(String 订单ID) {
        this.订单ID = 订单ID;
    }

    public String getBi_xddt() {
        return bi_xddt;
    }

    public void setBi_xddt(String bi_xddt) {
        this.bi_xddt = bi_xddt;
    }

    public String getBi_fhdt() {
        return bi_fhdt;
    }

    public void setBi_fhdt(String bi_fhdt) {
        this.bi_fhdt = bi_fhdt;
    }

    public String get运货商() {
        return 运货商;
    }

    public void set运货商(String 运货商) {
        this.运货商 = 运货商;
    }

    public String get货主名称() {
        return 货主名称;
    }

    public void set货主名称(String 货主名称) {
        this.货主名称 = 货主名称;
    }

    public String getBi_dept() {
        return bi_dept;
    }

    public void setBi_dept(String bi_dept) {
        this.bi_dept = bi_dept;
    }

    public String getBi_areaname() {
        return bi_areaname;
    }

    public void setBi_areaname(String bi_areaname) {
        this.bi_areaname = bi_areaname;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String get货主城市() {
        return 货主城市;
    }

    public void set货主城市(String 货主城市) {
        this.货主城市 = 货主城市;
    }

    public Integer getTdsct091_oqua() {
        return tdsct091_oqua;
    }

    public void setTdsct091_oqua(Integer tdsct091_oqua) {
        this.tdsct091_oqua = tdsct091_oqua;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "Access01{" +
                "订单ID='" + 订单ID + '\'' +
                ", bi_xddt='" + bi_xddt + '\'' +
                ", bi_fhdt='" + bi_fhdt + '\'' +
                ", 运货商='" + 运货商 + '\'' +
                ", 货主名称='" + 货主名称 + '\'' +
                ", bi_dept='" + bi_dept + '\'' +
                ", bi_areaname='" + bi_areaname + '\'' +
                ", ip='" + ip + '\'' +
                ", 货主城市='" + 货主城市 + '\'' +
                ", tdsct091_oqua=" + tdsct091_oqua +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}