package com.imooc.flink.kafka;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/25 20:00
 * @File: KafkaTest.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class KafkaTest {
    public static void main(String[] args) throws Exception {
        DataStream<Tuple2<String, String>> source = FlinkUtils.createKafkaStreamV4(args, PKKafkaDeserializationSchema.class);
        source.print();
        FlinkUtils.env.execute();
    }
}