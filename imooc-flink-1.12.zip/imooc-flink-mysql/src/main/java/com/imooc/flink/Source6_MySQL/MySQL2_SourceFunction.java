package com.imooc.flink.Source6_MySQL;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/23 23:00
 * @File: MySQL2_SourceFunction.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class MySQL2_SourceFunction {
    public static void main(String[] args) throws Exception {

        // ToDo 0.env
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // ToDo 1.source
        DataStreamSource<Student> dataInput = env.addSource(new MySQLSource());


        // ToDo 2.transformation

        // ToDo 3.sink
        dataInput.print();

        // ToDo 4.execute
        env.execute("MySQL2_SourceFunction");
    }
}