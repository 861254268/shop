package com.imooc.flink.Sink6_MySQL;

import com.imooc.flink.Source6_MySQL.Student;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/23 23:20
 * @File: MySQLSink.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class MySQLSink extends RichSinkFunction<Student> {

    private Connection conn = null;
    private PreparedStatement insertStmt = null;
    private PreparedStatement updateStmt = null;

    // 打开数据库连接，只执行一次，之后一直使用这个连接
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        Class.forName("com.mysql.jdbc.Driver");  // 加载数据库驱动
        conn = DriverManager.getConnection(  // 获取连接
                "jdbc:mysql://localhost:3306/demodb?serverTimezone=GMT%2B8&useSSL=false",  // 数据库URL
                "root",  // 用户名
                "123456");  // 登录密码
        insertStmt = conn.prepareStatement(  // 获取执行语句
                "insert into t_student(id,name,age) values (?,?,?)");  // 插入数据
        updateStmt = conn.prepareStatement(  // 获取执行语句
                "update t_student set name=?,age=? where id=?");  // 更新数据
    }

    // 执行插入和更新
    @Override
    public void invoke(Student value, Context ctx) throws Exception {
        // 每条数据到来后，直接执行更新语句
        updateStmt.setString(1, value.getName());  // 与占位符(?)对应的参数
        updateStmt.setInt(2, value.getAge());
        updateStmt.setInt(3, value.getId());
        updateStmt.execute();  // 执行更新语句

        // 如果更新数为0，则执行插入语句
        if (updateStmt.getUpdateCount() == 0) {
            insertStmt.setInt(1, value.getId());
            insertStmt.setString(2, value.getName());
            insertStmt.setInt(3, value.getAge());
            insertStmt.execute();  // 执行插入语句
        }
    }

    // 关闭数据库连接
    @Override
    public void close() throws Exception {
        super.close();
        if (conn != null) conn.close();
        if (insertStmt != null) insertStmt.close();
        if (updateStmt != null) updateStmt.close();
    }

}
