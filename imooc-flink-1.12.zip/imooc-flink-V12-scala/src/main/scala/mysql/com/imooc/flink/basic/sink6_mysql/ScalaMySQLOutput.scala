package mysql.com.imooc.flink.basic.sink6_mysql

import mysql.com.imooc.flink.basic.source6_mysql.Student
import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.api.java.io.jdbc.JDBCOutputFormat
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/6 22:00
  * @File: ScalaMySQLOutput.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: JDBCOutputFormat
  */
object ScalaMySQLOutput {
  // case class Student(id: Int, name: String, age: Int) {}
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val dataMap: DataStream[(Integer, String, Integer)] = env.fromCollection(List(
      new Student(100, "Nancy", 22),
      new Student(101, "Mary", 53),
      new Student(102, "Scala", 32)
    ))
      .map(x => (x.getId, x.getName, x.getAge))

    dataMap.print()
    // dataMap.output()【需要进一步研究】
//    dataMap.output(JDBCOutputFormat.buildJDBCOutputFormat()
//      .setDrivername("com.mysql.jdbc.Driver")  // JDBC驱动名
//      .setDBUrl("jdbc:mysql://localhost:3306/demodb?serverTimezone=GMT%2B8&useSSL=false")  // 数据库URL
//      .setUsername("root")  // 用户名
//      .setPassword("123456")  // 登录密码
//      .setQuery("insert into t_student(id,name,age) values(?,?,?)")  // 需要执行的SQL语句
//      // 如果数据不存在则插入，数据存在则更新，可以将SQL语句替换为以下：
//      // insert into t_student(id,name,age) values(?,?,?) on duplicate key update name=values(name),age=values(age)
//      //.setSqlTypes(new int[]{Types.INTEGER, Types.VARCHAR, Types.INTEGER})  // 设置查询的列的类型
//      .finish());
    env.execute()
  }
}
