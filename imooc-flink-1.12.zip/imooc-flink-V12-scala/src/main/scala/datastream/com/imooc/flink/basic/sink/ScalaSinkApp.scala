package datastream.com.imooc.flink.basic.sink

//import datastream.com.imooc.flink.basic.transformation.Access
import datastream.com.imooc.flink.basic.source.Access
import org.apache.flink.api.common.functions.MapFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.api.scala._
import org.apache.flink.streaming.connectors.redis.RedisSink
import org.apache.flink.streaming.connectors.redis.common.config.FlinkJedisPoolConfig
import org.apache.flink.streaming.connectors.redis.common.mapper.{RedisCommand, RedisCommandDescription, RedisMapper}

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/2 19:48
  * @File: ScalaSinkApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: sink之print&printToErr及并行度
  */
object ScalaSinkApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    printTest(env) // 并行度及printToErr的使用
    // toMySQL(env)  // toMySQL【后续测试】
    // toRedis(env)

    env.execute()
  }

  def toRedis(env: StreamExecutionEnvironment): Unit = {
    val source = env.readTextFile("data/access.log")
    val result: DataStream[Access] = source.map(new MapFunction[String, Access] {
      override def map(value: String): Access = {
        val splits = value.split(",")
        //        for(split<-splits){
        //        }
        val time = splits(0).toLong
        val domain = splits(1).trim
        val traffic = splits(2).trim.toDouble

        new Access(time, domain, traffic)
      }
    }) //.print()
      .keyBy(_.getDomain)
      .sum("traffic")
    result.print()

    val conf = new FlinkJedisPoolConfig.Builder().setHost("127.0.0.1").build()
    result
      .map(new MapFunction[Access, (String, Double)] {
        override def map(value: Access): (String, Double) = {
          (value.getDomain, value.getTraffic)
        }
      })
      .addSink(new RedisSink[(String, Double)](conf, new MyRedisMapper))


    //定义一个redis的mapper类,用于定义保存到redis时调用的命令
    class MyRedisMapper extends RedisMapper[(String, Double)] {
      override def getCommandDescription: RedisCommandDescription = {
        //把传感器id和温度值保存成哈希表: HSET key field value
        new RedisCommandDescription(RedisCommand.HSET, "sc-traffic")
      }

      //相当于是field
      override def getKeyFromData(data: (String, Double)): String = {
        data._1
      }

      override def getValueFromData(data: (String, Double)): String = {
        data._2.toString
      }
    }

    println("...写入成功！...")

  }


  def printTest(env: StreamExecutionEnvironment): Unit = {
    val stream = env.socketTextStream("localhost", 9999)
    println("stream: " + stream.parallelism) // 1    parallelism代替getParallelism获取并行度
    // stream.printToErr()
    stream.print("Mr.Jia").setParallelism(2)

  }


}
