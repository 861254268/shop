package datastream.com.imooc.flink.basic.source

import java.util.Properties

import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/9/1 20:35
  * @File: ScalaSourceApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: StreamExecutionEnvironment详解
  */
object ScalaSourceApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment

    // base(env) // 并行度的基本测试
    // test02(env)
    // test03(env) // 自定义单并行Source
    // test03V2(env) // 自定义多并行Source
    test05(env) // Source API编程之对接kafka数据
    env.execute()
  }

  def test05(env: StreamExecutionEnvironment): Unit = {
    val properties = new Properties()
    properties.setProperty("bootstrap.servers", "localhost:9092")
    // only required for Kafka 0.8
    // properties.setProperty("zookeeper.connect", "localhost:2181")
    properties.setProperty("group.id", "test")
    val stream = env
      .addSource(new FlinkKafkaConsumer[String]("flinktopic", new SimpleStringSchema(), properties))
    println(stream.parallelism)
    stream.print()
  }

  def test03V2(env: StreamExecutionEnvironment): Unit = {
    val source = env.addSource(new ScalaAccessSourceV2)
    // .setParallelism(5)
    println(source.parallelism) // 默认是机器的core数：12
    source.print()
  }

  def test03(env: StreamExecutionEnvironment): Unit = {
    val source = env.addSource(new ScalaAccessSource)
    println(source.parallelism)
    source.print()
  }

  def test02(env: StreamExecutionEnvironment): Unit = {
    // 对于env设置的并行度，是一个全局的概念
    // env.setParallelism(8)
    // val data = 1 to 10
    val x = List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    val source = env.fromCollection(x).filter(_ >= 5)
    //类似于java env.fromParallelCollection(new NumberSequenceIterator(1, 10), classOf[Long])
    source.print()
  }

  def base(env: StreamExecutionEnvironment): Unit = {
    env.setParallelism(5)
    var source = env.socketTextStream("localhost", 9999)
    println("source..." + source.parallelism)

    source.filter(!_.equals("pk")).setParallelism(6).print()

  }

}
