package com.imooc.flink.tablesql

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/3 20:14
  * @File: Table2StreamApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption:
  */
object Table2StreamApp {
  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val tEnv = StreamTableEnvironment.create(env)
    val stream = env.socketTextStream("localhost", 7777)
    // TODO... 逗号分隔，每个切分后的词进行WC统计
    val stream2 = stream.flatMap(_.split(",")).map(x => WC(x.toLowerCase(), 1))
    val table = tEnv.fromDataStream(stream2)
    tEnv.registerTable("WC", table)

    // ① Append-only模式：
    //    // val resultTable = tEnv.sqlQuery("select word,sum(cnt) as cnts from WC group by word") // Table is not an append-only table. Use the toRetractStream() in order to handle add and retract messages.
    //    // table ==> stream toAppendStream模式处理
    //    tEnv.toAppendStream[Row](table).print()

    // ② Retract模式：
    /*
    *　Retract模式：
    * 返回boolean类型：true表示插入，false表示撤回
     */
    val resultTable = tEnv.sqlQuery("select word,sum(cnt) as cnts from WC group by word")
    // table ==> stream toRetractStream模式处理
    tEnv.toRetractStream[Row](resultTable).print()
    env.execute(this.getClass.getSimpleName)
  }

}
