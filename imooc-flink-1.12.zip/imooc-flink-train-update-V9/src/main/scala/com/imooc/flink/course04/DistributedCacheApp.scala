package com.imooc.flink.course04

import org.apache.commons.io.FileUtils
import org.apache.flink.api.common.functions.RichMapFunction
import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.configuration.Configuration


/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/17 11:32
  * @File: DistributedCacheApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 基于flink的分布式缓存(DistributecCache)功能的scala实现
  *               step1：注册一个本地/HDFS文件
  *               step2：在open方法中获取到分布式缓存的内容即可
  *               java集合和scala集合不兼容的问题的解决（小技巧）
  */
object DistributedCacheApp {
  def main(args: Array[String]): Unit = {

    val env = ExecutionEnvironment.getExecutionEnvironment

    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\input\\hello.txt"

    // step1: 注册一个本地/HDFS文件
    env.registerCachedFile(filePath, "pk-scala-dc")

    import org.apache.flink.api.scala._
    val data = env.fromElements("hadoop", "spark", "flink", "pyspark", "storm")


    data.map(new RichMapFunction[String, String] {

      // step2：在open方法中获取到分布式缓存的内容即可
      override def open(parameters: Configuration): Unit = {
        val dcFile = getRuntimeContext.getDistributedCache().getFile("pk-scala-dc")

        val lines = FileUtils.readLines(dcFile) // java


        //增强for循环
        /**
          * for (ele <- lines) { //scala的语法
          * 此时会出先一个异常：java集合和scala集合不兼容的问题
          * 解决方法：导包，转换
          *
          * 这个很重要：
          * import scala.collection.JavaConverters._
          *
          **/
        import scala.collection.JavaConverters._
        for (ele <- lines.asScala) { // scala
          println(ele)
        }
      }

      override def map(value: String): String = {
        value
      }
    }).print()
  }

}
