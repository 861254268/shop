package com.imooc.flink.course04

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.configuration.Configuration
// 导入隐式转换
import org.apache.flink.api.scala._

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/7/13 20:56
  * @File: DataSetDataSourceApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: 从文件或者文件夹创建dataset
  */
object DataSetDataSourceApp2 {
  def main(args: Array[String]): Unit = {
    val env = ExecutionEnvironment.getExecutionEnvironment
    //     fromCollection(env)
    //        textFile(env)
    //    csvFile(env)
    readRecursiveFiles(env)


  }

  // 从递归文件夹的内容创建dataset
  def readRecursiveFiles(env: ExecutionEnvironment): Unit = {
    //    val filePath = "F:\\study\\Flink\\imooc\\flink-train\\nested"
    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\RecursiveFiles"
    env.readTextFile(filePath).print()
    println("~~~~~~~华丽的分割线~~~~~~~")

    val parameters = new Configuration
    parameters.setBoolean("recursive.file.enumeration", true) // 递归的关键
    env.readTextFile(filePath).withParameters(parameters).print()
  }

  // 从csv文件创建dataset
  def csvFile(env: ExecutionEnvironment): Unit = {
    //    val filePath = "F:\\study\\Flink\\imooc\\flink-train\\data\\04\\people.csv"
    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\data\\04\\people.csv"
    //    env.readCsvFile[(String, Int, String)](filePath, ignoreFirstLine = true).print()
    // ①Tuple方式实现：指定数据类型，忽略第一行
    //    env.readCsvFile[(String, Int)](filePath, ignoreFirstLine = true).print() // 读出两列
    //    env.readCsvFile[(String, Int)](filePath, ignoreFirstLine = true, includedFields = Array(0, 1)).print()


    // ②case class实现
    //    case class MyCaseClass(name: String, age: Int)
    //
    //    env.readCsvFile[MyCaseClass](filePath, ignoreFirstLine = true, includedFields = Array(0, 1)).print()

    // ③pojo方式实现
    env.readCsvFile[Person](filePath, ignoreFirstLine = true, pojoFields = Array("name", "age", "work")).print()

  }

  // 从文件或者文件夹创建dataset
  def textFile(env: ExecutionEnvironment): Unit = {
    //    val filePath = "file:///User/rocky/data/04/hello.txt"

    //    val filePath = "F:\\study\\Flink\\imooc\\words.txt"
    //    env.readTextFile(filePath).print()

    //    val filePath = "F:\\study\\Flink\\imooc\\flink-train\\note"
    val filePath = "D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\note"
    env.readTextFile(filePath).print()
  }

  // 从集合创建dataset
  def fromCollection(env: ExecutionEnvironment): Unit = {
    val data = 1 to 10
    env.fromCollection(data).print()
  }

}
