package com.imooc.flink.tablesql

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/3 20:03
  * @File: StreamSQLApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: DataStream整合SQL实战
  */
object StreamSQLApp {
  def main(args: Array[String]): Unit = {
    // 获取流式运行环境
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // 创建一个Table运行环境
    val tEnv = StreamTableEnvironment.create(env)
    // 数据源
    val inputStream = env.readTextFile("D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\data\\tablesql\\access.log")
    // map操作
    val mapStream = inputStream.map(x => {
      val splits = x.split(",")
      Access(splits(0).trim.toLong, splits(1).trim, splits(2).trim.toDouble)

    })

    // DataStream==>Table
    val table = tEnv.fromDataStream(mapStream)
    // 注册表：Table ==> table
    tEnv.registerTable("access", table)

    val resultTable = tEnv.sqlQuery("select * from access")
    // TODO... Table如何输出呢？
    /*
    * toAppendStream[Row]方法的泛型一定要注意
     */
    tEnv.toAppendStream[Row](resultTable).print()

    env.execute(this.getClass.getSimpleName)
  }

}
