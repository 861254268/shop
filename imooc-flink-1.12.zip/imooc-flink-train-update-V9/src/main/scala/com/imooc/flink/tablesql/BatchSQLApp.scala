package com.imooc.flink.tablesql

import org.apache.flink.api.scala.ExecutionEnvironment
import org.apache.flink.table.api.scala.BatchTableEnvironment
import org.apache.flink.api.scala._
import org.apache.flink.types.Row

/**
  * -*- coding: utf-8 -*-
  *
  * @Author: Mr.Jia
  * @Create Time: 2021/8/3 20:09
  * @File: BatchSQLApp.scala/java
  * @Software: IntelliJ IDEA 2018.2.4
  * @descirption: DataSet整合SQL实战
  */
object BatchSQLApp {
  def main(args: Array[String]): Unit = {
    // 创建批处理运行环境
    val env = ExecutionEnvironment.getExecutionEnvironment
    // 创建一个Table运行环境
    val tEnv = BatchTableEnvironment.create(env)
    // 读取数据源
    val inputDataSet = env.readTextFile("D:\\SourceCode2020\\FlinkDemo\\imooc\\DataNote\\data\\tablesql\\access.log")
    // map操作
    val mapBatch = inputDataSet.map(x => {
      val splits = x.split(",")
      Access(splits(0).trim.toLong, splits(1).trim, splits(2).trim.toDouble)

    })

    // DataSet==>Table
    val table = tEnv.fromDataSet(mapBatch)
    // 注册表：Table ==> table
    tEnv.registerTable("batch_access", table)

    val sql="select domain,sum(traffic) as traffics from batch_access group by domain"
    val resultTable = tEnv.sqlQuery(sql)
    // TODO... Table如何输出呢？
    /*
    * toDataSet[Row]方法的泛型一定要注意
     */

    resultTable.printSchema()
    /*
    * root
    *    |-- time: BIGINT
    *    |-- domain: STRING
    *    |-- traffic: DOUBLE
    *
    */
    println("=====================================")
    tEnv.toDataSet[Row](resultTable).print()
    // env.execute(this.getClass.getSimpleName)
  }
}
