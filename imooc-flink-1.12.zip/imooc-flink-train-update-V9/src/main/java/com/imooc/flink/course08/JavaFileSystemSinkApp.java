package com.imooc.flink.course08;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.fs.StringWriter;
import org.apache.flink.streaming.connectors.fs.bucketing.BucketingSink;
import org.apache.flink.streaming.connectors.fs.bucketing.DateTimeBucketer;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/7/22 19:44
 * @File: JavaFileSystemSinkApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: HDFS Connector的使用
 */
public class JavaFileSystemSinkApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> data = env.socketTextStream("localhost", 9999);

        data.print().setParallelism(1);

        String filePath = "F:\\study\\Flink\\imooc\\flink-train\\hdfssink";
        BucketingSink<String> sink = new BucketingSink<String>(filePath);
        sink.setBucketer(new DateTimeBucketer<String>("yyyy-MM-dd--HH:mm"));
        sink.setWriter(new StringWriter<String>());
        sink.setBatchRolloverInterval(20000);
        data.addSink(sink);
        env.execute("JavaFileSystemSinkApp");
    }
}
