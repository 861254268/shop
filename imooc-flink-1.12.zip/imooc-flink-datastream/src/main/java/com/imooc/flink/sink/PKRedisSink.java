package com.imooc.flink.sink;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommand;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommandDescription;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisMapper;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/12 19:50
 * @File: PKRedisSink.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: RedisSink功能实现
 * <p>
 * 在生产环境中，软件版本做了升级
 * 代码有了很大的变化
 * <p>
 * ==> diff
 */

public class PKRedisSink implements RedisMapper<Tuple2<String, Double>> {

    @Override
    public RedisCommandDescription getCommandDescription() {
        return new RedisCommandDescription(RedisCommand.HSET, "pk-traffic");
    }

    @Override
    public String getKeyFromData(Tuple2<String, Double> data) {
        return data.f0;
    }

    @Override
    public String getValueFromData(Tuple2<String, Double> data) {
        return data.f1 + "";
    }
}
