package com.imooc.flink.sink;

import com.imooc.flink.sink.PKMySQLSink;
import com.imooc.flink.transformation.Access;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.redis.RedisSink;
import org.apache.flink.streaming.connectors.redis.common.config.FlinkJedisPoolConfig;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/10 22:43
 * @File: SinkApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: sink之print&printToErr及并行度
 */
public class SinkApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // test(env);
        // print(env);
        // toRedis(env);
        toMySQL(env);



        env.execute("SinkApp");
    }

    public static void toMySQL(StreamExecutionEnvironment env) {

        DataStreamSource<String> source = env.readTextFile("data/access.log");

        SingleOutputStreamOperator<Access> mapStream = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String value) throws Exception {
                String[] splits = value.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });

        SingleOutputStreamOperator<Access> result = mapStream.keyBy(new KeySelector<Access, String>() {
            @Override
            public String getKey(Access value) throws Exception {
                return value.getDomain();
            }
        }).sum("traffic");

//        resullt.print();

    }


    public static void toRedis(StreamExecutionEnvironment env) {

        DataStreamSource<String> source = env.readTextFile("data/access.log");

        SingleOutputStreamOperator<Access> mapStream = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String value) throws Exception {
                String[] splits = value.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });

        SingleOutputStreamOperator<Access> result = mapStream.keyBy(new KeySelector<Access, String>() {
            @Override
            public String getKey(Access value) throws Exception {
                return value.getDomain();
            }
        }).sum("traffic");

        result.print();
        // result.addSink(new PKMySQLSink("jdbc:mysql://localhost:3306/pk_flink_imooc", "root", "123456"));
//        result.addSink(new PKMySQLSink());


        FlinkJedisPoolConfig conf = new FlinkJedisPoolConfig.Builder().setHost("127.0.0.1").build();
        result.map(new MapFunction<Access, Tuple2<String, Double>>() {
            @Override
            public Tuple2<String, Double> map(Access value) throws Exception {
                return Tuple2.of(value.getDomain(), value.getTraffic());
            }
        }).addSink(new RedisSink<Tuple2<String, Double>>(conf, new PKRedisSink()));

    }


    public static void print(StreamExecutionEnvironment env) {
        DataStreamSource<String> source = env.socketTextStream("localhost", 9527);

        System.out.println("source:" + source.getParallelism());

        source.print().setParallelism(2);
    }




    public static void test(StreamExecutionEnvironment env) {
        DataStreamSource<String> Stream = env.socketTextStream("localhost", 9999);
        System.out.println("Stream..." + Stream.getParallelism());    // 1

//        Stream.printToErr().setParallelism(2);   // printToErr():输出内容为红色
        Stream.print("Mr.Jia").setParallelism(2);  // 输出加前缀：Mr.Jia
        // Mr.Jia:1> pk,pk,flink
        // Mr.Jia:2> pk,pk,spark
    }
}
