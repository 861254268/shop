package com.imooc.flink.window;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import static java.lang.Math.max;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/15 16:48
 * @File: PKProcessWindowFunction.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */

/**
 * @param <IN>  待处理DataStream中每个元素的数据类型.
 * @param <OUT> 结果DataStream中每个元素的数据类型.
 * @param <KEY> KeyBy中指定key的类型.
 * @param <W>   W extends Window: TimeWindow.
 */
public class PKProcessWindowFunction extends ProcessWindowFunction<Tuple2<String, Integer>, String, String, TimeWindow> {

    @Override
    public void process(String s, Context context, Iterable<Tuple2<String, Integer>> elements, Collector<String> out) throws Exception {
        System.out.println("----process invoked ...----");  // 输出一次为全量，多次为增量

        int maxValue = Integer.MIN_VALUE;
        for (Tuple2<String, Integer> element : elements) {
            maxValue = max(element.f1, maxValue);
        }

        System.out.println(context.window().getStart());
        System.out.println(context.window().getEnd());
        out.collect("当前窗口的最大值是：" + maxValue);
    }
}
