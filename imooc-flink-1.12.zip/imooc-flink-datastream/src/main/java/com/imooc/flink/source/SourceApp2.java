package com.imooc.flink.source;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.NumberSequenceIterator;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/9 21:21
 * @File: SourceApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Source API编程之并行集合及并行度
 */
public class SourceApp2 {
    public static void main(String[] args) throws Exception {
        // 执行上下文
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // test01(env);
        test02(env);

        env.execute("SourceApp2");
    }

    // 方法重构
    // 并行集合
    public static void test02(StreamExecutionEnvironment env) {

        env.setParallelism(8); // 对于env设置的并行度，是一个全局的概念
        // 调出子类：ctrl+T/ctrl+alt+鼠标单击
        DataStreamSource<Long> source = env.fromParallelCollection(new NumberSequenceIterator(1, 10), Long.class
        ).setParallelism(5);
        System.out.println("source..." + source.getParallelism());    // 12 默认并行度
        SingleOutputStreamOperator<Long> filterStream = source.filter(new FilterFunction<Long>() {
            @Override
            public boolean filter(Long value) throws Exception {
                return value >= 5;
            }
        }).setParallelism(6);   // 对于算子层面的并行度，如果全局设置，以本算子的并行度为准
        System.out.println("filterStream..." + filterStream.getParallelism());    // 12 默认并行度
        filterStream.print();

    }
    // 方法重构
    public static void test01(StreamExecutionEnvironment env) {
        // 设置全局并行度
        // 如果算子没有设置并行度，以全局的并行度为准;
        // 如果算子自身设置并行度，那么以算子设置的并行度为准。
        env.setParallelism(5);
        // 创建的本地/远程执行环境，一般不用
        /**
         * StreamExecutionEnvironment.createLocalEnvironment();
         * StreamExecutionEnvironment.createLocalEnvironment(3);
         * StreamExecutionEnvironment.createLocalEnvironment(new Configuration());
         * StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(new Configuration());    // 可能用得较多
         * StreamExecutionEnvironment.createRemoteEnvironment(String host,int port, String... jarFiles);
         * */

        DataStreamSource<String> source = env.socketTextStream("localhost", 9999);
        System.out.println("source..." + source.getParallelism()); // 获取并行度 =1
        //source.print();

        // 接收socket过来的数据，一行一个单词，把pk的过滤掉
        SingleOutputStreamOperator<String> filterStream = source.filter(new FilterFunction<String>() {
            @Override
            public boolean filter(String s) throws Exception {
                return !"pk".equals(s);
            }
        }).setParallelism(6);

        System.out.println("filter..." + filterStream.getParallelism());   // 12 可自定义 例如：4
        filterStream.print();
    }
}


