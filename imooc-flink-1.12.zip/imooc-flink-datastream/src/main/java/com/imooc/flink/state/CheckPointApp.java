package com.imooc.flink.state;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

import java.util.concurrent.TimeUnit;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/17 19:13
 * @File: CheckPointApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Flink应用程序中开启CheckPoint
 */
public class CheckPointApp {
    public static void main(String[] args) throws Exception {
        // System.setProperty("HADOOP_USER_NAME", "hadoop");
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();


        /**
         * 不开启checkpoint:不重启
         *
         * 开启了checkpoint
         * 1) 没有配置重启策略：Integer.MAX_VALUE
         * 2) 如果配置了重启策略，就使用我们配置的重启策略覆盖默认的
         *
         * 重启策略的配置：
         * 1) code
         * 2) yaml
         * */
        // 开启CheckPoint
        env.enableCheckpointing(5000);  // 默认参数：CheckpointingMode.EXACTLY_ONCE
        // env.enableCheckpointing(5000, CheckpointingMode.EXACTLY_ONCE);  // 默认参数：CheckpointingMode.EXACTLY_ONCE，可以不写

        /**
         new MemoryStateBackend(100, false); // 内存：默认是异步快照
         new FsStateBackend("", false);   // 文件系统
         // new RocksDBStateBackend()       // 数据库
         */
        // 设置StatePoint
        env.setStateBackend(new FsStateBackend("file:///D:/SourceCode2020/FlinkDemo/coding510-learn/imooc-flink/checkpoints"));   // file
        // env.setStateBackend(new FsStateBackend("hdfs://jiatao:8082/imooc-flink//checkpoints"));   // hdfs

        /*
         * // 设置checkpoint是否在进程挂掉保存下来：
         * ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION --保留
         * ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION --删除(默认)
         */
        // 是否保留
        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);


        // 自定义设置我们需要的重启策略
        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(
                3,      //尝试重启次数：不算第1次，第1次为正常启动。因此此处尝试启动4次
                Time.of(5, TimeUnit.SECONDS)));         // 间隔


        DataStreamSource<String> source = env.socketTextStream("localhost", 9999);
//        DataStreamSource<String> source = env.socketTextStream("hadoop", 9999);
        source.map(new MapFunction<String, String>() {
            @Override
            public String map(String value) throws Exception {
                if (value.contains("pk")) {
                    throw new RuntimeException("pk哥来了，快跑...");
                } else {
                    return value.toUpperCase();
                }
            }
        })
                .flatMap(new FlatMapFunction<String, String>() {
                    @Override
                    public void flatMap(String value, Collector<String> out) throws Exception {
                        String[] splits = value.split(",");
                        for (String split : splits) {
                            out.collect(split);
                        }
                    }
                })
                .map(new MapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> map(String value) throws Exception {
                        return Tuple2.of(value, 1);
                    }
                })
                .keyBy(x -> x.f0)
                .sum(1)
                .print();
        env.execute("CheckPointApp");
    }
}

