package com.imooc.flink.transformation;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;
import org.apache.flink.util.StringUtils;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/10 20:06
 * @File: TransformationApp2.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Transformation算子之filter/flatMap/keyby/reduce
 */
public class TransformationApp2 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//        filter(env);
//        flatMap(env);
//        keyBy(env);
        reduce(env);
        env.execute("TransformationApp2");
    }

    /*
     * wc :socket
     *
     * 进来的数据：pk,pk,flink    pk,spark,spark
     *
     * wc需求分析：
     * 1) 读进来的数据;
     * 2) 按照指定的分隔符进行拆分 pk pk flink pk spark spark
     * 3) 为每个单词赋上一个出现次数为1的值 (pk,1) (pk,1) ...
     * 4) 按照单词进行keyBy
     * 5) 分组求和
     * */
    public static void reduce(StreamExecutionEnvironment env) {
        DataStreamSource<String> source = env.socketTextStream("localhost", 9999);

        source.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public void flatMap(String s, Collector<String> collector) throws Exception {
                String[] splits = s.split(",");
                for (String word : splits) {
                    collector.collect(word);
                }
            }
        }).map(new MapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> map(String s) throws Exception {

//                return new Tuple2<>(s,1);
                return Tuple2.of(s, 1);
            }
        }).keyBy(x -> x.f0)   // 单词word相同的都会分到一个task中去执行
                //.sum(1)
                .reduce(new ReduceFunction<Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> reduce(Tuple2<String, Integer> value1, Tuple2<String, Integer> value2) throws Exception {
                        return Tuple2.of(value1.f0, value1.f1 + value2.f1);
                    }
                })
                .print();
    }

    // 按照domain分组,求traffic和
    public static void keyBy(StreamExecutionEnvironment env) {
        DataStreamSource<String> source = env.readTextFile("data/access.log");
//        source.print();
        SingleOutputStreamOperator<Access> mapSource = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String s) throws Exception {
                String[] splits = s.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });

        // mapSource.keyBy("domain").sum("traffic").print();   // keyBy()过时,flink1.9之前的写法

        // mapSource.keyBy(new KeySelector<Access, String>() {  // 常规做法
        //     @Override
        //     public String getKey(Access access) throws Exception {
        //         return access.getDomain();
        //     }
        // }).sum("traffic").print;

        KeyedStream<Access, String> keyedStream = mapSource.keyBy(x -> x.getDomain());  // λ表达式
        keyedStream.sum("traffic").print();

    }

    /*
     * 进来是一行行的数据： pk,pk,flink    pk,spark,spark
     * 需求：
     * 1、把一行行的数据按照逗号进行分割
     * 2、过滤掉pk
     *
     * */
    public static void flatMap(StreamExecutionEnvironment env) {
        DataStreamSource<String> source = env.socketTextStream("localhost", 9999);
        source.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public void flatMap(String s, Collector<String> collector) throws Exception {
                String[] splits = s.split(",");
                for (String split : splits) {
                    collector.collect(split);
                }
            }
        }).filter(new FilterFunction<String>() {
            @Override
            public boolean filter(String value) throws Exception {
                return !"pk".equals(value);
            }
        })
                .print();

    }

    // filter就是对DataStream中的数据进行过滤操作,保留true
    public static void filter(StreamExecutionEnvironment env) {
        DataStreamSource<String> source = env.readTextFile("data/access.log");
//        source.print();
        SingleOutputStreamOperator<Access> mapSource = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String s) throws Exception {
                String[] splits = s.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });
        // mapSource.print();
        SingleOutputStreamOperator<Access> filterStream = mapSource.filter(new FilterFunction<Access>() {
            @Override
            public boolean filter(Access access) throws Exception {
                return access.getTraffic() > 4000;
            }
        });
        filterStream.print();
    }
}
