package com.imooc.flink.transformation;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import java.util.ArrayList;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/10 19:52
 * @File: TransformationApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Transformation算子之map/richMap
 */
public class TransformationApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        map(env);
        // map2(env);
        // richMap(env);
        env.execute("TransformationApp");
    }

    public static void richMap(StreamExecutionEnvironment env) {
        env.setParallelism(3);
        DataStreamSource<String> source = env.readTextFile("data/access.log");
        SingleOutputStreamOperator<Access> mapStream = source.map(new PKMapFunction());
        mapStream.print();
    }

    /*
     * 读进来的数据是一行一行的，也是字符串类型的
     * TODO... 每一行数据 ==> Access
     * 将map算子对应的函数作用到DataStream,产生一个新的DataStream
     * map会作用到已有的DataStream这个数据集中的每一个元素上
     * */
    public static void map(StreamExecutionEnvironment env) {
        DataStreamSource<String> source = env.readTextFile("data/access.log");
//        source.print();
        SingleOutputStreamOperator<Access> mapSource = source.map(new MapFunction<String, Access>() {
            @Override
            public Access map(String s) throws Exception {
                String[] splits = s.split(",");
                Long time = Long.parseLong(splits[0].trim());
                String domain = splits[1].trim();
                Double traffic = Double.parseDouble(splits[2].trim());

                return new Access(time, domain, traffic);
            }
        });
        mapSource.print();  //// 输出的是地址:com.imooc.flink.transformation.Access@7a31372b，由于Access.toString()未实现

    }

    public static void map2(StreamExecutionEnvironment env) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        DataStreamSource<Integer> source = env.fromCollection(list);
        source.map(new MapFunction<Integer, Integer>() {
            @Override
            public Integer map(Integer value) throws Exception {
                return value * value;
            }
        }).print();

    }
}
