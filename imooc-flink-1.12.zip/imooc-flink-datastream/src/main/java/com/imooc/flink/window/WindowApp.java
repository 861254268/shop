package com.imooc.flink.window;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

import static com.imooc.flink.source.SourceApp2.test01;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/15 12:41
 * @File: WindowApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 基于ProcessingTime的Non-Keyed/keyed滚动窗口实战
 * <p>
 */
public class WindowApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // test01(env); // 不带key的
        test02(env); // 带keyed的

        env.execute("WindowApp");
    }

    public static void test02(StreamExecutionEnvironment env) {
        // HADOOP,1 spark,1
        env.socketTextStream("localhost", 9999)
                .map(new MapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> map(String value) throws Exception {
                        String[] splits = value.split(",");
                        return Tuple2.of(splits[0].trim(), Integer.parseInt(splits[1].trim()));
                    }
                })
                .keyBy(x -> x.f0)
                .window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
                .sum(1)
                .print();
    }

    public static void test01(StreamExecutionEnvironment env) {
        // .timeWindowAll(Time.seconds(5)) // 报错： Record has Long.MIN_VALUE timestamp (= no timestamp marker). Is the time characteristic set to 'ProcessingTime', or did you forget to call 'DataStream.assignTimestampsAndWatermarks(...)'?
        // 解决方案： env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);

        //env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);  // 过时的
        env.socketTextStream("localhost", 9999)
                .map(new MapFunction<String, Integer>() {
                    @Override
                    public Integer map(String value) throws Exception {
                        return Integer.parseInt(value);
                    }
                })
                // .timeWindowAll(Time.seconds(5)) // 过时的
                .windowAll(TumblingProcessingTimeWindows.of(Time.seconds(5)))
                .sum(0)
                .print();
    }

}
