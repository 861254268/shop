package com.imooc.flink.source;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.LocalStreamEnvironment;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/9 21:21
 * @File: SourceApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: StreamExecutionEnvironment详解
 */
public class SourceApp {
    public static void main(String[] args) throws Exception {
        // 执行上下文
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // 设置全局并行度
        // 如果算子没有设置并行度，以全局的并行度为准;
        // 如果算子自身设置并行度，那么以算子设置的并行度为准。
        env.setParallelism(5);
        // 创建的本地/远程执行环境，一般不用
        /**
         * StreamExecutionEnvironment.createLocalEnvironment();
         * StreamExecutionEnvironment.createLocalEnvironment(3);
         * StreamExecutionEnvironment.createLocalEnvironment(new Configuration());
         * StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(new Configuration());    // 可能用得较多
         * StreamExecutionEnvironment.createRemoteEnvironment(String host,int port, String... jarFiles);
         * */

        DataStreamSource<String> source = env.socketTextStream("localhost", 9999);
        System.out.println("source..." + source.getParallelism()); // 获取并行度 =1
        //source.print();

        // 接收socket过来的数据，一行一个单词，把pk的过滤掉
        SingleOutputStreamOperator<String> filterStream = source.filter(new FilterFunction<String>() {
            @Override
            public boolean filter(String s) throws Exception {
                return !"pk".equals(s);
            }
        }).setParallelism(6);

        System.out.println("filter..." + filterStream.getParallelism());   // 12 可自定义 例如：4
        filterStream.print();

        env.execute("SourceApp");
    }
}
