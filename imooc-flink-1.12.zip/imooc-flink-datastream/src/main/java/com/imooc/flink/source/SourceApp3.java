package com.imooc.flink.source;

import com.imooc.flink.transformation.Access;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/11 20:20
 * @File: SourceApp3.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: 自定义单并行/多并行Source/MySQL
 */
public class SourceApp3 {
    public static void main(String[] args) throws Exception {
        // 执行上下文
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // test03(env);  // 自定义单并行Source
        // test03V2(env);  // 自定义多并行Source
        test04(env);    // 自定义Source读取MySQL数据

        env.execute("SourceApp3");
    }

    // 方法重构

    public static void test04(StreamExecutionEnvironment env) {
        DataStreamSource<Student> source = env.addSource(new StudentSource());
        System.out.println(source.getParallelism());
        source.print();
    }


    public static void test03V2(StreamExecutionEnvironment env) {
        DataStreamSource<Access> source = env.addSource(new AccessSourceV2()) // 多并行默认并行度为机器core数,12
                .setParallelism(2);
        System.out.println(source.getParallelism());
        source.print();
    }

    public static void test03(StreamExecutionEnvironment env) {

        DataStreamSource<Access> source = env.addSource(new AccessSource()); // 单并行默认并行度为1
        // .setParallelism(2);   // 单并行默认并行度为1，设置为大于1的数会报错：The parallelism of non parallel operator must be 1.
        System.out.println(source.getParallelism());
        source.print();
    }
}
