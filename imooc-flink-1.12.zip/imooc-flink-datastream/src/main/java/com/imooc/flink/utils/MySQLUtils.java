package com.imooc.flink.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/11 20:02
 * @File: MySQLUtils.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption:
 */
public class MySQLUtils {
    // public static Connection getConnection() throws ClassNotFoundException {
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");   // 此处需要异常处理
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/pk_flink_imooc", "root", "123456"); // 此处需要异常处理
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // public static void close(Connection connection) throws SQLException {
    public static void close(Connection connection , PreparedStatement psmt) {
        if (null != connection) {
            try {
                connection.close();     // 此处需要异常处理
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if (null != psmt) {
            try {
                psmt.close();     // 此处需要异常处理
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public static void main(String[] args) {
        System.out.println(getConnection());
    }
}