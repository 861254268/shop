package com.imooc.flink.source;


import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;


import java.util.Properties;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/10 19:42
 * @File: SourceKafkaApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: Source API编程之对接kafka数据
 */
public class SourceKafkaApp {
    public static void main(String[] args) throws Exception {
        // 执行上下文
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        test05(env);
        env.execute("SourceKafkaApp");
    }

    // 方法重构，对接Kafka
    public static void test05(StreamExecutionEnvironment env) {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");
        properties.setProperty("group.id", "test");
        DataStream<String> stream = env
                .addSource(new FlinkKafkaConsumer<>("flinktopic", new SimpleStringSchema(), properties));

        System.out.println(env.getParallelism());
        stream.print();
    }
}
