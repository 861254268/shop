package com.imooc.flink.watermark;

import org.apache.commons.lang.time.FastDateFormat;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;


/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/15 17:32
 * @File: EventTimeWMApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: EventTime结合WaterMark的使用
 * <p>
 * 1) 基于EventTime和WaterMark结合滚动窗口综合案例之没有延迟
 * <p>
 * 2) 基于EventTime和WaterMark结合滚动窗口综合案例之有延迟
 * <p>
 * 3) 基于EventTime和WaterMark结合滚动窗口综合案例之延迟数据丢失
 * <p>
 * 4) 基于EventTime和WaterMark结合滚动窗口综合案例之捕获到延迟数据
 * 输入数据的格式：时间字段，单词，次数
 */
public class EventTimeWMApp {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // test01(env);    // sum:基于EventTime和WaterMark结合滚动窗口综合案例之没有延迟
        // test02(env);    // reduce:基于EventTime和WaterMark结合滚动窗口综合案例之有延迟
        // test03(env);    // reduce:基于EventTime和WaterMark结合滚动窗口综合案例之延迟数据丢失
        test04(env);          // reduce:基于EventTime和WaterMark结合滚动窗口综合案例之捕获到延迟数据


        env.execute("EventTimeWMApp");
    }

    public static void test04(StreamExecutionEnvironment env) {
        OutputTag<Tuple2<String, Integer>> outputTag = new OutputTag<Tuple2<String, Integer>>("late-data") {
        };
        /**
         * 分配WaterMark的两种方式：
         * 1) 接入数据的时候创建(推荐使用);
         * 2) 处理的时候创建。
         *
         * WM其实就是延迟触发的一种机制：
         * WM=数据所携带的时间(窗口中最大的时间)-延迟执行的时间
         * WM >= 上一个窗口的执行边界 就会触发窗口的执行
         * eg: 6999 - 2000 = 4999 >= 上一个窗口的边界
         * */
        SingleOutputStreamOperator<String> lines = env.socketTextStream("localhost", 9999)
                .assignTimestampsAndWatermarks( // 过时的方法
                        new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) {
                            // Time.seconds(0): 不允许延迟的
                            // Time.seconds(2):允许2s延迟
                            @Override
                            public long extractTimestamp(String element) {
                                return Long.parseLong(element.split(",")[0]);
                            }
                        }
                );


        SingleOutputStreamOperator<Tuple2<String, Integer>> mapStream = lines.map(new MapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> map(String value) throws Exception {
                String[] splits = value.split(",");

                return Tuple2.of(splits[1].trim(), Integer.parseInt(splits[2].trim()));
            }
        });


        // [1000,5000) [5000,10000)
        SingleOutputStreamOperator<String> windowStream
                = mapStream.keyBy(x -> x.f0)
                .window(TumblingEventTimeWindows.of(Time.seconds(5)))
                // 基于EventTime和WaterMark结合滚动窗口综合案例之捕获到延迟数据
                .sideOutputLateData(outputTag)
                .reduce(new ReduceFunction<Tuple2<String, Integer>>() {    // 第一个参数：增量
                    @Override
                    public Tuple2<String, Integer> reduce(Tuple2<String, Integer> value1, Tuple2<String, Integer> value2) throws Exception {
                        System.out.println("---reduce involed---" + value1.f0 + "==>" + (value1.f1 + value2.f1));
                        return Tuple2.of(value1.f0, value1.f1 + value2.f1);
                    }
                }, new ProcessWindowFunction<Tuple2<String, Integer>, String, String, TimeWindow>() {   // 第二个参数：全量

                    //时间格式化
                    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");

                    @Override
                    public void process(String s, Context context, Iterable<Tuple2<String, Integer>> elements, Collector<String> out) throws Exception {
                        for (Tuple2<String, Integer> element : elements) {
                            System.out.println(format.format(context.currentWatermark()));  // 当前时间
                            out.collect("[" + format.format(context.window().getStart()) + "==>" + format.format(context.window().getEnd()) + "]" + element.f0 + "==>" + element.f1);
                        }
                    }
                });
        windowStream.print();    // 主流的数据
        DataStream<Tuple2<String, Integer>> sideOutput = windowStream.getSideOutput(outputTag);
        sideOutput.printToErr();     // 侧流的数据：将延迟的数据标记为红色，便于观察
    }


    public static void test03(StreamExecutionEnvironment env) {
        /**
         * 分配WaterMark的两种方式：
         * 1) 接入数据的时候创建(推荐使用);
         * 2) 处理的时候创建。
         *
         * WM其实就是延迟触发的一种机制：
         * WM=数据所携带的时间(窗口中最大的时间)-延迟执行的时间
         * WM >= 上一个窗口的执行边界 就会触发窗口的执行
         * eg: 6999 - 2000 = 4999 >= 上一个窗口的边界
         * */
        SingleOutputStreamOperator<String> lines = env.socketTextStream("localhost", 9999)
                .assignTimestampsAndWatermarks( // 过时的方法
                        new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) {
                            // Time.seconds(0): 不允许延迟的
                            // Time.seconds(2):允许2s延迟
                            @Override
                            public long extractTimestamp(String element) {
                                return Long.parseLong(element.split(",")[0]);
                            }
                        }
                );

        SingleOutputStreamOperator<Tuple2<String, Integer>> mapStream = lines.map(new MapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> map(String value) throws Exception {
                String[] splits = value.split(",");

                return Tuple2.of(splits[1].trim(), Integer.parseInt(splits[2].trim()));
            }
        });

        // [1000,5000) [5000,10000)
        mapStream.keyBy(x -> x.f0)
                .window(TumblingEventTimeWindows.of(Time.seconds(5)))
                .reduce(new ReduceFunction<Tuple2<String, Integer>>() {    // 第一个参数
                    @Override
                    public Tuple2<String, Integer> reduce(Tuple2<String, Integer> value1, Tuple2<String, Integer> value2) throws Exception {
                        System.out.println("---reduce involed---" + value1.f0 + "==>" + (value1.f1 + value2.f1));
                        return Tuple2.of(value1.f0, value1.f1 + value2.f1);
                    }
                }, new ProcessWindowFunction<Tuple2<String, Integer>, String, String, TimeWindow>() {   // 第二个参数

                    //时间格式化
                    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");

                    @Override
                    public void process(String s, Context context, Iterable<Tuple2<String, Integer>> elements, Collector<String> out) throws Exception {
                        for (Tuple2<String, Integer> element : elements) {
                            System.out.println(format.format(context.currentWatermark()));  // 当前时间
                            out.collect("[" + format.format(context.window().getStart()) + "==>" + format.format(context.window().getEnd()) + "]" + element.f0 + "==>" + element.f1);
                        }
                    }
                })
                .print();
    }

    public static void test02(StreamExecutionEnvironment env) {
        /**
         * 分配WaterMark的两种方式：
         * 1) 接入数据的时候创建(推荐使用);
         * 2) 处理的时候创建。
         *
         * WM其实就是延迟触发的一种机制：
         * WM=数据所携带的时间(窗口中最大的时间)-延迟执行的时间
         * WM >= 上一个窗口的执行边界 就会触发窗口的执行
         * eg: 6999 - 2000 = 4999 >= 上一个窗口的边界
         * */
        SingleOutputStreamOperator<String> lines = env.socketTextStream("localhost", 9999)
                .assignTimestampsAndWatermarks( // 过时的方法
                        new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(2)) {
                            // Time.seconds(0): 不允许延迟的
                            // Time.seconds(2):允许2s延迟
                            @Override
                            public long extractTimestamp(String element) {
                                return Long.parseLong(element.split(",")[0]);
                            }
                        }
                );
        SingleOutputStreamOperator<Tuple2<String, Integer>> mapStream = lines.map(new MapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> map(String value) throws Exception {
                String[] splits = value.split(",");

                return Tuple2.of(splits[1].trim(), Integer.parseInt(splits[2].trim()));
            }
        });

        // [1000,5000) [5000,10000)
        mapStream.keyBy(x -> x.f0)
                .window(TumblingEventTimeWindows.of(Time.seconds(5)))
                .reduce(new ReduceFunction<Tuple2<String, Integer>>() {    // 第一个参数
                    @Override
                    public Tuple2<String, Integer> reduce(Tuple2<String, Integer> value1, Tuple2<String, Integer> value2) throws Exception {
                        System.out.println("---reduce involed---" + value1.f0 + "==>" + (value1.f1 + value2.f1));
                        return Tuple2.of(value1.f0, value1.f1 + value2.f1);
                    }
                }, new ProcessWindowFunction<Tuple2<String, Integer>, String, String, TimeWindow>() {   // 第二个参数

                    //时间格式化
                    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");

                    @Override
                    public void process(String s, Context context, Iterable<Tuple2<String, Integer>> elements, Collector<String> out) throws Exception {
                        for (Tuple2<String, Integer> element : elements) {
                            System.out.println(format.format(context.currentWatermark()));  // 当前时间
                            out.collect("[" + format.format(context.window().getStart()) + "==>" + format.format(context.window().getEnd()) + "]" + element.f0 + "==>" + element.f1);
                        }
                    }
                })
                .print();
    }

    // sum
    public static void test01(StreamExecutionEnvironment env) {
        /**
         * 分配WaterMark的两种方式：
         * 1) 接入数据的时候创建(推荐使用);
         * 2) 处理的时候创建。
         * */
        SingleOutputStreamOperator<String> lines = env.socketTextStream("localhost", 9999)
                .assignTimestampsAndWatermarks( // 过时的方法
                        new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) {   // Time.seconds(0): 不允许延迟的
                            @Override
                            public long extractTimestamp(String element) {
                                return Long.parseLong(element.split(",")[0]);
                            }
                        }
                );
        SingleOutputStreamOperator<Tuple2<String, Integer>> mapStream = lines.map(new MapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> map(String value) throws Exception {
                String[] splits = value.split(",");

                return Tuple2.of(splits[1].trim(), Integer.parseInt(splits[2].trim()));
            }
        });

        // [1000,5000) [5000,10000)
        mapStream.keyBy(x -> x.f0)
                .window(TumblingEventTimeWindows.of(Time.seconds(5)))
                .sum(1)
                .print();
    }
}
