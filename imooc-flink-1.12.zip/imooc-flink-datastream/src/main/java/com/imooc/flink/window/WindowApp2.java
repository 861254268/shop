package com.imooc.flink.window;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

/**
 * -*- coding: utf-8 -*-
 *
 * @Author: Mr.Jia
 * @Create Time: 2021/8/15 12:41
 * @File: WindowApp.scala/java
 * @Software: IntelliJ IDEA 2018.2.4
 * @descirption: WindowFunction之ReduceFunction/ProcessWindowFunction实战
 * <p>
 */
public class WindowApp2 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        test01(env);    // ReduceFunction
        // test02(env);    // ProcessWindowFunction
        // test03(env); // AggregateFunction 可以自己实现。。。

        env.execute("WindowApp");
    }

    // ProcessWindowFunction
    public static void test02(StreamExecutionEnvironment env) {
        // HADOOP,1 spark,1
        env.socketTextStream("localhost", 9999)
                .map(new MapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> map(String value) throws Exception {
                        return Tuple2.of("pk", Integer.parseInt(value));
                    }
                })
                .keyBy(x -> x.f0)
                .window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
                .process(new PKProcessWindowFunction())
                .print();
    }


    public static void test01(StreamExecutionEnvironment env) {
        // HADOOP,1 spark,1
        env.socketTextStream("localhost", 9999)
                .map(new MapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> map(String value) throws Exception {
                        String[] splits = value.split(",");
                        return Tuple2.of(splits[0].trim(), Integer.parseInt(splits[1].trim()));
                    }
                })
                .keyBy(x -> x.f0)
                .window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
                .reduce(new ReduceFunction<Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> reduce(Tuple2<String, Integer> value1, Tuple2<String, Integer> value2) throws Exception {
                        System.out.println("value1=[" + value1 + "],value2=[" + value2 + "]");
                        return Tuple2.of(value1.f0, value1.f1 + value1.f1);
                    }
                })
                .print();
    }
}
